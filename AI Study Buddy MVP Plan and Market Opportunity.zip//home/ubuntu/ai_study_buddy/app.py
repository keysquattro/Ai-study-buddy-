import os
import time
from flask import Flask, jsonify, request
from flask_cors import CORS
from dotenv import load_dotenv
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager

# Load environment variables
load_dotenv()

# Initialize SQLAlchemy
db = SQLAlchemy()
migrate = Migrate()
jwt = JWTManager()

def create_app(test_config=None):
    # Create and configure the app
    app = Flask(__name__, instance_relative_config=True)
    
    # Configure the app
    if test_config is None:
        # Load the instance config, if it exists, when not testing
        app.config.from_mapping(
            SECRET_KEY=os.environ.get('SECRET_KEY', 'dev'),
            SQLALCHEMY_DATABASE_URI=os.environ.get('DATABASE_URL', 'sqlite:///ai_study_buddy.db'),
            SQLALCHEMY_TRACK_MODIFICATIONS=False,
            JWT_SECRET_KEY=os.environ.get('JWT_SECRET_KEY', 'jwt-secret-key'),
            JWT_ACCESS_TOKEN_EXPIRES=86400,  # 24 hours
            OPENAI_API_KEY=os.environ.get('OPENAI_API_KEY', '')
        )
    else:
        # Load the test config if passed in
        app.config.from_mapping(test_config)
    
    # Ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass
    
    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    CORS(app)
    
    # Register blueprints
    from src.routes.auth import auth_bp
    from src.routes.notes import notes_bp
    from src.routes.homework import homework_bp
    from src.routes.reminders import reminders_bp
    from src.routes.scheduler import scheduler_bp
    from src.routes.study import study_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(notes_bp, url_prefix='/api/notes')
    app.register_blueprint(homework_bp, url_prefix='/api/homework')
    app.register_blueprint(reminders_bp, url_prefix='/api/reminders')
    app.register_blueprint(scheduler_bp, url_prefix='/api/scheduler')
    app.register_blueprint(study_bp, url_prefix='/api/study')
    
    # Create a simple route for testing
    @app.route('/api/health')
    def health_check():
        return jsonify({
            'status': 'healthy',
            'timestamp': time.time(),
            'version': '1.0.0'
        })
    
    # Create a dashboard route
    @app.route('/api/dashboard')
    def dashboard():
        # In a real implementation, this would fetch data from various services
        # For now, we'll return mock data
        return jsonify({
            'upcoming_assignments': [
                {
                    'id': 1,
                    'title': 'Math Problem Set 3',
                    'due_date': '2025-03-25T23:59:00',
                    'course_name': 'Calculus I',
                    'priority': 2
                },
                {
                    'id': 2,
                    'title': 'History Essay',
                    'due_date': '2025-03-28T23:59:00',
                    'course_name': 'World History',
                    'priority': 1
                }
            ],
            'upcoming_reminders': [
                {
                    'id': 1,
                    'title': 'Start Math Homework',
                    'reminder_date': '2025-03-22T10:00:00',
                    'priority': 2
                },
                {
                    'id': 2,
                    'title': 'Study for Physics Quiz',
                    'reminder_date': '2025-03-23T15:00:00',
                    'priority': 3
                }
            ],
            'class_schedule': [
                {
                    'id': 1,
                    'title': 'Calculus I',
                    'start_time': '09:00',
                    'end_time': '10:30',
                    'day_of_week': 1,
                    'location': 'Math Building, Room 101'
                },
                {
                    'id': 2,
                    'title': 'World History',
                    'start_time': '11:00',
                    'end_time': '12:30',
                    'day_of_week': 1,
                    'location': 'Humanities Building, Room 203'
                }
            ],
            'recent_notes': [
                {
                    'id': 1,
                    'title': 'Calculus: Limits and Continuity',
                    'created_at': '2025-03-18T14:30:00',
                    'course_name': 'Calculus I'
                },
                {
                    'id': 2,
                    'title': 'World War II: Major Events',
                    'created_at': '2025-03-17T10:15:00',
                    'course_name': 'World History'
                }
            ],
            'study_stats': {
                'notes_count': 15,
                'flashcard_sets': 8,
                'quizzes_completed': 12,
                'study_time_this_week': 14.5  # hours
            }
        })
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(e):
        return jsonify({'error': 'Not found'}), 404
    
    @app.errorhandler(500)
    def server_error(e):
        return jsonify({'error': 'Server error'}), 500
    
    return app

# This allows running the app with `python app.py`
if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True)
