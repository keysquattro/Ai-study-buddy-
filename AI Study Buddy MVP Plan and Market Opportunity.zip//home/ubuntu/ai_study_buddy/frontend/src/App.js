import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Box, CssBaseline } from '@mui/material';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Notes from './pages/Notes';
import Homework from './pages/Homework';
import Reminders from './pages/Reminders';
import Scheduler from './pages/Scheduler';
import Study from './pages/Study';
import Login from './pages/Login';
import Register from './pages/Register';
import PrivateRoute from './components/PrivateRoute';

function App() {
  const [open, setOpen] = React.useState(true);
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);

  const handleDrawerToggle = () => {
    setOpen(!open);
  };

  // For demo purposes, we'll auto-authenticate
  React.useEffect(() => {
    setIsAuthenticated(true);
  }, []);

  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      <Header open={open} handleDrawerToggle={handleDrawerToggle} isAuthenticated={isAuthenticated} />
      {isAuthenticated && <Sidebar open={open} handleDrawerToggle={handleDrawerToggle} />}
      
      <Box component="main" sx={{ 
        flexGrow: 1, 
        p: 3, 
        width: { sm: `calc(100% - ${240}px)` },
        marginTop: '64px'
      }}>
        <Routes>
          <Route path="/login" element={
            isAuthenticated ? <Navigate to="/dashboard" /> : <Login setIsAuthenticated={setIsAuthenticated} />
          } />
          <Route path="/register" element={
            isAuthenticated ? <Navigate to="/dashboard" /> : <Register setIsAuthenticated={setIsAuthenticated} />
          } />
          
          <Route path="/dashboard" element={
            <PrivateRoute isAuthenticated={isAuthenticated}>
              <Dashboard />
            </PrivateRoute>
          } />
          <Route path="/notes" element={
            <PrivateRoute isAuthenticated={isAuthenticated}>
              <Notes />
            </PrivateRoute>
          } />
          <Route path="/homework" element={
            <PrivateRoute isAuthenticated={isAuthenticated}>
              <Homework />
            </PrivateRoute>
          } />
          <Route path="/reminders" element={
            <PrivateRoute isAuthenticated={isAuthenticated}>
              <Reminders />
            </PrivateRoute>
          } />
          <Route path="/scheduler" element={
            <PrivateRoute isAuthenticated={isAuthenticated}>
              <Scheduler />
            </PrivateRoute>
          } />
          <Route path="/study" element={
            <PrivateRoute isAuthenticated={isAuthenticated}>
              <Study />
            </PrivateRoute>
          } />
          
          <Route path="/" element={<Navigate to="/dashboard" />} />
        </Routes>
      </Box>
    </Box>
  );
}

export default App;
