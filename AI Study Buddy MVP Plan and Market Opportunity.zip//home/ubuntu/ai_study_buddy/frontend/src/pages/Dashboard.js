import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  Paper,
  Button
} from '@mui/material';
import AssignmentIcon from '@mui/icons-material/Assignment';
import NotificationsIcon from '@mui/icons-material/Notifications';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import NoteIcon from '@mui/icons-material/Note';

const Dashboard = () => {
  // Mock data for demonstration
  const [upcomingAssignments] = useState([
    { id: 1, title: 'Math Problem Set 3', dueDate: '2025-03-25', course: 'Calculus I', priority: 'High' },
    { id: 2, title: 'History Essay', dueDate: '2025-03-28', course: 'World History', priority: 'Medium' },
    { id: 3, title: 'Physics Lab Report', dueDate: '2025-04-01', course: 'Physics 101', priority: 'High' }
  ]);

  const [upcomingReminders] = useState([
    { id: 1, title: 'Start Math Homework', date: '2025-03-22 10:00', priority: 'Medium' },
    { id: 2, title: 'Study for Physics Quiz', date: '2025-03-23 15:00', priority: 'High' },
    { id: 3, title: 'Meet with Study Group', date: '2025-03-24 14:00', priority: 'Medium' }
  ]);

  const [todayClasses] = useState([
    { id: 1, title: 'Calculus I', time: '09:00 - 10:30', location: 'Math Building, Room 101' },
    { id: 2, title: 'World History', time: '11:00 - 12:30', location: 'Humanities Building, Room 203' },
    { id: 3, title: 'Physics 101', time: '14:00 - 15:30', location: 'Science Center, Room 305' }
  ]);

  const [recentNotes] = useState([
    { id: 1, title: 'Calculus: Limits and Continuity', date: '2025-03-18', course: 'Calculus I' },
    { id: 2, title: 'World War II: Major Events', date: '2025-03-17', course: 'World History' },
    { id: 3, title: 'Newton\'s Laws of Motion', date: '2025-03-16', course: 'Physics 101' }
  ]);

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'High': return 'error.main';
      case 'Medium': return 'warning.main';
      case 'Low': return 'success.main';
      default: return 'text.secondary';
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom component="h1" sx={{ fontWeight: 'bold', mb: 3 }}>
        Dashboard
      </Typography>
      
      <Grid container spacing={3}>
        {/* Stats Cards */}
        <Grid item xs={12} md={3}>
          <Paper
            sx={{
              p: 2,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              bgcolor: 'primary.light',
              color: 'white',
              borderRadius: 2
            }}
          >
            <Typography component="h2" variant="h6" gutterBottom>
              Notes
            </Typography>
            <Typography component="p" variant="h3">
              15
            </Typography>
            <Typography variant="body2" sx={{ mt: 1 }}>
              Total notes created
            </Typography>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={3}>
          <Paper
            sx={{
              p: 2,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              bgcolor: 'secondary.light',
              color: 'white',
              borderRadius: 2
            }}
          >
            <Typography component="h2" variant="h6" gutterBottom>
              Flashcards
            </Typography>
            <Typography component="p" variant="h3">
              8
            </Typography>
            <Typography variant="body2" sx={{ mt: 1 }}>
              Flashcard sets created
            </Typography>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={3}>
          <Paper
            sx={{
              p: 2,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              bgcolor: 'success.light',
              color: 'white',
              borderRadius: 2
            }}
          >
            <Typography component="h2" variant="h6" gutterBottom>
              Quizzes
            </Typography>
            <Typography component="p" variant="h3">
              12
            </Typography>
            <Typography variant="body2" sx={{ mt: 1 }}>
              Quizzes completed
            </Typography>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={3}>
          <Paper
            sx={{
              p: 2,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              bgcolor: 'warning.light',
              color: 'white',
              borderRadius: 2
            }}
          >
            <Typography component="h2" variant="h6" gutterBottom>
              Study Time
            </Typography>
            <Typography component="p" variant="h3">
              14.5
            </Typography>
            <Typography variant="body2" sx={{ mt: 1 }}>
              Hours this week
            </Typography>
          </Paper>
        </Grid>

        {/* Upcoming Assignments */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardHeader 
              title="Upcoming Assignments" 
              titleTypographyProps={{ variant: 'h6' }}
              avatar={<AssignmentIcon color="primary" />}
              action={
                <Button size="small" color="primary">
                  View All
                </Button>
              }
            />
            <Divider />
            <CardContent sx={{ p: 0 }}>
              <List>
                {upcomingAssignments.map((assignment) => (
                  <React.Fragment key={assignment.id}>
                    <ListItem button>
                      <ListItemIcon>
                        <Box 
                          sx={{ 
                            width: 10, 
                            height: 10, 
                            borderRadius: '50%', 
                            bgcolor: getPriorityColor(assignment.priority),
                            mr: 1
                          }} 
                        />
                      </ListItemIcon>
                      <ListItemText 
                        primary={assignment.title} 
                        secondary={`Due: ${assignment.dueDate} • ${assignment.course}`}
                      />
                    </ListItem>
                    <Divider variant="inset" component="li" />
                  </React.Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Upcoming Reminders */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardHeader 
              title="Upcoming Reminders" 
              titleTypographyProps={{ variant: 'h6' }}
              avatar={<NotificationsIcon color="secondary" />}
              action={
                <Button size="small" color="primary">
                  View All
                </Button>
              }
            />
            <Divider />
            <CardContent sx={{ p: 0 }}>
              <List>
                {upcomingReminders.map((reminder) => (
                  <React.Fragment key={reminder.id}>
                    <ListItem button>
                      <ListItemIcon>
                        <Box 
                          sx={{ 
                            width: 10, 
                            height: 10, 
                            borderRadius: '50%', 
                            bgcolor: getPriorityColor(reminder.priority),
                            mr: 1
                          }} 
                        />
                      </ListItemIcon>
                      <ListItemText 
                        primary={reminder.title} 
                        secondary={`${reminder.date}`}
                      />
                    </ListItem>
                    <Divider variant="inset" component="li" />
                  </React.Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Today's Classes */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardHeader 
              title="Today's Classes" 
              titleTypographyProps={{ variant: 'h6' }}
              avatar={<CalendarTodayIcon color="primary" />}
              action={
                <Button size="small" color="primary">
                  Full Schedule
                </Button>
              }
            />
            <Divider />
            <CardContent sx={{ p: 0 }}>
              <List>
                {todayClasses.map((classItem) => (
                  <React.Fragment key={classItem.id}>
                    <ListItem button>
                      <ListItemText 
                        primary={classItem.title} 
                        secondary={`${classItem.time} • ${classItem.location}`}
                      />
                    </ListItem>
                    <Divider component="li" />
                  </React.Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Recent Notes */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%' }}>
            <CardHeader 
              title="Recent Notes" 
              titleTypographyProps={{ variant: 'h6' }}
              avatar={<NoteIcon color="secondary" />}
              action={
                <Button size="small" color="primary">
                  View All
                </Button>
              }
            />
            <Divider />
            <CardContent sx={{ p: 0 }}>
              <List>
                {recentNotes.map((note) => (
                  <React.Fragment key={note.id}>
                    <ListItem button>
                      <ListItemText 
                        primary={note.title} 
                        secondary={`${note.date} • ${note.course}`}
                      />
                    </ListItem>
                    <Divider component="li" />
                  </React.Fragment>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Study Progress */}
        <Grid item xs={12}>
          <Card>
            <CardHeader 
              title="Study Progress" 
              titleTypographyProps={{ variant: 'h6' }}
              avatar={<TrendingUpIcon color="primary" />}
            />
            <Divider />
            <CardContent>
              <Typography variant="body2" color="text.secondary" paragraph>
                Your study progress visualization will appear here, showing your activity over time, 
                completion rates for assignments, and mastery of subjects based on quiz performance.
              </Typography>
              <Box sx={{ 
                height: 100, 
                bgcolor: 'background.paper', 
                borderRadius: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <Typography variant="body2" color="text.secondary">
                  Progress visualization placeholder
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Dashboard;
