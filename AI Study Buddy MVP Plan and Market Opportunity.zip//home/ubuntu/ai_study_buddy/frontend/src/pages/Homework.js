import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  TextField, 
  Button, 
  Tabs, 
  Tab, 
  Divider,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  IconButton,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextareaAutosize
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import AssignmentIcon from '@mui/icons-material/Assignment';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import DateRangeIcon from '@mui/icons-material/DateRange';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';

const Homework = () => {
  const [tabValue, setTabValue] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAssistant, setShowAssistant] = useState(false);
  const [assistantQuery, setAssistantQuery] = useState('');
  
  // Mock data for demonstration
  const [assignments] = useState([
    { 
      id: 1, 
      title: 'Math Problem Set 3', 
      description: 'Complete problems 1-20 on page 35 of the textbook.',
      dueDate: '2025-03-25', 
      course: 'Calculus I',
      status: 'Not Started',
      priority: 'High'
    },
    { 
      id: 2, 
      title: 'History Essay', 
      description: 'Write a 5-page essay on the causes and effects of World War II.',
      dueDate: '2025-03-28', 
      course: 'World History',
      status: 'In Progress',
      priority: 'Medium'
    },
    { 
      id: 3, 
      title: 'Physics Lab Report', 
      description: 'Write a lab report on the pendulum experiment conducted in class.',
      dueDate: '2025-04-01', 
      course: 'Physics 101',
      status: 'Not Started',
      priority: 'High'
    },
    { 
      id: 4, 
      title: 'Chemistry Problem Set', 
      description: 'Complete the problems on balancing chemical equations.',
      dueDate: '2025-03-30', 
      course: 'Chemistry 201',
      status: 'Completed',
      priority: 'Medium'
    }
  ]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const handleAssistantQueryChange = (event) => {
    setAssistantQuery(event.target.value);
  };

  const toggleAssistant = () => {
    setShowAssistant(!showAssistant);
  };

  // Filter assignments based on search query and active tab
  const filteredAssignments = assignments.filter(assignment => {
    const matchesSearch = assignment.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         assignment.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         assignment.course.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (tabValue === 0) return matchesSearch; // All assignments
    if (tabValue === 1) return matchesSearch && assignment.status === 'Not Started'; // Not Started
    if (tabValue === 2) return matchesSearch && assignment.status === 'In Progress'; // In Progress
    if (tabValue === 3) return matchesSearch && assignment.status === 'Completed'; // Completed
    
    return false;
  });

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'High': return 'error';
      case 'Medium': return 'warning';
      case 'Low': return 'success';
      default: return 'default';
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'Not Started': return 'error';
      case 'In Progress': return 'warning';
      case 'Completed': return 'success';
      default: return 'default';
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Homework
        </Typography>
        <Box>
          <Button 
            variant="outlined" 
            color="secondary" 
            startIcon={<HelpOutlineIcon />}
            onClick={toggleAssistant}
            sx={{ mr: 2 }}
          >
            Homework Assistant
          </Button>
          <Button 
            variant="contained" 
            color="primary" 
            startIcon={<AddIcon />}
          >
            New Assignment
          </Button>
        </Box>
      </Box>
      
      {showAssistant && (
        <Paper sx={{ p: 3, mb: 3, bgcolor: 'background.paper', borderRadius: 2 }}>
          <Typography variant="h6" gutterBottom>
            Homework Assistant
          </Typography>
          <Typography variant="body2" color="text.secondary" paragraph>
            Get step-by-step explanations, citation help, or grammar checking for your assignments.
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                multiline
                rows={4}
                placeholder="Enter your question or problem here..."
                variant="outlined"
                value={assistantQuery}
                onChange={handleAssistantQueryChange}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth size="small">
                <InputLabel>Assignment</InputLabel>
                <Select
                  label="Assignment"
                  defaultValue=""
                >
                  <MenuItem value="">None</MenuItem>
                  {assignments.map(assignment => (
                    <MenuItem key={assignment.id} value={assignment.id}>
                      {assignment.title}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth size="small">
                <InputLabel>Help Type</InputLabel>
                <Select
                  label="Help Type"
                  defaultValue="explanation"
                >
                  <MenuItem value="explanation">Step-by-Step Explanation</MenuItem>
                  <MenuItem value="citation">Citation Generation</MenuItem>
                  <MenuItem value="grammar">Grammar & Style Check</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Button 
                variant="contained" 
                color="secondary" 
                startIcon={<AutoAwesomeIcon />}
                disabled={!assistantQuery.trim()}
              >
                Generate Help
              </Button>
            </Grid>
          </Grid>
        </Paper>
      )}
      
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper sx={{ p: 2, mb: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <TextField
                fullWidth
                placeholder="Search assignments..."
                variant="outlined"
                size="small"
                value={searchQuery}
                onChange={handleSearchChange}
                InputProps={{
                  startAdornment: <SearchIcon sx={{ color: 'text.secondary', mr: 1 }} />,
                }}
                sx={{ mr: 2 }}
              />
              <IconButton>
                <FilterListIcon />
              </IconButton>
            </Box>
            
            <Tabs 
              value={tabValue} 
              onChange={handleTabChange}
              indicatorColor="primary"
              textColor="primary"
            >
              <Tab label="All Assignments" />
              <Tab label="Not Started" />
              <Tab label="In Progress" />
              <Tab label="Completed" />
            </Tabs>
          </Paper>
        </Grid>
        
        {filteredAssignments.length > 0 ? (
          filteredAssignments.map(assignment => (
            <Grid item xs={12} key={assignment.id}>
              <Card>
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={8}>
                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                        <AssignmentIcon color="primary" sx={{ mr: 1 }} />
                        <Typography variant="h6" component="h2">
                          {assignment.title}
                        </Typography>
                      </Box>
                      
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                        {assignment.course}
                      </Typography>
                      
                      <Typography variant="body1" paragraph>
                        {assignment.description}
                      </Typography>
                    </Grid>
                    
                    <Grid item xs={12} sm={4}>
                      <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <DateRangeIcon fontSize="small" sx={{ mr: 1, color: 'text.secondary' }} />
                          <Typography variant="body2">
                            Due: {assignment.dueDate}
                          </Typography>
                        </Box>
                        
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <PriorityHighIcon fontSize="small" sx={{ mr: 1, color: 'text.secondary' }} />
                          <Chip 
                            label={`Priority: ${assignment.priority}`} 
                            size="small" 
                            color={getPriorityColor(assignment.priority)}
                            variant="outlined"
                          />
                        </Box>
                        
                        <Box sx={{ mb: 2 }}>
                          <Chip 
                            label={`Status: ${assignment.status}`} 
                            size="small" 
                            color={getStatusColor(assignment.status)}
                          />
                        </Box>
                        
                        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 'auto' }}>
                          <Button 
                            size="small" 
                            startIcon={<HelpOutlineIcon />}
                            sx={{ mr: 1 }}
                            onClick={toggleAssistant}
                          >
                            Get Help
                          </Button>
                          <IconButton size="small">
                            <EditIcon fontSize="small" />
                          </IconButton>
                          <IconButton size="small" color="error">
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Box>
                      </Box>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          ))
        ) : (
          <Grid item xs={12}>
            <Paper sx={{ p: 3, textAlign: 'center' }}>
              <Typography variant="body1" color="text.secondary">
                No assignments found. Try adjusting your search or create a new assignment.
              </Typography>
            </Paper>
          </Grid>
        )}
      </Grid>
    </Container>
  );
};

export default Homework;
