import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  TextField, 
  Button, 
  Tabs, 
  Tab, 
  Divider,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  IconButton,
  Chip
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import NoteIcon from '@mui/icons-material/Note';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';

const Notes = () => {
  const [tabValue, setTabValue] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Mock data for demonstration
  const [notes] = useState([
    { 
      id: 1, 
      title: 'Calculus: Limits and Continuity', 
      content: 'A limit is the value that a function approaches as the input approaches some value. Continuity requires the function to be defined at a point, the limit exists at that point, and the limit equals the function value.',
      date: '2025-03-18', 
      course: 'Calculus I',
      tags: ['math', 'calculus', 'limits'],
      isAiGenerated: true
    },
    { 
      id: 2, 
      title: 'World War II: Major Events', 
      content: 'Key events include German invasion of Poland (1939), Pearl Harbor (1941), D-Day (1944), and the atomic bombings of Hiroshima and Nagasaki (1945).',
      date: '2025-03-17', 
      course: 'World History',
      tags: ['history', 'war', 'politics'],
      isAiGenerated: false
    },
    { 
      id: 3, 
      title: 'Newton\'s Laws of Motion', 
      content: 'First Law: An object at rest stays at rest, and an object in motion stays in motion unless acted upon by an external force. Second Law: F = ma. Third Law: For every action, there is an equal and opposite reaction.',
      date: '2025-03-16', 
      course: 'Physics 101',
      tags: ['physics', 'mechanics', 'newton'],
      isAiGenerated: true
    },
    { 
      id: 4, 
      title: 'Organic Chemistry: Functional Groups', 
      content: 'Common functional groups include alcohols (-OH), aldehydes (-CHO), ketones (-CO-), carboxylic acids (-COOH), and amines (-NH2).',
      date: '2025-03-15', 
      course: 'Chemistry 201',
      tags: ['chemistry', 'organic', 'functional groups'],
      isAiGenerated: false
    }
  ]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  // Filter notes based on search query and active tab
  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         note.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         note.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (tabValue === 0) return matchesSearch; // All notes
    if (tabValue === 1) return matchesSearch && note.isAiGenerated; // AI-generated notes
    if (tabValue === 2) return matchesSearch && !note.isAiGenerated; // Manual notes
    
    return false;
  });

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Notes
        </Typography>
        <Button 
          variant="contained" 
          color="primary" 
          startIcon={<AddIcon />}
        >
          New Note
        </Button>
      </Box>
      
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper sx={{ p: 2, mb: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <TextField
                fullWidth
                placeholder="Search notes..."
                variant="outlined"
                size="small"
                value={searchQuery}
                onChange={handleSearchChange}
                InputProps={{
                  startAdornment: <SearchIcon sx={{ color: 'text.secondary', mr: 1 }} />,
                }}
                sx={{ mr: 2 }}
              />
              <IconButton>
                <FilterListIcon />
              </IconButton>
              <Button 
                variant="outlined" 
                color="secondary" 
                startIcon={<AutoAwesomeIcon />}
                sx={{ ml: 2 }}
              >
                Generate Notes
              </Button>
            </Box>
            
            <Tabs 
              value={tabValue} 
              onChange={handleTabChange}
              indicatorColor="primary"
              textColor="primary"
            >
              <Tab label="All Notes" />
              <Tab label="AI-Generated" />
              <Tab label="My Notes" />
            </Tabs>
          </Paper>
        </Grid>
        
        {filteredNotes.length > 0 ? (
          filteredNotes.map(note => (
            <Grid item xs={12} md={6} key={note.id}>
              <Card sx={{ height: '100%' }}>
                <CardContent>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <Typography variant="h6" component="h2" gutterBottom>
                      {note.title}
                    </Typography>
                    <Box>
                      {note.isAiGenerated && (
                        <Chip 
                          size="small" 
                          icon={<AutoAwesomeIcon />} 
                          label="AI Generated" 
                          color="secondary" 
                          variant="outlined"
                          sx={{ mr: 1 }}
                        />
                      )}
                    </Box>
                  </Box>
                  
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    {note.date} • {note.course}
                  </Typography>
                  
                  <Typography variant="body1" paragraph sx={{ 
                    mb: 2,
                    display: '-webkit-box',
                    WebkitLineClamp: 3,
                    WebkitBoxOrient: 'vertical',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                  }}>
                    {note.content}
                  </Typography>
                  
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 2 }}>
                    {note.tags.map(tag => (
                      <Chip 
                        key={tag} 
                        label={tag} 
                        size="small" 
                        variant="outlined" 
                        color="primary"
                      />
                    ))}
                  </Box>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                    <IconButton size="small">
                      <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton size="small" color="error">
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))
        ) : (
          <Grid item xs={12}>
            <Paper sx={{ p: 3, textAlign: 'center' }}>
              <Typography variant="body1" color="text.secondary">
                No notes found. Try adjusting your search or create a new note.
              </Typography>
            </Paper>
          </Grid>
        )}
      </Grid>
    </Container>
  );
};

export default Notes;
