import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  TextField, 
  Button, 
  Tabs, 
  Tab, 
  Paper,
  IconButton,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  ListItemSecondaryAction,
  Divider
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import NotificationsIcon from '@mui/icons-material/Notifications';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import DateRangeIcon from '@mui/icons-material/DateRange';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import SnoozeIcon from '@mui/icons-material/Snooze';

const Reminders = () => {
  const [tabValue, setTabValue] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Mock data for demonstration
  const [reminders] = useState([
    { 
      id: 1, 
      title: 'Start Math Homework', 
      description: 'Begin working on Math Problem Set 3',
      date: '2025-03-22 10:00', 
      status: 'Active',
      priority: 'Medium',
      isRecurring: false,
      linkedAssignment: 'Math Problem Set 3',
      linkedClass: 'Calculus I'
    },
    { 
      id: 2, 
      title: 'Study for Physics Quiz', 
      description: 'Review chapters 5-7 for upcoming quiz',
      date: '2025-03-23 15:00', 
      status: 'Active',
      priority: 'High',
      isRecurring: false,
      linkedAssignment: null,
      linkedClass: 'Physics 101'
    },
    { 
      id: 3, 
      title: 'Meet with Study Group', 
      description: 'Weekly study group meeting at the library',
      date: '2025-03-24 14:00', 
      status: 'Active',
      priority: 'Medium',
      isRecurring: true,
      recurrencePattern: 'Weekly',
      linkedAssignment: null,
      linkedClass: null
    },
    { 
      id: 4, 
      title: 'Submit History Essay Draft', 
      description: 'Submit draft for feedback before final submission',
      date: '2025-03-26 23:59', 
      status: 'Active',
      priority: 'High',
      isRecurring: false,
      linkedAssignment: 'History Essay',
      linkedClass: 'World History'
    },
    { 
      id: 5, 
      title: 'Review Chemistry Notes', 
      description: 'Review notes from last lecture',
      date: '2025-03-21 18:00', 
      status: 'Completed',
      priority: 'Low',
      isRecurring: false,
      linkedAssignment: null,
      linkedClass: 'Chemistry 201'
    }
  ]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  // Filter reminders based on search query and active tab
  const filteredReminders = reminders.filter(reminder => {
    const matchesSearch = reminder.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         reminder.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (tabValue === 0) return matchesSearch; // All reminders
    if (tabValue === 1) return matchesSearch && reminder.status === 'Active'; // Active
    if (tabValue === 2) return matchesSearch && reminder.status === 'Completed'; // Completed
    if (tabValue === 3) return matchesSearch && reminder.isRecurring; // Recurring
    
    return false;
  });

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'High': return 'error';
      case 'Medium': return 'warning';
      case 'Low': return 'success';
      default: return 'default';
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Reminders
        </Typography>
        <Box>
          <Button 
            variant="outlined" 
            color="secondary" 
            startIcon={<AutoAwesomeIcon />}
            sx={{ mr: 2 }}
          >
            Suggest Reminders
          </Button>
          <Button 
            variant="contained" 
            color="primary" 
            startIcon={<AddIcon />}
          >
            New Reminder
          </Button>
        </Box>
      </Box>
      
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper sx={{ p: 2, mb: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <TextField
                fullWidth
                placeholder="Search reminders..."
                variant="outlined"
                size="small"
                value={searchQuery}
                onChange={handleSearchChange}
                InputProps={{
                  startAdornment: <SearchIcon sx={{ color: 'text.secondary', mr: 1 }} />,
                }}
                sx={{ mr: 2 }}
              />
              <IconButton>
                <FilterListIcon />
              </IconButton>
            </Box>
            
            <Tabs 
              value={tabValue} 
              onChange={handleTabChange}
              indicatorColor="primary"
              textColor="primary"
            >
              <Tab label="All Reminders" />
              <Tab label="Active" />
              <Tab label="Completed" />
              <Tab label="Recurring" />
            </Tabs>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={8}>
          {filteredReminders.length > 0 ? (
            <Paper>
              <List>
                {filteredReminders.map((reminder, index) => (
                  <React.Fragment key={reminder.id}>
                    <ListItem alignItems="flex-start">
                      <ListItemIcon>
                        <NotificationsIcon color={reminder.status === 'Completed' ? 'disabled' : 'primary'} />
                      </ListItemIcon>
                      <ListItemText
                        primary={
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Typography
                              variant="subtitle1"
                              component="span"
                              sx={{
                                textDecoration: reminder.status === 'Completed' ? 'line-through' : 'none',
                                color: reminder.status === 'Completed' ? 'text.disabled' : 'text.primary',
                              }}
                            >
                              {reminder.title}
                            </Typography>
                            {reminder.isRecurring && (
                              <Chip 
                                size="small" 
                                label="Recurring" 
                                color="info" 
                                variant="outlined"
                                sx={{ ml: 1 }}
                              />
                            )}
                            <Chip 
                              size="small" 
                              label={reminder.priority} 
                              color={getPriorityColor(reminder.priority)}
                              variant="outlined"
                              sx={{ ml: 1 }}
                            />
                          </Box>
                        }
                        secondary={
                          <>
                            <Typography
                              component="span"
                              variant="body2"
                              color={reminder.status === 'Completed' ? 'text.disabled' : 'text.primary'}
                            >
                              {reminder.description}
                            </Typography>
                            <Box sx={{ mt: 1, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                <DateRangeIcon fontSize="small" sx={{ mr: 0.5, fontSize: '1rem' }} />
                                <Typography variant="caption" color="text.secondary">
                                  {reminder.date}
                                </Typography>
                              </Box>
                              
                              {reminder.linkedAssignment && (
                                <Typography variant="caption" color="text.secondary">
                                  • Assignment: {reminder.linkedAssignment}
                                </Typography>
                              )}
                              
                              {reminder.linkedClass && (
                                <Typography variant="caption" color="text.secondary">
                                  • Class: {reminder.linkedClass}
                                </Typography>
                              )}
                            </Box>
                          </>
                        }
                      />
                      <ListItemSecondaryAction>
                        <IconButton edge="end" aria-label="complete" sx={{ mr: 1 }}>
                          <CheckCircleIcon color={reminder.status === 'Completed' ? 'success' : 'disabled'} />
                        </IconButton>
                        <IconButton edge="end" aria-label="snooze" sx={{ mr: 1 }}>
                          <SnoozeIcon />
                        </IconButton>
                        <IconButton edge="end" aria-label="edit" sx={{ mr: 1 }}>
                          <EditIcon />
                        </IconButton>
                        <IconButton edge="end" aria-label="delete">
                          <DeleteIcon color="error" />
                        </IconButton>
                      </ListItemSecondaryAction>
                    </ListItem>
                    {index < filteredReminders.length - 1 && <Divider variant="inset" component="li" />}
                  </React.Fragment>
                ))}
              </List>
            </Paper>
          ) : (
            <Paper sx={{ p: 3, textAlign: 'center' }}>
              <Typography variant="body1" color="text.secondary">
                No reminders found. Try adjusting your search or create a new reminder.
              </Typography>
            </Paper>
          )}
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Quick Add Reminder
              </Typography>
              
              <TextField
                fullWidth
                label="Title"
                variant="outlined"
                size="small"
                margin="normal"
              />
              
              <TextField
                fullWidth
                label="Description"
                variant="outlined"
                size="small"
                multiline
                rows={2}
                margin="normal"
              />
              
              <TextField
                fullWidth
                label="Date & Time"
                type="datetime-local"
                variant="outlined"
                size="small"
                margin="normal"
                InputLabelProps={{
                  shrink: true,
                }}
                defaultValue="2025-03-25T10:00"
              />
              
              <FormControl fullWidth margin="normal" size="small">
                <InputLabel>Priority</InputLabel>
                <Select
                  label="Priority"
                  defaultValue="Medium"
                >
                  <MenuItem value="High">High</MenuItem>
                  <MenuItem value="Medium">Medium</MenuItem>
                  <MenuItem value="Low">Low</MenuItem>
                </Select>
              </FormControl>
              
              <FormControlLabel
                control={<Switch />}
                label="Recurring"
                margin="normal"
              />
              
              <Box sx={{ mt: 2 }}>
                <Button 
                  fullWidth
                  variant="contained" 
                  color="primary" 
                  startIcon={<AddIcon />}
                >
                  Add Reminder
                </Button>
              </Box>
            </CardContent>
          </Card>
          
          <Card sx={{ mt: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Study Schedule
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                Generate an optimized study schedule based on your assignments and deadlines.
              </Typography>
              <Button 
                fullWidth
                variant="outlined" 
                color="secondary" 
                startIcon={<AutoAwesomeIcon />}
              >
                Generate Schedule
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Reminders;
