import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  TextField, 
  Button, 
  Tabs, 
  Tab, 
  Paper,
  IconButton,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  ListItemSecondaryAction,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import SchoolIcon from '@mui/icons-material/School';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import PersonIcon from '@mui/icons-material/Person';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import WarningIcon from '@mui/icons-material/Warning';

const Scheduler = () => {
  const [tabValue, setTabValue] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Mock data for demonstration
  const [classes] = useState([
    { 
      id: 1, 
      title: 'Calculus I', 
      instructor: 'Dr. Smith',
      location: 'Math Building, Room 101',
      startDate: '2025-01-15',
      endDate: '2025-05-15',
      sessions: [
        { day: 1, startTime: '09:00', endTime: '10:30', isOnline: false },
        { day: 3, startTime: '09:00', endTime: '10:30', isOnline: false }
      ]
    },
    { 
      id: 2, 
      title: 'World History', 
      instructor: 'Prof. Johnson',
      location: 'Humanities Building, Room 203',
      startDate: '2025-01-15',
      endDate: '2025-05-15',
      sessions: [
        { day: 1, startTime: '11:00', endTime: '12:30', isOnline: false },
        { day: 3, startTime: '11:00', endTime: '12:30', isOnline: false }
      ]
    },
    { 
      id: 3, 
      title: 'Physics 101', 
      instructor: 'Dr. Garcia',
      location: 'Science Center, Room 305',
      startDate: '2025-01-15',
      endDate: '2025-05-15',
      sessions: [
        { day: 2, startTime: '14:00', endTime: '15:30', isOnline: false },
        { day: 4, startTime: '14:00', endTime: '15:30', isOnline: true, meetingLink: 'https://zoom.us/j/123456789' }
      ]
    },
    { 
      id: 4, 
      title: 'Chemistry 201', 
      instructor: 'Dr. Williams',
      location: 'Science Center, Room 210',
      startDate: '2025-01-15',
      endDate: '2025-05-15',
      sessions: [
        { day: 2, startTime: '09:30', endTime: '11:00', isOnline: false },
        { day: 4, startTime: '09:30', endTime: '11:00', isOnline: false }
      ]
    }
  ]);

  const [conflicts] = useState([
    {
      class1: 'Physics 101',
      class2: 'Chemistry 201',
      day: 'Tuesday',
      time: '14:00 - 15:30 overlaps with 09:30 - 11:00',
      severity: 'Warning'
    }
  ]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  // Filter classes based on search query
  const filteredClasses = classes.filter(classItem => 
    classItem.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    classItem.instructor.toLowerCase().includes(searchQuery.toLowerCase()) ||
    classItem.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getDayName = (day) => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[day];
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Class Scheduler
        </Typography>
        <Box>
          <Button 
            variant="outlined" 
            color="secondary" 
            startIcon={<CloudUploadIcon />}
            sx={{ mr: 2 }}
          >
            Import Schedule
          </Button>
          <Button 
            variant="contained" 
            color="primary" 
            startIcon={<AddIcon />}
          >
            Add Class
          </Button>
        </Box>
      </Box>
      
      {conflicts.length > 0 && (
        <Paper sx={{ p: 2, mb: 3, bgcolor: 'warning.light' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <WarningIcon color="warning" sx={{ mr: 1 }} />
            <Typography variant="subtitle1" fontWeight="bold">
              Schedule Conflicts Detected
            </Typography>
          </Box>
          <List dense>
            {conflicts.map((conflict, index) => (
              <ListItem key={index}>
                <ListItemText 
                  primary={`${conflict.class1} conflicts with ${conflict.class2}`}
                  secondary={`${conflict.day}: ${conflict.time}`}
                />
                <ListItemSecondaryAction>
                  <Button size="small" variant="outlined">
                    Resolve
                  </Button>
                </ListItemSecondaryAction>
              </ListItem>
            ))}
          </List>
        </Paper>
      )}
      
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper sx={{ p: 2, mb: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <TextField
                fullWidth
                placeholder="Search classes..."
                variant="outlined"
                size="small"
                value={searchQuery}
                onChange={handleSearchChange}
                InputProps={{
                  startAdornment: <SearchIcon sx={{ color: 'text.secondary', mr: 1 }} />,
                }}
                sx={{ mr: 2 }}
              />
              <IconButton>
                <FilterListIcon />
              </IconButton>
              <Button 
                variant="outlined" 
                color="secondary" 
                startIcon={<AutoAwesomeIcon />}
                sx={{ ml: 2 }}
              >
                Optimize Schedule
              </Button>
            </Box>
            
            <Tabs 
              value={tabValue} 
              onChange={handleTabChange}
              indicatorColor="primary"
              textColor="primary"
            >
              <Tab label="List View" />
              <Tab label="Calendar View" />
            </Tabs>
          </Paper>
        </Grid>
        
        {tabValue === 0 ? (
          // List View
          filteredClasses.length > 0 ? (
            filteredClasses.map(classItem => (
              <Grid item xs={12} key={classItem.id}>
                <Card>
                  <CardContent>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={8}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <SchoolIcon color="primary" sx={{ mr: 1 }} />
                          <Typography variant="h6" component="h2">
                            {classItem.title}
                          </Typography>
                        </Box>
                        
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <PersonIcon fontSize="small" sx={{ mr: 1, color: 'text.secondary' }} />
                          <Typography variant="body2" color="text.secondary">
                            {classItem.instructor}
                          </Typography>
                        </Box>
                        
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <LocationOnIcon fontSize="small" sx={{ mr: 1, color: 'text.secondary' }} />
                          <Typography variant="body2" color="text.secondary">
                            {classItem.location}
                          </Typography>
                        </Box>
                        
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <CalendarTodayIcon fontSize="small" sx={{ mr: 1, color: 'text.secondary' }} />
                          <Typography variant="body2" color="text.secondary">
                            {classItem.startDate} to {classItem.endDate}
                          </Typography>
                        </Box>
                      </Grid>
                      
                      <Grid item xs={12} sm={4}>
                        <Typography variant="subtitle2" gutterBottom>
                          Class Sessions:
                        </Typography>
                        <List dense>
                          {classItem.sessions.map((session, index) => (
                            <ListItem key={index} disableGutters>
                              <ListItemIcon sx={{ minWidth: 30 }}>
                                <AccessTimeIcon fontSize="small" color="primary" />
                              </ListItemIcon>
                              <ListItemText 
                                primary={`${getDayName(session.day)}: ${session.startTime} - ${session.endTime}`}
                                secondary={session.isOnline ? 'Online' : 'In-person'}
                              />
                            </ListItem>
                          ))}
                        </List>
                        
                        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                          <IconButton size="small" sx={{ mr: 1 }}>
                            <EditIcon fontSize="small" />
                          </IconButton>
                          <IconButton size="small" color="error">
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Box>
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>
            ))
          ) : (
            <Grid item xs={12}>
              <Paper sx={{ p: 3, textAlign: 'center' }}>
                <Typography variant="body1" color="text.secondary">
                  No classes found. Try adjusting your search or add a new class.
                </Typography>
              </Paper>
            </Grid>
          )
        ) : (
          // Calendar View
          <Grid item xs={12}>
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell width="10%">Time</TableCell>
                    <TableCell width="15%">Monday</TableCell>
                    <TableCell width="15%">Tuesday</TableCell>
                    <TableCell width="15%">Wednesday</TableCell>
                    <TableCell width="15%">Thursday</TableCell>
                    <TableCell width="15%">Friday</TableCell>
                    <TableCell width="15%">Weekend</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {['09:00 - 11:00', '11:00 - 13:00', '13:00 - 15:00', '15:00 - 17:00'].map((timeSlot) => (
                    <TableRow key={timeSlot}>
                      <TableCell>{timeSlot}</TableCell>
                      <TableCell>
                        {timeSlot === '09:00 - 11:00' && (
                          <Chip 
                            label="Calculus I" 
                            color="primary" 
                            size="small" 
                            sx={{ width: '100%' }}
                          />
                        )}
                        {timeSlot === '11:00 - 13:00' && (
                          <Chip 
                            label="World History" 
                            color="secondary" 
                            size="small" 
                            sx={{ width: '100%' }}
                          />
                        )}
                      </TableCell>
                      <TableCell>
                        {timeSlot === '09:00 - 11:00' && (
                          <Chip 
                            label="Chemistry 201" 
                            color="success" 
                            size="small" 
                            sx={{ width: '100%' }}
                          />
                        )}
                        {timeSlot === '13:00 - 15:00' && (
                          <Chip 
                            label="Physics 101" 
                            color="warning" 
                            size="small" 
                            sx={{ width: '100%' }}
                          />
                        )}
                      </TableCell>
                      <TableCell>
                        {timeSlot === '09:00 - 11:00' && (
                          <Chip 
                            label="Calculus I" 
                            color="primary" 
                            size="small" 
                            sx={{ width: '100%' }}
                          />
                        )}
                        {timeSlot === '11:00 - 13:00' && (
                          <Chip 
                            label="World History" 
                            color="secondary" 
                            size="small" 
                            sx={{ width: '100%' }}
                          />
                        )}
                      </TableCell>
                      <TableCell>
                        {timeSlot === '09:00 - 11:00' && (
                          <Chip 
                            label="Chemistry 201" 
                            color="success" 
                            size="small" 
                            sx={{ width: '100%' }}
                          />
                        )}
                        {timeSlot === '13:00 - 15:00' && (
                          <Chip 
                            label="Physics 101 (Online)" 
                            color="warning" 
                            size="small" 
                            variant="outlined"
                            sx={{ width: '100%' }}
                          />
                        )}
                      </TableCell>
                      <TableCell></TableCell>
                      <TableCell></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Grid>
        )}
      </Grid>
    </Container>
  );
};

export default Scheduler;
