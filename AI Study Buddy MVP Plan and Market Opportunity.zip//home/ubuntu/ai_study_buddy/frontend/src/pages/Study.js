import React, { useState } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Card, 
  CardContent, 
  TextField, 
  Button, 
  Tabs, 
  Tab, 
  Paper,
  IconButton,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  ListItemSecondaryAction,
  Divider,
  CardActions,
  CardMedia,
  CardHeader,
  LinearProgress
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import SchoolIcon from '@mui/icons-material/School';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import FlashOnIcon from '@mui/icons-material/FlashOn';
import SummarizeIcon from '@mui/icons-material/Summarize';
import QuizIcon from '@mui/icons-material/Quiz';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';

const Study = () => {
  const [tabValue, setTabValue] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFlashcardSet, setActiveFlashcardSet] = useState(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  
  // Mock data for demonstration
  const [flashcardSets] = useState([
    { 
      id: 1, 
      title: 'Calculus: Limits and Derivatives', 
      description: 'Key concepts and formulas for limits and derivatives',
      course: 'Calculus I',
      cardCount: 15,
      lastStudied: '2025-03-18',
      isAiGenerated: true,
      cards: [
        { front: 'What is the definition of a limit?', back: 'The value that a function approaches as the input approaches some value.' },
        { front: 'What is the derivative of f(x) = x²?', back: 'f\'(x) = 2x' },
        { front: 'What is the chain rule?', back: 'If h(x) = f(g(x)), then h\'(x) = f\'(g(x)) · g\'(x)' }
      ]
    },
    { 
      id: 2, 
      title: 'World War II: Major Events', 
      description: 'Timeline and key events of World War II',
      course: 'World History',
      cardCount: 20,
      lastStudied: '2025-03-15',
      isAiGenerated: false,
      cards: [
        { front: 'When did Germany invade Poland?', back: 'September 1, 1939' },
        { front: 'When did Japan attack Pearl Harbor?', back: 'December 7, 1941' },
        { front: 'When was D-Day?', back: 'June 6, 1944' }
      ]
    },
    { 
      id: 3, 
      title: 'Newton\'s Laws of Motion', 
      description: 'The three laws of motion formulated by Isaac Newton',
      course: 'Physics 101',
      cardCount: 10,
      lastStudied: '2025-03-20',
      isAiGenerated: true,
      cards: [
        { front: 'What is Newton\'s First Law?', back: 'An object at rest stays at rest, and an object in motion stays in motion unless acted upon by an external force.' },
        { front: 'What is Newton\'s Second Law?', back: 'F = ma. The acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass.' },
        { front: 'What is Newton\'s Third Law?', back: 'For every action, there is an equal and opposite reaction.' }
      ]
    }
  ]);

  const [summaries] = useState([
    { 
      id: 1, 
      title: 'Limits and Continuity', 
      content: 'A limit is the value that a function approaches as the input approaches some value. A function is continuous at a point if the limit exists at that point, the function is defined at that point, and the limit equals the function value.',
      course: 'Calculus I',
      date: '2025-03-18',
      isAiGenerated: true
    },
    { 
      id: 2, 
      title: 'World War II Overview', 
      content: 'World War II was a global conflict from 1939 to 1945 involving the Allies (including the US, UK, and USSR) and the Axis powers (Nazi Germany, Italy, and Japan). Major events include the German invasion of Poland, Pearl Harbor, D-Day, and the atomic bombings of Hiroshima and Nagasaki.',
      course: 'World History',
      date: '2025-03-15',
      isAiGenerated: true
    }
  ]);

  const [quizzes] = useState([
    { 
      id: 1, 
      title: 'Calculus Quiz 1', 
      description: 'Test your knowledge of limits and derivatives',
      course: 'Calculus I',
      questionCount: 10,
      timeEstimate: '15 min',
      lastTaken: null,
      isAiGenerated: true
    },
    { 
      id: 2, 
      title: 'World War II Quiz', 
      description: 'Test your knowledge of World War II events and timeline',
      course: 'World History',
      questionCount: 15,
      timeEstimate: '20 min',
      lastTaken: '2025-03-16',
      score: '80%',
      isAiGenerated: true
    }
  ]);

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const handleStartFlashcards = (flashcardSet) => {
    setActiveFlashcardSet(flashcardSet);
    setCurrentCardIndex(0);
    setShowAnswer(false);
  };

  const handleNextCard = () => {
    if (currentCardIndex < activeFlashcardSet.cards.length - 1) {
      setCurrentCardIndex(currentCardIndex + 1);
      setShowAnswer(false);
    } else {
      // End of deck
      setActiveFlashcardSet(null);
    }
  };

  const toggleShowAnswer = () => {
    setShowAnswer(!showAnswer);
  };

  const handleCloseFlashcards = () => {
    setActiveFlashcardSet(null);
  };

  // Filter items based on search query and active tab
  const getFilteredItems = () => {
    const searchLower = searchQuery.toLowerCase();
    
    if (tabValue === 0) { // Flashcards
      return flashcardSets.filter(set => 
        set.title.toLowerCase().includes(searchLower) || 
        set.description.toLowerCase().includes(searchLower) ||
        set.course.toLowerCase().includes(searchLower)
      );
    } else if (tabValue === 1) { // Summaries
      return summaries.filter(summary => 
        summary.title.toLowerCase().includes(searchLower) || 
        summary.content.toLowerCase().includes(searchLower) ||
        summary.course.toLowerCase().includes(searchLower)
      );
    } else { // Quizzes
      return quizzes.filter(quiz => 
        quiz.title.toLowerCase().includes(searchLower) || 
        quiz.description.toLowerCase().includes(searchLower) ||
        quiz.course.toLowerCase().includes(searchLower)
      );
    }
  };

  const filteredItems = getFilteredItems();

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {activeFlashcardSet ? (
        // Flashcard Study Mode
        <Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
              Studying: {activeFlashcardSet.title}
            </Typography>
            <Button 
              variant="outlined" 
              color="primary" 
              onClick={handleCloseFlashcards}
            >
              Exit
            </Button>
          </Box>
          
          <LinearProgress 
            variant="determinate" 
            value={(currentCardIndex + 1) / activeFlashcardSet.cards.length * 100} 
            sx={{ mb: 3, height: 10, borderRadius: 5 }}
          />
          
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2, textAlign: 'center' }}>
            Card {currentCardIndex + 1} of {activeFlashcardSet.cards.length}
          </Typography>
          
          <Card 
            sx={{ 
              minHeight: 300, 
              display: 'flex', 
              flexDirection: 'column', 
              justifyContent: 'center',
              alignItems: 'center',
              p: 4,
              mb: 3,
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              transform: showAnswer ? 'rotateY(180deg)' : 'rotateY(0)',
              '&:hover': {
                boxShadow: 6
              }
            }}
            onClick={toggleShowAnswer}
          >
            <CardContent sx={{ 
              width: '100%', 
              textAlign: 'center',
              transform: showAnswer ? 'rotateY(180deg)' : 'rotateY(0)',
            }}>
              {!showAnswer ? (
                <Typography variant="h5" component="div">
                  {activeFlashcardSet.cards[currentCardIndex].front}
                </Typography>
              ) : (
                <Typography variant="h5" component="div" color="primary">
                  {activeFlashcardSet.cards[currentCardIndex].back}
                </Typography>
              )}
            </CardContent>
          </Card>
          
          <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
            <Button 
              variant="outlined" 
              color="primary" 
              startIcon={showAnswer ? <VisibilityOffIcon /> : <VisibilityIcon />}
              onClick={toggleShowAnswer}
            >
              {showAnswer ? 'Hide Answer' : 'Show Answer'}
            </Button>
            <Button 
              variant="contained" 
              color="primary" 
              endIcon={<ArrowForwardIcon />}
              onClick={handleNextCard}
            >
              Next Card
            </Button>
          </Box>
        </Box>
      ) : (
        // Study Materials List
        <>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
              Study Materials
            </Typography>
            <Box>
              <Button 
                variant="outlined" 
                color="secondary" 
                startIcon={<AutoAwesomeIcon />}
                sx={{ mr: 2 }}
              >
                Generate Materials
              </Button>
              <Button 
                variant="contained" 
                color="primary" 
                startIcon={<AddIcon />}
              >
                Create New
              </Button>
            </Box>
          </Box>
          
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Paper sx={{ p: 2, mb: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <TextField
                    fullWidth
                    placeholder="Search study materials..."
                    variant="outlined"
                    size="small"
                    value={searchQuery}
                    onChange={handleSearchChange}
                    InputProps={{
                      startAdornment: <SearchIcon sx={{ color: 'text.secondary', mr: 1 }} />,
                    }}
                    sx={{ mr: 2 }}
                  />
                  <IconButton>
                    <FilterListIcon />
                  </IconButton>
                </Box>
                
                <Tabs 
                  value={tabValue} 
                  onChange={handleTabChange}
                  indicatorColor="primary"
                  textColor="primary"
                >
                  <Tab icon={<FlashOnIcon />} label="Flashcards" />
                  <Tab icon={<SummarizeIcon />} label="Summaries" />
                  <Tab icon={<QuizIcon />} label="Quizzes" />
                </Tabs>
              </Paper>
            </Grid>
            
            {filteredItems.length > 0 ? (
              <>
                {tabValue === 0 && (
                  // Flashcards
                  filteredItems.map(flashcardSet => (
                    <Grid item xs={12} sm={6} md={4} key={flashcardSet.id}>
                      <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                        <CardHeader
                          avatar={<FlashOnIcon color="primary" />}
                          title={flashcardSet.title}
                          subheader={flashcardSet.course}
                          action={
                            flashcardSet.isAiGenerated && (
                              <Chip 
                                size="small" 
                                icon={<AutoAwesomeIcon />} 
                                label="AI Generated" 
                                color="secondary" 
                                variant="outlined"
                              />
                            )
                          }
                        />
                        <CardContent sx={{ flexGrow: 1 }}>
                          <Typography variant="body2" color="text.secondary" paragraph>
                            {flashcardSet.description}
                          </Typography>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                            <Typography variant="body2">
                              Cards: {flashcardSet.cardCount}
                            </Typography>
                            {flashcardSet.lastStudied && (
                              <Typography variant="body2" color="text.secondary">
                                Last studied: {flashcardSet.lastStudied}
                              </Typography>
                            )}
                          </Box>
                        </CardContent>
                        <CardActions>
                          <Button 
                            size="small" 
                            color="primary"
                            onClick={() => handleStartFlashcards(flashcardSet)}
                          >
                            Study
                          </Button>
                          <Button size="small">Edit</Button>
                          <IconButton size="small" color="error" sx={{ ml: 'auto' }}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </CardActions>
                      </Card>
                    </Grid>
                  ))
                )}
                
                {tabValue === 1 && (
                  // Summaries
                  filteredItems.map(summary => (
                    <Grid item xs={12} key={summary.id}>
                      <Card>
                        <CardContent>
                          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                              <SummarizeIcon color="primary" sx={{ mr: 1 }} />
                              <Typography variant="h6" component="h2">
                                {summary.title}
                              </Typography>
                            </Box>
                            <Box>
                              {summary.isAiGenerated && (
                                <Chip 
                                  size="small" 
                                  icon={<AutoAwesomeIcon />} 
                                  label="AI Generated" 
                                  color="secondary" 
                                  variant="outlined"
                                />
                              )}
                            </Box>
                          </Box>
                          
                          <Typography variant="body2" color="text.secondary" sx={{ mt: 1, mb: 2 }}>
                            {summary.course} • {summary.date}
                          </Typography>
                          
                          <Typography variant="body1" paragraph>
                            {summa<response clipped><NOTE>To save on context only part of this file has been shown to you. You should retry this tool after you have searched inside the file with `grep -n` in order to find the line numbers of what you are looking for.</NOTE>