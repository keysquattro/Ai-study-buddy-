"""
Configuration settings for the AI Study Buddy application.
"""
import os
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()

class Config:
    """Base configuration."""
    # Application settings
    APP_NAME = "AI Study Buddy"
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-key-change-in-production")
    DEBUG = False
    TESTING = False
    
    # Database settings
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL", "sqlite:///app.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # API keys
    OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
    GOOGLE_CLOUD_API_KEY = os.environ.get("GOOGLE_CLOUD_API_KEY")
    
    # Redis settings (for Celery)
    REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
    
    # File storage
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "uploads")
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max upload size
    
    # Session settings
    SESSION_TYPE = "redis"
    SESSION_PERMANENT = False
    SESSION_USE_SIGNER = True
    SESSION_REDIS = None  # Will be set in app initialization
    
    # Feature flags
    ENABLE_NOTE_TAKING = True
    ENABLE_HOMEWORK_ASSISTANT = True
    ENABLE_SMART_REMINDERS = True
    ENABLE_CLASS_SCHEDULER = True
    ENABLE_STUDY_MODE = True


class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL", "sqlite:///dev.db")


class TestingConfig(Config):
    """Testing configuration."""
    TESTING = True
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


class ProductionConfig(Config):
    """Production configuration."""
    # Ensure all required environment variables are set
    @classmethod
    def init_app(cls, app):
        assert os.environ.get("SECRET_KEY"), "SECRET_KEY environment variable is not set"
        assert os.environ.get("DATABASE_URL"), "DATABASE_URL environment variable is not set"
        assert os.environ.get("OPENAI_API_KEY"), "OPENAI_API_KEY environment variable is not set"


# Configuration dictionary
config = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig
}
