"""
Assignment model for the AI Study Buddy application.
"""
from datetime import datetime
from app import db

class Assignment(db.Model):
    """Assignment model for storing homework assignments."""
    
    __tablename__ = 'assignments'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    due_date = db.Column(db.DateTime, nullable=False)
    priority = db.Column(db.Integer, default=2)  # 1=Low, 2=Medium, 3=High
    status = db.Column(db.String(20), default='Not Started')  # Not Started, In Progress, Completed
    completion_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=True)
    
    # Relationships
    files = db.relationship('AssignmentFile', backref='assignment', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<Assignment {self.title}>'


class AssignmentFile(db.Model):
    """Model for files attached to assignments."""
    
    __tablename__ = 'assignment_files'
    
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    file_type = db.Column(db.String(50))
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign keys
    assignment_id = db.Column(db.Integer, db.ForeignKey('assignments.id'), nullable=False)
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<AssignmentFile {self.filename}>'
