"""
Note model for the AI Study Buddy application.
"""
from datetime import datetime
from app import db

class Note(db.Model):
    """Note model for storing user notes."""
    
    __tablename__ = 'notes'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    source_type = db.Column(db.String(50))  # lecture, reading, etc.
    source_reference = db.Column(db.String(200))  # file name, URL, etc.
    is_ai_generated = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=True)
    
    # Relationships
    tags = db.relationship('NoteTag', backref='note', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<Note {self.title}>'


class NoteTag(db.Model):
    """Model for note tags to categorize notes."""
    
    __tablename__ = 'note_tags'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    
    # Foreign keys
    note_id = db.Column(db.Integer, db.ForeignKey('notes.id'), nullable=False)
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<NoteTag {self.name}>'


class Course(db.Model):
    """Course model for organizing notes and assignments."""
    
    __tablename__ = 'courses'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    code = db.Column(db.String(20))
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Relationships
    notes = db.relationship('Note', backref='course', lazy='dynamic')
    assignments = db.relationship('Assignment', backref='course', lazy='dynamic')
    classes = db.relationship('Class', backref='course', lazy='dynamic')
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<Course {self.name}>'
