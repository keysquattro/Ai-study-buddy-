"""
Reminder model for the AI Study Buddy application.
"""
from datetime import datetime
from app import db

class Reminder(db.Model):
    """Reminder model for storing user reminders and deadlines."""
    
    __tablename__ = 'reminders'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    reminder_date = db.Column(db.DateTime, nullable=False)
    is_recurring = db.Column(db.Boolean, default=False)
    recurrence_pattern = db.Column(db.String(50))  # daily, weekly, monthly, etc.
    priority = db.Column(db.Integer, default=2)  # 1=Low, 2=Medium, 3=High
    status = db.Column(db.String(20), default='Active')  # Active, Completed, Snoozed
    is_ai_suggested = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    assignment_id = db.Column(db.Integer, db.ForeignKey('assignments.id'), nullable=True)
    class_id = db.Column(db.Integer, db.ForeignKey('classes.id'), nullable=True)
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<Reminder {self.title}>'


class Notification(db.Model):
    """Notification model for storing reminder notifications."""
    
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.String(255), nullable=False)
    notification_type = db.Column(db.String(50))  # email, push, in-app
    is_read = db.Column(db.Boolean, default=False)
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    reminder_id = db.Column(db.Integer, db.ForeignKey('reminders.id'), nullable=True)
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<Notification {self.id}>'
