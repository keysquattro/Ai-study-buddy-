"""
Class scheduler models for the AI Study Buddy application.
"""
from datetime import datetime, time
from app import db

class Class(db.Model):
    """Class model for storing scheduled classes."""
    
    __tablename__ = 'classes'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(100))
    instructor = db.Column(db.String(100))
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=True)
    
    # Relationships
    sessions = db.relationship('ClassSession', backref='class', lazy='dynamic', cascade='all, delete-orphan')
    reminders = db.relationship('Reminder', backref='class', lazy='dynamic')
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<Class {self.title}>'


class ClassSession(db.Model):
    """Model for individual class sessions (recurring meetings)."""
    
    __tablename__ = 'class_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    day_of_week = db.Column(db.Integer, nullable=False)  # 0=Monday, 1=Tuesday, etc.
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    is_online = db.Column(db.Boolean, default=False)
    meeting_link = db.Column(db.String(255))
    
    # Foreign keys
    class_id = db.Column(db.Integer, db.ForeignKey('classes.id'), nullable=False)
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<ClassSession {self.day_of_week} {self.start_time}-{self.end_time}>'


class CalendarEvent(db.Model):
    """Model for one-time calendar events."""
    
    __tablename__ = 'calendar_events'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    start_datetime = db.Column(db.DateTime, nullable=False)
    end_datetime = db.Column(db.DateTime, nullable=False)
    location = db.Column(db.String(100))
    is_all_day = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<CalendarEvent {self.title}>'
