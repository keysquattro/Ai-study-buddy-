"""
Study mode and flashcard models for the AI Study Buddy application.
"""
from datetime import datetime
from app import db

class FlashcardSet(db.Model):
    """Model for sets of flashcards."""
    
    __tablename__ = 'flashcard_sets'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    is_ai_generated = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=True)
    
    # Relationships
    flashcards = db.relationship('Flashcard', backref='flashcard_set', lazy='dynamic', cascade='all, delete-orphan')
    study_sessions = db.relationship('StudySession', backref='flashcard_set', lazy='dynamic')
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<FlashcardSet {self.title}>'


class Flashcard(db.Model):
    """Model for individual flashcards."""
    
    __tablename__ = 'flashcards'
    
    id = db.Column(db.Integer, primary_key=True)
    front_content = db.Column(db.Text, nullable=False)
    back_content = db.Column(db.Text, nullable=False)
    difficulty = db.Column(db.Integer, default=2)  # 1=Easy, 2=Medium, 3=Hard
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign keys
    flashcard_set_id = db.Column(db.Integer, db.ForeignKey('flashcard_sets.id'), nullable=False)
    
    # Relationships
    study_records = db.relationship('FlashcardStudyRecord', backref='flashcard', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<Flashcard {self.id}>'


class StudySession(db.Model):
    """Model for tracking study sessions."""
    
    __tablename__ = 'study_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime)
    duration_minutes = db.Column(db.Integer)
    cards_studied = db.Column(db.Integer, default=0)
    correct_answers = db.Column(db.Integer, default=0)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    flashcard_set_id = db.Column(db.Integer, db.ForeignKey('flashcard_sets.id'), nullable=False)
    
    # Relationships
    study_records = db.relationship('FlashcardStudyRecord', backref='study_session', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<StudySession {self.id}>'


class FlashcardStudyRecord(db.Model):
    """Model for tracking individual flashcard study results."""
    
    __tablename__ = 'flashcard_study_records'
    
    id = db.Column(db.Integer, primary_key=True)
    is_correct = db.Column(db.Boolean)
    confidence_level = db.Column(db.Integer)  # 1-5 scale
    time_spent_seconds = db.Column(db.Integer)
    next_review_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign keys
    flashcard_id = db.Column(db.Integer, db.ForeignKey('flashcards.id'), nullable=False)
    study_session_id = db.Column(db.Integer, db.ForeignKey('study_sessions.id'), nullable=False)
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<FlashcardStudyRecord {self.id}>'


class StudySummary(db.Model):
    """Model for AI-generated study summaries."""
    
    __tablename__ = 'study_summaries'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    source_type = db.Column(db.String(50))  # notes, textbook, etc.
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=True)
    note_id = db.Column(db.Integer, db.ForeignKey('notes.id'), nullable=True)
    
    def __repr__(self):
        """Represent instance as a string."""
        return f'<StudySummary {self.title}>'
