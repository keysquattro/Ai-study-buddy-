"""
API routes for the AI Study Buddy application.
"""
from flask import Blueprint

from src.controllers.note_controller import NoteController
from src.controllers.homework_controller import HomeworkController
from src.controllers.reminder_controller import ReminderController
from src.controllers.scheduler_controller import SchedulerController
from src.controllers.study_controller import StudyController

# Initialize controllers
note_controller = NoteController()
homework_controller = HomeworkController()
reminder_controller = ReminderController()
scheduler_controller = SchedulerController()
study_controller = StudyController()

# Create blueprints
notes_bp = Blueprint('notes', __name__)
homework_bp = Blueprint('homework', __name__)
reminders_bp = Blueprint('reminders', __name__)
scheduler_bp = Blueprint('scheduler', __name__)
study_bp = Blueprint('study', __name__)

# Notes routes
notes_bp.route('/', methods=['GET'])(note_controller.get_notes)
notes_bp.route('/<int:note_id>', methods=['GET'])(note_controller.get_note)
notes_bp.route('/', methods=['POST'])(note_controller.create_note)
notes_bp.route('/<int:note_id>', methods=['PUT'])(note_controller.update_note)
notes_bp.route('/<int:note_id>', methods=['DELETE'])(note_controller.delete_note)
notes_bp.route('/generate', methods=['POST'])(note_controller.generate_notes)

# Homework routes
homework_bp.route('/', methods=['GET'])(homework_controller.get_assignments)
homework_bp.route('/<int:assignment_id>', methods=['GET'])(homework_controller.get_assignment)
homework_bp.route('/', methods=['POST'])(homework_controller.create_assignment)
homework_bp.route('/<int:assignment_id>', methods=['PUT'])(homework_controller.update_assignment)
homework_bp.route('/<int:assignment_id>', methods=['DELETE'])(homework_controller.delete_assignment)
homework_bp.route('/assist', methods=['POST'])(homework_controller.get_assistance)
homework_bp.route('/format', methods=['POST'])(homework_controller.format_report)
homework_bp.route('/citations', methods=['POST'])(homework_controller.generate_citations)
homework_bp.route('/grammar', methods=['POST'])(homework_controller.check_grammar_style)
homework_bp.route('/<int:assignment_id>/files', methods=['POST'])(homework_controller.upload_assignment_file)

# Reminders routes
reminders_bp.route('/', methods=['GET'])(reminder_controller.get_reminders)
reminders_bp.route('/<int:reminder_id>', methods=['GET'])(reminder_controller.get_reminder)
reminders_bp.route('/', methods=['POST'])(reminder_controller.create_reminder)
reminders_bp.route('/<int:reminder_id>', methods=['PUT'])(reminder_controller.update_reminder)
reminders_bp.route('/<int:reminder_id>', methods=['DELETE'])(reminder_controller.delete_reminder)
reminders_bp.route('/upcoming', methods=['GET'])(reminder_controller.get_upcoming_reminders)
reminders_bp.route('/suggest', methods=['POST'])(reminder_controller.suggest_reminders)
reminders_bp.route('/prioritize', methods=['POST'])(reminder_controller.prioritize_tasks)
reminders_bp.route('/study-schedule', methods=['POST'])(reminder_controller.generate_study_schedule)

# Scheduler routes
scheduler_bp.route('/classes', methods=['GET'])(scheduler_controller.get_classes)
scheduler_bp.route('/classes/<int:class_id>', methods=['GET'])(scheduler_controller.get_class)
scheduler_bp.route('/classes', methods=['POST'])(scheduler_controller.create_class)
scheduler_bp.route('/classes/<int:class_id>', methods=['PUT'])(scheduler_controller.update_class)
scheduler_bp.route('/classes/<int:class_id>', methods=['DELETE'])(scheduler_controller.delete_class)
scheduler_bp.route('/calendar', methods=['GET'])(scheduler_controller.get_calendar)
scheduler_bp.route('/import', methods=['POST'])(scheduler_controller.import_schedule)
scheduler_bp.route('/conflicts', methods=['GET'])(scheduler_controller.check_conflicts)
scheduler_bp.route('/optimize', methods=['POST'])(scheduler_controller.optimize_schedule)

# Study routes
study_bp.route('/flashcards', methods=['GET'])(study_controller.get_flashcard_sets)
study_bp.route('/flashcards/<int:set_id>', methods=['GET'])(study_controller.get_flashcard_set)
study_bp.route('/flashcards', methods=['POST'])(study_controller.create_flashcard_set)
study_bp.route('/flashcards/<int:set_id>', methods=['PUT'])(study_controller.update_flashcard_set)
study_bp.route('/flashcards/<int:set_id>', methods=['DELETE'])(study_controller.delete_flashcard_set)
study_bp.route('/generate/summary', methods=['POST'])(study_controller.generate_summary)
study_bp.route('/generate/flashcards', methods=['POST'])(study_controller.generate_flashcards)
study_bp.route('/generate/quiz', methods=['POST'])(study_controller.generate_quiz)
study_bp.route('/sessions', methods=['POST'])(study_controller.record_study_session)
study_bp.route('/progress', methods=['GET'])(study_controller.get_study_progress)
