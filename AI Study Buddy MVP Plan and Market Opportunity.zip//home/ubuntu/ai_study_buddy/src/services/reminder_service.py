"""
AI service for smart reminders functionality in the AI Study Buddy application.
"""
import os
import openai
from datetime import datetime, timedelta
from flask import current_app

class ReminderService:
    """Service for AI-powered reminder features."""
    
    def __init__(self):
        """Initialize the reminder service with API key."""
        self.api_key = os.environ.get("OPENAI_API_KEY")
        openai.api_key = self.api_key
    
    def suggest_reminders(self, user_data):
        """
        Suggest reminders based on user's schedule and assignments.
        
        Args:
            user_data (dict): Dictionary containing user's classes, assignments, and existing reminders.
            
        Returns:
            list: A list of suggested reminders.
        """
        try:
            # Extract relevant data
            assignments = user_data.get('assignments', [])
            classes = user_data.get('classes', [])
            existing_reminders = user_data.get('reminders', [])
            
            # Create a prompt for the OpenAI API
            prompt = self._create_reminder_suggestion_prompt(assignments, classes, existing_reminders)
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an AI study assistant that helps students manage their time effectively. Suggest smart reminders based on their schedule and assignments."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000,
                temperature=0.5
            )
            
            # Extract the suggested reminders
            suggestions_text = response.choices[0].message.content
            
            # Parse the suggestions into a structured format
            suggested_reminders = self._parse_reminder_suggestions(suggestions_text)
            
            return suggested_reminders
            
        except Exception as e:
            current_app.logger.error(f"Error suggesting reminders: {str(e)}")
            return []
    
    def prioritize_tasks(self, tasks):
        """
        Prioritize tasks based on deadlines, importance, and estimated effort.
        
        Args:
            tasks (list): List of task dictionaries with title, due_date, and description.
            
        Returns:
            list: A list of prioritized tasks with priority levels.
        """
        try:
            # Create a prompt for the OpenAI API
            tasks_text = "\n".join([f"Task: {task['title']}\nDue Date: {task['due_date']}\nDescription: {task['description']}" 
                                   for task in tasks])
            
            prompt = f"""
            Prioritize the following tasks based on deadlines, importance, and estimated effort.
            Assign a priority level (High, Medium, Low) to each task and explain the reasoning.
            
            Today's date: {datetime.now().strftime('%Y-%m-%d')}
            
            {tasks_text}
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a productivity assistant that helps students prioritize their tasks effectively."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000,
                temperature=0.3
            )
            
            # Extract the prioritized tasks
            prioritization_text = response.choices[0].message.content
            
            # Parse the prioritization into a structured format
            prioritized_tasks = []
            current_task = None
            
            for line in prioritization_text.split('\n'):
                line = line.strip()
                if line.startswith('Task:') or line.startswith('- Task:'):
                    if current_task:
                        prioritized_tasks.append(current_task)
                    task_name = line.split(':', 1)[1].strip()
                    current_task = {'title': task_name}
                elif line.startswith('Priority:') or line.startswith('- Priority:'):
                    if current_task:
                        priority = line.split(':', 1)[1].strip()
                        if 'high' in priority.lower():
                            current_task['priority'] = 3
                        elif 'medium' in priority.lower():
                            current_task['priority'] = 2
                        else:
                            current_task['priority'] = 1
                elif line.startswith('Reasoning:') or line.startswith('- Reasoning:'):
                    if current_task:
                        current_task['reasoning'] = line.split(':', 1)[1].strip()
            
            if current_task:
                prioritized_tasks.append(current_task)
            
            # Match prioritized tasks back to original tasks
            for pt in prioritized_tasks:
                for original_task in tasks:
                    if pt['title'].lower() in original_task['title'].lower():
                        pt.update({k: v for k, v in original_task.items() if k not in pt})
            
            return prioritized_tasks
            
        except Exception as e:
            current_app.logger.error(f"Error prioritizing tasks: {str(e)}")
            return tasks
    
    def generate_study_schedule(self, assignments, classes, preferences):
        """
        Generate an optimal study schedule based on assignments, classes, and preferences.
        
        Args:
            assignments (list): List of assignment dictionaries.
            classes (list): List of class dictionaries.
            preferences (dict): User preferences for study times.
            
        Returns:
            dict: A dictionary containing the generated study schedule.
        """
        try:
            # Create a prompt for the OpenAI API
            assignments_text = "\n".join([f"Assignment: {a['title']}\nDue Date: {a['due_date']}\nEstimated Hours: {a.get('estimated_hours', 'Unknown')}" 
                                        for a in assignments])
            
            classes_text = "\n".join([f"Class: {c['title']}\nSchedule: {c.get('schedule', 'Unknown')}" 
                                     for c in classes])
            
            preferences_text = f"""
            Preferred Study Times: {preferences.get('preferred_times', 'Flexible')}
            Study Session Duration: {preferences.get('session_duration', '1-2 hours')}
            Breaks: {preferences.get('breaks', '15 minutes per hour')}
            """
            
            prompt = f"""
            Generate an optimal study schedule for the next 7 days based on the following information:
            
            Today's date: {datetime.now().strftime('%Y-%m-%d')}
            
            ASSIGNMENTS:
            {assignments_text}
            
            CLASSES:
            {classes_text}
            
            PREFERENCES:
            {preferences_text}
            
            Please create a day-by-day schedule that allocates appropriate study time for each assignment,
            avoids conflicts with classes, and respects the student's preferences.
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a study planning assistant that helps students create optimal study schedules."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1500,
                temperature=0.5
            )
            
            # Extract the generated schedule
            schedule_text = response.choices[0].message.content
            
            return {
                "schedule_text": schedule_text,
                "generated_date": datetime.now().strftime('%Y-%m-%d'),
                "days_covered": 7
            }
            
        except Exception as e:
            current_app.logger.error(f"Error generating study schedule: {str(e)}")
            return {
                "schedule_text": f"An error occurred while generating study schedule: {str(e)}",
                "generated_date": datetime.now().strftime('%Y-%m-%d'),
                "days_covered": 0
            }
    
    def _create_reminder_suggestion_prompt(self, assignments, classes, existing_reminders):
        """
        Create a prompt for the OpenAI API to suggest reminders.
        
        Args:
            assignments (list): List of assignment dictionaries.
            classes (list): List of class dictionaries.
            existing_reminders (list): List of existing reminder dictionaries.
            
        Returns:
            str: The prompt for the OpenAI API.
        """
        today = datetime.now()
        
        assignments_text = ""
        for a in assignments:
            due_date = a.get('due_date', 'Unknown')
            if isinstance(due_date, str):
                due_date_str = due_date
            else:
                due_date_str = due_date.strftime('%Y-%m-%d')
            
            assignments_text += f"- {a.get('title', 'Untitled Assignment')} (Due: {due_date_str})\n"
        
        classes_text = ""
        for c in classes:
            classes_text += f"- {c.get('title', 'Untitled Class')}\n"
            if 'sessions' in c:
                for s in c['sessions']:
                    day = s.get('day_of_week', 'Unknown')
                    start = s.get('start_time', 'Unknown')
                    end = s.get('end_time', 'Unknown')
                    classes_text += f"  - {day}: {start} - {end}\n"
        
        reminders_text = ""
        for r in existing_reminders:
            reminder_date = r.get('reminder_date', 'Unknown')
            if isinstance(reminder_date, str):
                reminder_date_str = reminder_date
            else:
                reminder_date_str = reminder_date.strftime('%Y-%m-%d')
            
            reminders_text += f"- {r.get('title', 'Untitled Reminder')} (Date: {reminder_date_str})\n"
        
        prompt = f"""
        Based on the following information, suggest smart reminders for a student:
        
        Today's date: {today.strftime('%Y-%m-%d')}
        
        ASSIGNMENTS:
        {assignments_text or "No assignments provided."}
        
        CLASSES:
        {classes_text or "No classes provided."}
        
        EXISTING REMINDERS:
        {reminders_text or "No existing reminders."}
        
        Please suggest 3-5 helpful reminders that would help the student stay on track with their assignments and classes.
        For each reminder, include:
        1. A clear title
        2. A suggested date and time
        3. A brief description of why this reminder is important
        
        Format each reminder as:
        REMINDER: [Title]
        DATE: [YYYY-MM-DD]
        TIME: [HH:MM]
        DESCRIPTION: [Brief description]
        """
        
        return prompt
    
    def _parse_reminder_suggestions(self, suggestions_text):
        """
        Parse the reminder suggestions from the OpenAI API response.
        
        Args:
            suggestions_text (str): The text containing reminder suggestions.
            
        Returns:
            list: A list of reminder dictionaries.
        """
        reminders = []
        current_reminder = None
        
        for line in suggestions_text.split('\n'):
            line = line.strip()
            if not line:
                continue
                
            if line.startswith('REMINDER:'):
                if current_reminder:
                    reminders.append(current_reminder)
                current_reminder = {'title': line.split(':', 1)[1].strip(), 'is_ai_suggested': True}
            elif line.startswith('DATE:') and current_reminder:
                date_str = line.split(':', 1)[1].strip()
                try:
                    # Parse the date string
                    reminder_date = datetime.strptime(date_str, '%Y-%m-%d')
                    current_reminder['reminder_date'] = reminder_date
                except ValueError:
                    current_reminder['reminder_date'] = datetime.now() + timedelta(days=1)
            elif line.startswith('TIME:') and current_reminder:
                time_str = line.split(':', 1)[1].strip()
                if 'reminder_date' in current_reminder:
                    try:
                        # Parse the time string and combine with date
                        time_parts = time_str.split(':')
                        hour = int(time_parts[0])
                        minute = int(time_parts[1]) if len(time_parts) > 1 else 0
                        
                        reminder_date = current_reminder['reminder_date']
                        reminder_datetime = reminder_date.replace(hour=hour, minute=minute)
                        
                        current_reminder['reminder_date'] = reminder_datetime
                    except (ValueError, IndexError):
                        pass
            elif line.startswith('DESCRIPTION:') and current_reminder:
                current_reminder['description'] = line.split(':', 1)[1].strip()
        
        if current_reminder:
            reminders.append(current_reminder)
        
        return reminders
