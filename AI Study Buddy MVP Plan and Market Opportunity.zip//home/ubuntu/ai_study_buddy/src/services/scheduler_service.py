"""
AI service for class scheduler functionality in the AI Study Buddy application.
"""
import os
import openai
from datetime import datetime, timedelta
from flask import current_app

class SchedulerService:
    """Service for AI-powered class scheduling features."""
    
    def __init__(self):
        """Initialize the scheduler service with API key."""
        self.api_key = os.environ.get("OPENAI_API_KEY")
        openai.api_key = self.api_key
    
    def detect_conflicts(self, classes, events):
        """
        Detect scheduling conflicts between classes and events.
        
        Args:
            classes (list): List of class dictionaries with sessions.
            events (list): List of event dictionaries.
            
        Returns:
            list: A list of detected conflicts.
        """
        try:
            # Create a text representation of classes and events
            classes_text = self._format_classes_for_prompt(classes)
            events_text = self._format_events_for_prompt(events)
            
            # Create a prompt for the OpenAI API
            prompt = f"""
            Analyze the following class schedule and events to identify any scheduling conflicts:
            
            CLASSES:
            {classes_text}
            
            EVENTS:
            {events_text}
            
            Please identify any scheduling conflicts where two or more activities overlap in time.
            For each conflict, specify:
            1. The conflicting activities
            2. The date and time of the conflict
            3. The duration of the overlap
            4. Suggestions for resolving the conflict
            
            Format each conflict as:
            CONFLICT: [Brief description]
            DATE: [YYYY-MM-DD]
            TIME: [HH:MM - HH:MM]
            ACTIVITIES: [List of conflicting activities]
            OVERLAP: [Duration in minutes]
            SUGGESTION: [Suggestion for resolution]
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a scheduling assistant that helps students identify and resolve scheduling conflicts."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000,
                temperature=0.3
            )
            
            # Extract the detected conflicts
            conflicts_text = response.choices[0].message.content
            
            # Parse the conflicts into a structured format
            conflicts = self._parse_conflicts(conflicts_text)
            
            return conflicts
            
        except Exception as e:
            current_app.logger.error(f"Error detecting conflicts: {str(e)}")
            return []
    
    def optimize_schedule(self, classes, preferences):
        """
        Optimize class schedule based on user preferences.
        
        Args:
            classes (list): List of potential class dictionaries with multiple options.
            preferences (dict): User preferences for scheduling.
            
        Returns:
            dict: A dictionary containing the optimized schedule.
        """
        try:
            # Create a text representation of classes
            classes_text = self._format_classes_for_prompt(classes)
            
            # Create a text representation of preferences
            preferences_text = "\n".join([f"{k}: {v}" for k, v in preferences.items()])
            
            # Create a prompt for the OpenAI API
            prompt = f"""
            Optimize the following class schedule based on the student's preferences:
            
            POTENTIAL CLASSES (multiple options available):
            {classes_text}
            
            STUDENT PREFERENCES:
            {preferences_text}
            
            Please create an optimized class schedule that:
            1. Avoids time conflicts
            2. Respects the student's preferences
            3. Creates a balanced weekly schedule
            4. Minimizes back-to-back classes when possible
            5. Allows for adequate study and break time
            
            For each class, select the best option and explain why it was chosen.
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a scheduling assistant that helps students optimize their class schedules."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1500,
                temperature=0.5
            )
            
            # Extract the optimized schedule
            schedule_text = response.choices[0].message.content
            
            return {
                "optimized_schedule": schedule_text,
                "generated_date": datetime.now().strftime('%Y-%m-%d')
            }
            
        except Exception as e:
            current_app.logger.error(f"Error optimizing schedule: {str(e)}")
            return {
                "optimized_schedule": f"An error occurred while optimizing schedule: {str(e)}",
                "generated_date": datetime.now().strftime('%Y-%m-%d')
            }
    
    def parse_imported_schedule(self, schedule_text, format_type="ical"):
        """
        Parse imported schedule text into structured class data.
        
        Args:
            schedule_text (str): The imported schedule text.
            format_type (str): The format of the imported schedule (ical, csv, etc.).
            
        Returns:
            list: A list of parsed class dictionaries.
        """
        try:
            # Create a prompt for the OpenAI API
            prompt = f"""
            Parse the following {format_type} schedule data into a structured format:
            
            {schedule_text[:2000]}  # Limit to first 2000 chars for API limits
            
            Extract the following information for each class or event:
            1. Title/Name
            2. Location
            3. Instructor (if available)
            4. Day(s) of week
            5. Start time
            6. End time
            7. Start date
            8. End date
            
            Format each class as:
            CLASS: [Title]
            LOCATION: [Location]
            INSTRUCTOR: [Instructor]
            DAYS: [Days of week]
            TIME: [Start time - End time]
            DATES: [Start date - End date]
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a data parsing assistant that extracts structured information from schedule data."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1500,
                temperature=0.3
            )
            
            # Extract the parsed schedule
            parsed_text = response.choices[0].message.content
            
            # Convert the parsed text to structured data
            parsed_classes = self._parse_classes_from_text(parsed_text)
            
            return parsed_classes
            
        except Exception as e:
            current_app.logger.error(f"Error parsing imported schedule: {str(e)}")
            return []
    
    def _format_classes_for_prompt(self, classes):
        """
        Format classes into a text representation for the prompt.
        
        Args:
            classes (list): List of class dictionaries.
            
        Returns:
            str: Formatted text representation of classes.
        """
        formatted_text = ""
        
        for i, cls in enumerate(classes):
            formatted_text += f"Class {i+1}: {cls.get('title', 'Untitled Class')}\n"
            
            if 'location' in cls:
                formatted_text += f"Location: {cls['location']}\n"
                
            if 'instructor' in cls:
                formatted_text += f"Instructor: {cls['instructor']}\n"
            
            if 'sessions' in cls:
                formatted_text += "Sessions:\n"
                for session in cls['sessions']:
                    day = session.get('day_of_week', 'Unknown')
                    start = session.get('start_time', 'Unknown')
                    end = session.get('end_time', 'Unknown')
                    formatted_text += f"  - {day}: {start} - {end}\n"
            
            formatted_text += "\n"
        
        return formatted_text
    
    def _format_events_for_prompt(self, events):
        """
        Format events into a text representation for the prompt.
        
        Args:
            events (list): List of event dictionaries.
            
        Returns:
            str: Formatted text representation of events.
        """
        formatted_text = ""
        
        for i, event in enumerate(events):
            formatted_text += f"Event {i+1}: {event.get('title', 'Untitled Event')}\n"
            
            if 'location' in event:
                formatted_text += f"Location: {event['location']}\n"
            
            if 'start_datetime' in event:
                start = event['start_datetime']
                if isinstance(start, datetime):
                    start_str = start.strftime('%Y-%m-%d %H:%M')
                else:
                    start_str = str(start)
                formatted_text += f"Start: {start_str}\n"
            
            if 'end_datetime' in event:
                end = event['end_datetime']
                if isinstance(end, datetime):
                    end_str = end.strftime('%Y-%m-%d %H:%M')
                else:
                    end_str = str(end)
                formatted_text += f"End: {end_str}\n"
            
            formatted_text += "\n"
        
        return formatted_text
    
    def _parse_conflicts(self, conflicts_text):
        """
        Parse the conflicts text into a structured format.
        
        Args:
            conflicts_text (str): The text containing conflict information.
            
        Returns:
            list: A list of conflict dictionaries.
        """
        conflicts = []
        current_conflict = None
        
        for line in conflicts_text.split('\n'):
            line = line.strip()
            if not line:
                continue
                
            if line.startswith('CONFLICT:'):
                if current_conflict:
                    conflicts.append(current_conflict)
                current_conflict = {'description': line.split(':', 1)[1].strip()}
            elif line.startswith('DATE:') and current_conflict:
                current_conflict['date'] = line.split(':', 1)[1].strip()
            elif line.startswith('TIME:') and current_conflict:
                current_conflict['time'] = line.split(':', 1)[1].strip()
            elif line.startswith('ACTIVITIES:') and current_conflict:
                current_conflict['activities'] = line.split(':', 1)[1].strip()
            elif line.startswith('OVERLAP:') and current_conflict:
                current_conflict['overlap'] = line.split(':', 1)[1].strip()
            elif line.startswith('SUGGESTION:') and current_conflict:
                current_conflict['suggestion'] = line.split(':', 1)[1].strip()
        
        if current_conflict:
            conflicts.append(current_conflict)
        
        return conflicts
    
    def _parse_classes_from_text(self, parsed_text):
        """
        Parse the class text into a structured format.
        
        Args:
            parsed_text (str): The text containing parsed class information.
            
        Returns:
            list: A list of class dictionaries.
        """
        classes = []
        current_class = None
        
        for line in parsed_text.split('\n'):
            line = line.strip()
            if not line:
                continue
                
            if line.startswith('CLASS:'):
                if current_class:
                    classes.append(current_class)
                current_class = {'title': line.split(':', 1)[1].strip()}
            elif line.startswith('LOCATION:') and current_class:
                current_class['location'] = line.split(':', 1)[1].strip()
            elif line.startswith('INSTRUCTOR:') and current_class:
                current_class['instructor'] = line.split(':', 1)[1].strip()
            elif line.startswith('DAYS:') and current_class:
                current_class['days'] = line.split(':', 1)[1].strip()
            elif line.startswith('TIME:') and current_class:
                time_str = line.split(':', 1)[1].strip()
                if '-' in time_str:
                    start_time, end_time = time_str.split('-', 1)
                    current_class['start_time'] = start_time.strip()
                    current_class['end_time'] = end_time.strip()
            elif line.startswith('DATES:') and current_class:
                dates_str = line.split(':', 1)[1].strip()
                if '-' in dates_str:
                    start_date, end_date = dates_str.split('-', 1)
                    current_class['start_date'] = start_date.strip()
                    current_class['end_date'] = end_date.strip()
        
        if current_class:
            classes.append(current_class)
        
        # Convert to proper session format
        for cls in classes:
            if 'days' in cls and 'start_time' in cls and 'end_time' in cls:
                days = cls['days'].split(',')
                sessions = []
                
                for day in days:
                    day = day.strip()
                    sessions.append({
                        'day_of_week': day,
                        'start_time': cls['start_time'],
                        'end_time': cls['end_time']
                    })
                
                cls['sessions'] = sessions
                
                # Remove the individual fields
                for field in ['days', 'start_time', 'end_time']:
                    if field in cls:
                        del cls[field]
        
        return classes
