import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add the project root to the path so we can import our modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.services.homework_service import HomeworkService

class TestHomeworkService(unittest.TestCase):
    def setUp(self):
        self.homework_service = HomeworkService()
        
    @patch('src.services.homework_service.openai')
    def test_generate_step_by_step_explanation(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        # Step-by-Step Solution: Quadratic Equation
        
        ## Problem
        Solve the quadratic equation: x² + 5x + 6 = 0
        
        ## Solution
        1. Identify the coefficients: a = 1, b = 5, c = 6
        2. Use the quadratic formula: x = (-b ± √(b² - 4ac)) / 2a
        3. Substitute the values: x = (-5 ± √(25 - 24)) / 2
        4. Simplify: x = (-5 ± √1) / 2
        5. Further simplify: x = (-5 ± 1) / 2
        6. Find the two solutions:
           - x₁ = (-5 + 1) / 2 = -2
           - x₂ = (-5 - 1) / 2 = -3
        
        ## Answer
        The solutions are x = -2 and x = -3
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        problem = "Solve the quadratic equation: x² + 5x + 6 = 0"
        
        # Call the method
        result = self.homework_service.generate_step_by_step_explanation(problem)
        
        # Assertions
        self.assertIsInstance(result, dict)
        self.assertIn('explanation', result)
        self.assertIn('steps', result)
        self.assertTrue(len(result['steps']) > 0)
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        call_args = mock_openai.ChatCompletion.create.call_args[1]
        self.assertEqual(call_args['model'], 'gpt-4')
        self.assertIn('messages', call_args)
        
    @patch('src.services.homework_service.openai')
    def test_generate_citations(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        [
            {
                "title": "Introduction to Algorithms",
                "authors": "Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, Clifford Stein",
                "year": 2009,
                "publisher": "MIT Press",
                "format": "MLA",
                "citation": "Cormen, Thomas H., et al. Introduction to Algorithms. MIT Press, 2009."
            },
            {
                "title": "Data Structures and Algorithms in Python",
                "authors": "Michael T. Goodrich, Roberto Tamassia, Michael H. Goldwasser",
                "year": 2013,
                "publisher": "Wiley",
                "format": "MLA",
                "citation": "Goodrich, Michael T., et al. Data Structures and Algorithms in Python. Wiley, 2013."
            }
        ]
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        topic = "binary search trees and their implementation in Python"
        
        # Call the method
        result = self.homework_service.generate_citations(topic)
        
        # Assertions
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) > 0)
        self.assertIn('title', result[0])
        self.assertIn('citation', result[0])
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        
    @patch('src.services.homework_service.openai')
    def test_check_grammar(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        {
            "corrected_text": "The quick brown fox jumps over the lazy dog. It was a beautiful day in the forest.",
            "corrections": [
                {
                    "original": "jumps",
                    "corrected": "jumped",
                    "explanation": "Changed to past tense to match the tense of the second sentence."
                },
                {
                    "original": "It was an beautiful day",
                    "corrected": "It was a beautiful day",
                    "explanation": "Changed 'an' to 'a' because 'beautiful' begins with a consonant sound."
                }
            ],
            "feedback": "Overall, the text has good grammar but needs consistency in tense and proper article usage."
        }
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        text = "The quick brown fox jumps over the lazy dog. It was an beautiful day in the forest."
        
        # Call the method
        result = self.homework_service.check_grammar(text)
        
        # Assertions
        self.assertIsInstance(result, dict)
        self.assertIn('corrected_text', result)
        self.assertIn('corrections', result)
        self.assertIn('feedback', result)
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()

if __name__ == '__main__':
    unittest.main()
