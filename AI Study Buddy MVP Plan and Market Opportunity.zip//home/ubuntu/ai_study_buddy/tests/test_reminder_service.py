import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add the project root to the path so we can import our modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.services.reminder_service import ReminderService

class TestReminderService(unittest.TestCase):
    def setUp(self):
        self.reminder_service = ReminderService()
        
    @patch('src.services.reminder_service.openai')
    def test_suggest_reminders(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        [
            {
                "title": "Start History Essay Research",
                "description": "Begin research for your History Essay due on Mar 28",
                "reminder_date": "2025-03-22T10:00:00",
                "priority": 2,
                "assignment_id": 2
            },
            {
                "title": "Review Programming Concepts",
                "description": "Review binary trees before starting your Programming Assignment",
                "reminder_date": "2025-03-22T14:00:00",
                "priority": 2,
                "assignment_id": 3
            },
            {
                "title": "Math Study Session",
                "description": "Schedule a study session for your upcoming Math exam",
                "reminder_date": "2025-03-23T15:00:00",
                "priority": 3,
                "class_id": 1
            }
        ]
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        assignments = [
            {"id": 1, "title": "Math Problem Set 3", "due_date": "2025-03-25T23:59:00", "course_id": 1},
            {"id": 2, "title": "History Essay", "due_date": "2025-03-28T23:59:00", "course_id": 2},
            {"id": 3, "title": "Programming Assignment", "due_date": "2025-03-24T23:59:00", "course_id": 3}
        ]
        
        classes = [
            {"id": 1, "title": "Calculus I"},
            {"id": 2, "title": "World History"},
            {"id": 3, "title": "Data Structures"}
        ]
        
        # Call the method
        result = self.reminder_service.suggest_reminders(assignments, classes)
        
        # Assertions
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) > 0)
        self.assertIn('title', result[0])
        self.assertIn('description', result[0])
        self.assertIn('reminder_date', result[0])
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        call_args = mock_openai.ChatCompletion.create.call_args[1]
        self.assertEqual(call_args['model'], 'gpt-4')
        self.assertIn('messages', call_args)
        
    @patch('src.services.reminder_service.openai')
    def test_prioritize_tasks(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        [
            {
                "id": 3,
                "title": "Programming Assignment",
                "priority": 3,
                "reason": "Due in 2 days and requires significant time to complete"
            },
            {
                "id": 1,
                "title": "Math Problem Set 3",
                "priority": 2,
                "reason": "Due in 3 days but should be started soon"
            },
            {
                "id": 2,
                "title": "History Essay",
                "priority": 1,
                "reason": "Due in 6 days, can be started later this week"
            }
        ]
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        tasks = [
            {"id": 1, "title": "Math Problem Set 3", "due_date": "2025-03-25T23:59:00"},
            {"id": 2, "title": "History Essay", "due_date": "2025-03-28T23:59:00"},
            {"id": 3, "title": "Programming Assignment", "due_date": "2025-03-24T23:59:00"}
        ]
        
        # Call the method
        result = self.reminder_service.prioritize_tasks(tasks)
        
        # Assertions
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) > 0)
        self.assertIn('id', result[0])
        self.assertIn('priority', result[0])
        self.assertIn('reason', result[0])
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        
    @patch('src.services.reminder_service.openai')
    def test_generate_study_schedule(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        {
            "schedule": [
                {
                    "day": "Monday",
                    "date": "2025-03-22",
                    "blocks": [
                        {
                            "start_time": "09:00",
                            "end_time": "11:00",
                            "activity": "Work on Programming Assignment",
                            "task_id": 3
                        },
                        {
                            "start_time": "14:00",
                            "end_time": "16:00",
                            "activity": "Math Problem Set 3",
                            "task_id": 1
                        }
                    ]
                },
                {
                    "day": "Tuesday",
                    "date": "2025-03-23",
                    "blocks": [
                        {
                            "start_time": "10:00",
                            "end_time": "12:00",
                            "activity": "Complete Programming Assignment",
                            "task_id": 3
                        },
                        {
                            "start_time": "15:00",
                            "end_time": "17:00",
                            "activity": "Continue Math Problem Set",
                            "task_id": 1
                        }
                    ]
                }
            ],
            "recommendations": [
                "Focus on completing the Programming Assignment first as it's due soonest",
                "Break the Math Problem Set into smaller sessions",
                "Start the History Essay research by Wednesday"
            ]
        }
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        tasks = [
            {"id": 1, "title": "Math Problem Set 3", "due_date": "2025-03-25T23:59:00", "priority": 2},
            {"id": 2, "title": "History Essay", "due_date": "2025-03-28T23:59:00", "priority": 1},
            {"id": 3, "title": "Programming Assignment", "due_date": "2025-03-24T23:59:00", "priority": 3}
        ]
        
        availability = {
            "weekdays": [
                {"day": "Monday", "start": "09:00", "end": "17:00"},
                {"day": "Tuesday", "start": "10:00", "end": "18:00"},
                {"day": "Wednesday", "start": "09:00", "end": "17:00"}
            ],
            "preferred_session_length": 120,
            "preferred_break_length": 30
        }
        
        # Call the method
        result = self.reminder_service.generate_study_schedule(tasks, availability)
        
        # Assertions
        self.assertIsInstance(result, dict)
        self.assertIn('schedule', result)
        self.assertIn('recommendations', result)
        self.assertTrue(len(result['schedule']) > 0)
        self.assertTrue(len(result['recommendations']) > 0)
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()

if __name__ == '__main__':
    unittest.main()
