import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add the project root to the path so we can import our modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.services.scheduler_service import SchedulerService

class TestSchedulerService(unittest.TestCase):
    def setUp(self):
        self.scheduler_service = SchedulerService()
        
    @patch('src.services.scheduler_service.openai')
    def test_detect_schedule_conflicts(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        [
            {
                "description": "Schedule overlap between Calculus I and English Literature",
                "date": "2025-03-24",
                "time": "09:00 - 10:30",
                "activities": "Calculus I, English Literature",
                "overlap": "90 minutes",
                "suggestion": "Consider rescheduling English Literature to a different time slot"
            },
            {
                "description": "Schedule overlap between Data Structures and Physics 101",
                "date": "2025-03-26",
                "time": "14:00 - 15:30",
                "activities": "Data Structures, Physics 101 Lab",
                "overlap": "30 minutes",
                "suggestion": "Check if you can leave Data Structures early or arrive late to Physics Lab"
            }
        ]
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        classes = [
            {
                "id": 1,
                "title": "Calculus I",
                "sessions": [
                    {
                        "day_of_week": 1,  # Monday
                        "start_time": "09:00",
                        "end_time": "10:30"
                    },
                    {
                        "day_of_week": 3,  # Wednesday
                        "start_time": "09:00",
                        "end_time": "10:30"
                    }
                ]
            },
            {
                "id": 2,
                "title": "English Literature",
                "sessions": [
                    {
                        "day_of_week": 1,  # Monday
                        "start_time": "09:00",
                        "end_time": "10:30"
                    }
                ]
            },
            {
                "id": 3,
                "title": "Data Structures",
                "sessions": [
                    {
                        "day_of_week": 3,  # Wednesday
                        "start_time": "14:00",
                        "end_time": "15:30"
                    }
                ]
            },
            {
                "id": 4,
                "title": "Physics 101",
                "sessions": [
                    {
                        "day_of_week": 3,  # Wednesday
                        "start_time": "15:00",
                        "end_time": "17:00"
                    }
                ]
            }
        ]
        
        # Call the method
        result = self.scheduler_service.detect_schedule_conflicts(classes)
        
        # Assertions
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) > 0)
        self.assertIn('description', result[0])
        self.assertIn('date', result[0])
        self.assertIn('time', result[0])
        self.assertIn('suggestion', result[0])
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        call_args = mock_openai.ChatCompletion.create.call_args[1]
        self.assertEqual(call_args['model'], 'gpt-4')
        self.assertIn('messages', call_args)
        
    @patch('src.services.scheduler_service.openai')
    def test_optimize_class_schedule(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        {
            "optimized_schedule": [
                {
                    "id": 1,
                    "title": "Calculus I",
                    "sessions": [
                        {
                            "day_of_week": 1,
                            "start_time": "09:00",
                            "end_time": "10:30"
                        },
                        {
                            "day_of_week": 3,
                            "start_time": "09:00",
                            "end_time": "10:30"
                        }
                    ]
                },
                {
                    "id": 2,
                    "title": "English Literature",
                    "sessions": [
                        {
                            "day_of_week": 1,
                            "start_time": "11:00",
                            "end_time": "12:30"
                        }
                    ]
                },
                {
                    "id": 3,
                    "title": "Data Structures",
                    "sessions": [
                        {
                            "day_of_week": 3,
                            "start_time": "14:00",
                            "end_time": "15:30"
                        }
                    ]
                },
                {
                    "id": 4,
                    "title": "Physics 101",
                    "sessions": [
                        {
                            "day_of_week": 3,
                            "start_time": "16:00",
                            "end_time": "18:00"
                        }
                    ]
                }
            ],
            "changes": [
                {
                    "class": "English Literature",
                    "original": "Monday 09:00-10:30",
                    "new": "Monday 11:00-12:30",
                    "reason": "Resolved conflict with Calculus I"
                },
                {
                    "class": "Physics 101",
                    "original": "Wednesday 15:00-17:00",
                    "new": "Wednesday 16:00-18:00",
                    "reason": "Resolved overlap with Data Structures"
                }
            ],
            "recommendations": [
                "This schedule eliminates all direct conflicts",
                "Added 30-minute breaks between consecutive classes",
                "Maintained original days to preserve your availability"
            ]
        }
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        classes = [
            {
                "id": 1,
                "title": "Calculus I",
                "sessions": [
                    {
                        "day_of_week": 1,  # Monday
                        "start_time": "09:00",
                        "end_time": "10:30"
                    },
                    {
                        "day_of_week": 3,  # Wednesday
                        "start_time": "09:00",
                        "end_time": "10:30"
                    }
                ]
            },
            {
                "id": 2,
                "title": "English Literature",
                "sessions": [
                    {
                        "day_of_week": 1,  # Monday
                        "start_time": "09:00",
                        "end_time": "10:30"
                    }
                ]
            },
            {
                "id": 3,
                "title": "Data Structures",
                "sessions": [
                    {
                        "day_of_week": 3,  # Wednesday
                        "start_time": "14:00",
                        "end_time": "15:30"
                    }
                ]
            },
            {
                "id": 4,
                "title": "Physics 101",
                "sessions": [
                    {
                        "day_of_week": 3,  # Wednesday
                        "start_time": "15:00",
                        "end_time": "17:00"
                    }
                ]
            }
        ]
        
        preferences = {
            "preferred_days": [1, 2, 3],  # Monday, Tuesday, Wednesday
            "preferred_time_range": {"start": "08:00", "end": "18:00"},
            "preferred_break_between_classes": 30,
            "minimize_changes": True
        }
        
        # Call the method
        result = self.scheduler_service.optimize_class_schedule(classes, preferences)
        
        # Assertions
        self.assertIsInstance(result, dict)
        self.assertIn('optimized_schedule', result)
        self.assertIn('changes', result)
        self.assertIn('recommendations', result)
        self.assertTrue(len(result['optimized_schedule']) > 0)
        self.assertTrue(len(result['changes']) > 0)
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        
    @patch('src.services.scheduler_service.openai')
    def test_parse_imported_schedule(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        [
            {
                "title": "Physics 101",
                "location": "Science Building, Room 302",
                "instructor": "Dr. Wilson",
                "sessions": [
                    {
                        "day_of_week": 2,
                        "start_time": "11:00",
                        "end_time": "12:30",
                        "is_online": false
                    },
                    {
                        "day_of_week": 4,
                        "start_time": "11:00",
                        "end_time": "12:30",
                        "is_online": false
                    }
                ]
            },
            {
                "title": "English Literature",
                "location": "Humanities Building, Room 105",
                "instructor": "Prof. Davis",
                "sessions": [
                    {
                        "day_of_week": 1,
                        "start_time": "11:00",
                        "end_time": "12:30",
                        "is_online": false
                    },
                    {
                        "day_of_week": 3,
                        "start_time": "11:00",
                        "end_time": "12:30",
                        "is_online": false
                    }
                ]
            }
        ]
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        raw_schedule = """
        PHYS 101 - Physics 101
        Instructor: Dr. Wilson
        Location: Science Building, Room 302
        Schedule: Tuesday and Thursday, 11:00 AM - 12:30 PM
        
        ENGL 205 - English Literature
        Instructor: Prof. Davis
        Location: Humanities Building, Room 105
        Schedule: Monday and Wednesday, 11:00 AM - 12:30 PM
        """
        
        format_type = "text"
        
        # Call the method
        result = self.scheduler_service.parse_imported_schedule(raw_schedule, format_type)
        
        # Assertions
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) > 0)
        self.assertIn('title', result[0])
        self.assertIn('location', result[0])
        self.assertIn('instructor', result[0])
        self.assertIn('sessions', result[0])
        self.assertTrue(len(result[0]['sessions']) > 0)
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()

if __name__ == '__main__':
    unittest.main()
