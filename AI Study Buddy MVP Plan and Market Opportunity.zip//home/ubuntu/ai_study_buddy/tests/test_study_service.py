import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add the project root to the path so we can import our modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.services.study_service import StudyService

class TestStudyService(unittest.TestCase):
    def setUp(self):
        self.study_service = StudyService()
        
    @patch('src.services.study_service.openai')
    def test_generate_summary(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        {
            "summary": "Newton's Laws of Motion are three fundamental principles that form the foundation of classical mechanics. The First Law states that an object at rest stays at rest, and an object in motion stays in motion unless acted upon by an external force. The Second Law establishes that force equals mass times acceleration (F = ma). The Third Law states that for every action, there is an equal and opposite reaction. These laws, formulated by Sir Isaac Newton in the 17th century, revolutionized our understanding of physics and remain essential to modern engineering and physics.",
            "key_points": [
                "Newton's First Law: Objects maintain their state of motion unless acted upon by a force",
                "Newton's Second Law: F = ma (Force equals mass times acceleration)",
                "Newton's Third Law: For every action, there is an equal and opposite reaction",
                "These laws form the foundation of classical mechanics",
                "Newton published these laws in the 17th century"
            ]
        }
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        content = "Newton's First Law: An object at rest stays at rest, and an object in motion stays in motion unless acted upon by an external force. Newton's Second Law: The acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass. Newton's Third Law: For every action, there is an equal and opposite reaction."
        
        # Call the method
        result = self.study_service.generate_summary(content)
        
        # Assertions
        self.assertIsInstance(result, dict)
        self.assertIn('summary', result)
        self.assertIn('key_points', result)
        self.assertTrue(len(result['key_points']) > 0)
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        call_args = mock_openai.ChatCompletion.create.call_args[1]
        self.assertEqual(call_args['model'], 'gpt-4')
        self.assertIn('messages', call_args)
        
    @patch('src.services.study_service.openai')
    def test_generate_flashcards(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        [
            {
                "front": "What is Newton's First Law of Motion?",
                "back": "An object at rest stays at rest, and an object in motion stays in motion unless acted upon by an external force."
            },
            {
                "front": "What is Newton's Second Law of Motion?",
                "back": "The acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass. F = ma"
            },
            {
                "front": "What is Newton's Third Law of Motion?",
                "back": "For every action, there is an equal and opposite reaction."
            }
        ]
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        content = "Newton's Laws of Motion include the First Law (inertia), the Second Law (F = ma), and the Third Law (equal and opposite reactions)."
        
        # Call the method
        result = self.study_service.generate_flashcards(content)
        
        # Assertions
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) > 0)
        self.assertIn('front', result[0])
        self.assertIn('back', result[0])
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        
    @patch('src.services.study_service.openai')
    def test_generate_quiz(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        {
            "questions": [
                {
                    "question": "What is Newton's First Law of Motion?",
                    "options": [
                        "Objects in motion tend to stay in motion unless acted upon by a force",
                        "Force equals mass times acceleration",
                        "For every action, there is an equal and opposite reaction",
                        "Energy cannot be created or destroyed"
                    ],
                    "correct_answer": 0
                },
                {
                    "question": "Which formula represents Newton's Second Law?",
                    "options": [
                        "E = mc²",
                        "F = ma",
                        "a = F/m",
                        "Both B and C"
                    ],
                    "correct_answer": 3
                },
                {
                    "question": "Newton's Third Law states that:",
                    "options": [
                        "Energy is conserved in a closed system",
                        "Objects maintain their velocity unless acted upon",
                        "For every action, there is an equal and opposite reaction",
                        "Force is directly proportional to acceleration"
                    ],
                    "correct_answer": 2
                }
            ]
        }
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        content = "Newton's Laws of Motion include the First Law (inertia), the Second Law (F = ma), and the Third Law (equal and opposite reactions)."
        
        # Call the method
        result = self.study_service.generate_quiz(content)
        
        # Assertions
        self.assertIsInstance(result, dict)
        self.assertIn('questions', result)
        self.assertTrue(len(result['questions']) > 0)
        self.assertIn('question', result['questions'][0])
        self.assertIn('options', result['questions'][0])
        self.assertIn('correct_answer', result['questions'][0])
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        
    def test_calculate_spaced_repetition(self):
        # Test inputs
        last_review_date = "2025-03-15"
        difficulty_level = 3  # Medium difficulty
        previous_interval = 2  # 2 days
        
        # Call the method
        next_review_date, new_interval = self.study_service.calculate_spaced_repetition(
            last_review_date, difficulty_level, previous_interval
        )
        
        # Assertions
        self.assertIsInstance(next_review_date, str)
        self.assertIsInstance(new_interval, int)
        self.assertTrue(new_interval > previous_interval)  # Interval should increase

if __name__ == '__main__':
    unittest.main()
