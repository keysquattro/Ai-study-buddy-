# AI Study Buddy - Deployment Guide

This guide provides instructions for deploying the AI Study Buddy application in various environments.

## Deployment Options

AI Study Buddy can be deployed in several ways:

1. **Local Development**: For testing and development
2. **Traditional Server Deployment**: For production on a VPS or dedicated server
3. **Docker Deployment**: For containerized environments
4. **Cloud Platform Deployment**: For scalable cloud hosting

## Option 1: Local Development Deployment

Follow the instructions in the [Installation Guide](installation_guide.md) for setting up a local development environment.

## Option 2: Traditional Server Deployment

### Prerequisites

- Ubuntu 20.04 LTS or newer
- Python 3.10+
- Node.js 16+
- PostgreSQL 13+
- Nginx
- Certbot (for SSL)

### Backend Deployment

1. Clone the repository:
```bash
git clone https://github.com/aistudybuddy/ai-study-buddy.git
cd ai-study-buddy
```

2. Set up a Python virtual environment:
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install gunicorn
```

3. Create and configure the `.env` file:
```
DATABASE_URL=postgresql://username:password@localhost:5432/ai_study_buddy
SECRET_KEY=your_production_secret_key
JWT_SECRET_KEY=your_production_jwt_secret
OPENAI_API_KEY=your_openai_api_key
FLASK_ENV=production
```

4. Initialize the database:
```bash
flask db upgrade
```

5. Create a systemd service file for the backend:
```bash
sudo nano /etc/systemd/system/ai-study-buddy.service
```

6. Add the following content:
```
[Unit]
Description=AI Study Buddy Backend
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/path/to/ai-study-buddy
Environment="PATH=/path/to/ai-study-buddy/venv/bin"
EnvironmentFile=/path/to/ai-study-buddy/.env
ExecStart=/path/to/ai-study-buddy/venv/bin/gunicorn --workers 3 --bind 127.0.0.1:5000 app:app

[Install]
WantedBy=multi-user.target
```

7. Enable and start the service:
```bash
sudo systemctl enable ai-study-buddy
sudo systemctl start ai-study-buddy
```

### Frontend Deployment

1. Navigate to the frontend directory:
```bash
cd frontend
```

2. Install dependencies and build the production version:
```bash
npm install
npm run build
```

3. Configure Nginx:
```bash
sudo nano /etc/nginx/sites-available/ai-study-buddy
```

4. Add the following configuration:
```
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location /api {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location / {
        root /path/to/ai-study-buddy/frontend/build;
        index index.html;
        try_files $uri $uri/ /index.html;
    }
}
```

5. Enable the site and restart Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/ai-study-buddy /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

6. Set up SSL with Certbot:
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

## Option 3: Docker Deployment

### Prerequisites

- Docker
- Docker Compose

### Deployment Steps

1. Clone the repository:
```bash
git clone https://github.com/aistudybuddy/ai-study-buddy.git
cd ai-study-buddy
```

2. Create a `.env` file in the root directory:
```
OPENAI_API_KEY=your_openai_api_key
```

3. Deploy with Docker Compose:
```bash
docker-compose up -d
```

4. Access the application at `http://localhost:3000`

### Production Docker Deployment

For a production Docker deployment, modify the `docker-compose.yml` file:

1. Add a reverse proxy like Traefik or Nginx for SSL termination
2. Use Docker volumes for persistent data
3. Set appropriate environment variables for production

Example with Traefik:
```yaml
version: '3'

services:
  traefik:
    image: traefik:v2.5
    command:
      - "--api.insecure=false"
      - "--providers.docker=true"
      - "--providers.docker.exposedbydefault=false"
      - "--entrypoints.web.address=:80"
      - "--entrypoints.websecure.address=:443"
      - "--certificatesresolvers.myresolver.acme.tlschallenge=true"
      - "--certificatesresolvers.myresolver.acme.email=your-email@example.com"
      - "--certificatesresolvers.myresolver.acme.storage=/letsencrypt/acme.json"
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - "/var/run/docker.sock:/var/run/docker.sock:ro"
      - "letsencrypt:/letsencrypt"

  db:
    image: postgres:13
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_PASSWORD=postgres
      - POSTGRES_USER=postgres
      - POSTGRES_DB=ai_study_buddy
    restart: always

  backend:
    build: 
      context: .
      dockerfile: Dockerfile.backend
    depends_on:
      - db
    environment:
      - DATABASE_URL=postgresql://postgres:postgres@db:5432/ai_study_buddy
      - SECRET_KEY=production_secret_key
      - JWT_SECRET_KEY=production_jwt_secret
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - FLASK_ENV=production
    restart: always
    labels:
      - "traefik.enable=true"
      - "traefik.http.routers.backend.rule=Host(`api.yourdomain.com`)"
      - "traefik.http.routers.backend.entrypoints=websecure"
      - "traefik.http.routers.backend.tls.certresolver=myresolver"

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile.frontend
      args:
        - REACT_APP_API_URL=https://api.yourdomain.com
    restart: always
    labels:
      - "traefik.enable=true"
      - "traefik.http.routers.frontend.rule=Host(`yourdomain.com`)"
      - "traefik.http.routers.frontend.entrypoints=websecure"
      - "traefik.http.routers.frontend.tls.certresolver=myresolver"

volumes:
  postgres_data:
  letsencrypt:
```

## Option 4: Cloud Platform Deployment

### AWS Deployment

1. **Set up AWS Resources**:
   - EC2 instance for the application
   - RDS PostgreSQL instance for the database
   - S3 bucket for static assets (optional)
   - Elastic IP for stable addressing
   - Route 53 for domain management

2. **Deploy Backend**:
   - Follow the Traditional Server Deployment steps for the backend
   - Update the `.env` file with RDS connection details

3. **Deploy Frontend**:
   - Build the frontend with the production API URL
   - Deploy to the EC2 instance or to S3 with CloudFront

### Heroku Deployment

1. **Prerequisites**:
   - Heroku CLI
   - Heroku account
   - PostgreSQL add-on

2. **Backend Deployment**:
   ```bash
   heroku create ai-study-buddy-backend
   heroku addons:create heroku-postgresql:hobby-dev
   heroku config:set SECRET_KEY=your_secret_key
   heroku config:set JWT_SECRET_KEY=your_jwt_secret
   heroku config:set OPENAI_API_KEY=your_openai_api_key
   git push heroku main
   ```

3. **Frontend Deployment**:
   - Create a new Heroku app for the frontend
   - Set the API URL environment variable
   - Deploy the frontend to the new app

### Google Cloud Platform

1. **Set up GCP Resources**:
   - Compute Engine VM or Cloud Run for the application
   - Cloud SQL for PostgreSQL
   - Cloud Storage for static assets (optional)

2. **Deploy with Docker**:
   - Push Docker images to Google Container Registry
   - Deploy to Cloud Run or Compute Engine

## Monitoring and Maintenance

### Monitoring

1. **Set up Application Monitoring**:
   - Prometheus for metrics collection
   - Grafana for visualization
   - Sentry for error tracking

2. **Server Monitoring**:
   - CPU, memory, and disk usage
   - Network traffic
   - Database performance

### Backups

1. **Database Backups**:
   - Automated daily backups
   - Test restoration procedures regularly
   - Store backups in multiple locations

2. **Application Backups**:
   - Version control for code
   - Regular snapshots of configuration

### Updates

1. **Regular Updates**:
   - Security patches
   - Dependency updates
   - Feature enhancements

2. **Update Procedure**:
   - Test updates in staging environment
   - Deploy during low-traffic periods
   - Have rollback plan ready

## Security Considerations

1. **Application Security**:
   - Keep dependencies updated
   - Implement proper authentication and authorization
   - Validate all user inputs

2. **Server Security**:
   - Use firewalls to restrict access
   - Implement fail2ban for brute force protection
   - Keep server software updated

3. **Database Security**:
   - Use strong passwords
   - Restrict network access
   - Encrypt sensitive data

4. **SSL/TLS**:
   - Use HTTPS for all connections
   - Renew certificates automatically
   - Configure secure TLS settings

## Troubleshooting

### Common Issues

1. **Database Connection Problems**:
   - Check network connectivity
   - Verify credentials
   - Check database server status

2. **Application Errors**:
   - Check application logs
   - Verify environment variables
   - Ensure dependencies are installed

3. **Performance Issues**:
   - Monitor resource usage
   - Check for slow database queries
   - Consider scaling resources

### Getting Help

For deployment assistance, contact:
- Email: support@aistudybuddy.com
- GitHub Issues: https://github.com/aistudybuddy/ai-study-buddy/issues
