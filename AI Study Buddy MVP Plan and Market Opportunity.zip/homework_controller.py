"""
Controller for homework assistant functionality in the AI Study Buddy application.
"""
from flask import request, jsonify, current_app
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename
import os
import uuid

from app import db
from src.models.assignment import Assignment, AssignmentFile
from src.models.note import Course
from src.services.homework_service import HomeworkService

class HomeworkController:
    """Controller for handling homework-related requests."""
    
    def __init__(self):
        """Initialize the homework controller."""
        self.homework_service = HomeworkService()
    
    @login_required
    def get_assignments(self):
        """Get all assignments for the current user."""
        try:
            # Get query parameters
            course_id = request.args.get('course_id', type=int)
            status = request.args.get('status')
            
            # Build query
            query = Assignment.query.filter_by(user_id=current_user.id)
            
            # Apply filters if provided
            if course_id:
                query = query.filter_by(course_id=course_id)
            
            if status:
                query = query.filter_by(status=status)
            
            # Execute query and get results
            assignments = query.order_by(Assignment.due_date.asc()).all()
            
            # Format response
            result = []
            for assignment in assignments:
                # Get files for the assignment
                files = [
                    {
                        'id': file.id,
                        'filename': file.filename,
                        'file_type': file.file_type,
                        'upload_date': file.upload_date.isoformat()
                    } 
                    for file in assignment.files
                ]
                
                result.append({
                    'id': assignment.id,
                    'title': assignment.title,
                    'description': assignment.description,
                    'due_date': assignment.due_date.isoformat(),
                    'priority': assignment.priority,
                    'status': assignment.status,
                    'completion_date': assignment.completion_date.isoformat() if assignment.completion_date else None,
                    'created_at': assignment.created_at.isoformat(),
                    'updated_at': assignment.updated_at.isoformat(),
                    'course_id': assignment.course_id,
                    'files': files
                })
            
            return jsonify({'assignments': result}), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving assignments: {str(e)}")
            return jsonify({'error': 'Failed to retrieve assignments'}), 500
    
    @login_required
    def get_assignment(self, assignment_id):
        """Get a specific assignment."""
        try:
            # Get the assignment
            assignment = Assignment.query.filter_by(id=assignment_id, user_id=current_user.id).first()
            
            if not assignment:
                return jsonify({'error': 'Assignment not found'}), 404
            
            # Get files for the assignment
            files = [
                {
                    'id': file.id,
                    'filename': file.filename,
                    'file_type': file.file_type,
                    'upload_date': file.upload_date.isoformat()
                } 
                for file in assignment.files
            ]
            
            # Format response
            result = {
                'id': assignment.id,
                'title': assignment.title,
                'description': assignment.description,
                'due_date': assignment.due_date.isoformat(),
                'priority': assignment.priority,
                'status': assignment.status,
                'completion_date': assignment.completion_date.isoformat() if assignment.completion_date else None,
                'created_at': assignment.created_at.isoformat(),
                'updated_at': assignment.updated_at.isoformat(),
                'course_id': assignment.course_id,
                'files': files
            }
            
            return jsonify(result), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving assignment: {str(e)}")
            return jsonify({'error': 'Failed to retrieve assignment'}), 500
    
    @login_required
    def create_assignment(self):
        """Create a new assignment."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'title' not in data or 'due_date' not in data:
                return jsonify({'error': 'Title and due date are required'}), 400
            
            # Create new assignment
            assignment = Assignment(
                title=data['title'],
                description=data.get('description', ''),
                due_date=data['due_date'],
                priority=data.get('priority', 2),
                status=data.get('status', 'Not Started'),
                user_id=current_user.id,
                course_id=data.get('course_id')
            )
            
            # Add assignment to database
            db.session.add(assignment)
            db.session.commit()
            
            return jsonify({
                'message': 'Assignment created successfully',
                'assignment_id': assignment.id
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error creating assignment: {str(e)}")
            return jsonify({'error': 'Failed to create assignment'}), 500
    
    @login_required
    def update_assignment(self, assignment_id):
        """Update a specific assignment."""
        try:
            # Get the assignment
            assignment = Assignment.query.filter_by(id=assignment_id, user_id=current_user.id).first()
            
            if not assignment:
                return jsonify({'error': 'Assignment not found'}), 404
            
            # Get request data
            data = request.get_json()
            
            # Update assignment fields
            if 'title' in data:
                assignment.title = data['title']
            
            if 'description' in data:
                assignment.description = data['description']
            
            if 'due_date' in data:
                assignment.due_date = data['due_date']
            
            if 'priority' in data:
                assignment.priority = data['priority']
            
            if 'status' in data:
                assignment.status = data['status']
                
                # If status is changed to Completed, set completion date
                if data['status'] == 'Completed' and assignment.completion_date is None:
                    assignment.completion_date = datetime.now()
                # If status is changed from Completed, clear completion date
                elif data['status'] != 'Completed' and assignment.completion_date is not None:
                    assignment.completion_date = None
            
            if 'course_id' in data:
                assignment.course_id = data['course_id']
            
            # Commit changes
            db.session.commit()
            
            return jsonify({'message': 'Assignment updated successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error updating assignment: {str(e)}")
            return jsonify({'error': 'Failed to update assignment'}), 500
    
    @login_required
    def delete_assignment(self, assignment_id):
        """Delete a specific assignment."""
        try:
            # Get the assignment
            assignment = Assignment.query.filter_by(id=assignment_id, user_id=current_user.id).first()
            
            if not assignment:
                return jsonify({'error': 'Assignment not found'}), 404
            
            # Delete the assignment (cascade will delete files)
            db.session.delete(assignment)
            db.session.commit()
            
            return jsonify({'message': 'Assignment deleted successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error deleting assignment: {str(e)}")
            return jsonify({'error': 'Failed to delete assignment'}), 500
    
    @login_required
    def get_assistance(self):
        """Get AI assistance for homework."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'question' not in data:
                return jsonify({'error': 'Question is required'}), 400
            
            # Get assistance using the service
            assistance = self.homework_service.get_homework_assistance(
                question=data['question'],
                context=data.get('context'),
                subject=data.get('subject')
            )
            
            return jsonify(assistance), 200
            
        except Exception as e:
            current_app.logger.error(f"Error getting homework assistance: {str(e)}")
            return jsonify({'error': f'Failed to get homework assistance: {str(e)}'}), 500
    
    @login_required
    def generate_citations(self):
        """Generate properly formatted citations."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'source_info' not in data:
                return jsonify({'error': 'Source information is required'}), 400
            
            # Generate citation using the service
            citation = self.homework_service.generate_citations(
                source_info=data['source_info'],
                citation_style=data.get('citation_style', 'APA')
            )
            
            return jsonify(citation), 200
            
        except Exception as e:
            current_app.logger.error(f"Error generating citation: {str(e)}")
            return jsonify({'error': f'Failed to generate citation: {str(e)}'}), 500
    
    @login_required
    def format_report(self):
        """Format a report according to academic standards."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'content' not in data:
                return jsonify({'error': 'Report content is required'}), 400
            
            # Format report using the service
            formatted_report = self.homework_service.format_report(
                content=data['content'],
                formatting_style=data.get('formatting_style', 'APA')
            )
            
            return jsonify(formatted_report), 200
            
        except Exception as e:
            current_app.logger.error(f"Error formatting report: {str(e)}")
            return jsonify({'error': f'Failed to format report: {str(e)}'}), 500
    
    @login_required
    def check_grammar_style(self):
        """Check grammar and writing style in text."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'text' not in data:
                return jsonify({'error': 'Text content is required'}), 400
            
            # Check grammar and style using the service
            suggestions = self.homework_service.check_grammar_style(
                text=data['text']
            )
            
            return jsonify(suggestions), 200
            
        except Exception as e:
            current_app.logger.error(f"Error checking grammar and style: {str(e)}")
            return jsonify({'error': f'Failed to check grammar and style: {str(e)}'}), 500
    
    @login_required
    def upload_assignment_file(self, assignment_id):
        """Upload a file for an assignment."""
        try:
            # Get the assignment
            assignment = Assignment.query.filter_by(id=assignment_id, user_id=current_user.id).first()
            
            if not assignment:
                return jsonify({'error': 'Assignment not found'}), 404
            
            # Check if the post request has the file part
            if 'file' not in request.files:
                return jsonify({'error': 'No file part'}), 400
            
            file = request.files['file']
            
            if file.filename == '':
                return jsonify({'error': 'No selected file'}), 400
            
            if file:
                # Save the file
                filename = secure_filename(file.filename)
                unique_filename = f"{uuid.uuid4()}_{filename}"
                upload_folder = current_app.config['UPLOAD_FOLDER']
                file_path = os.path.join(upload_folder, unique_filename)
                file.save(file_path)
                
                # Determine file type
                file_type = os.path.splitext(filename)[1][1:].lower()
                
                # Create new assignment file
                assignment_file = AssignmentFile(
                    filename=filename,
                    file_path=file_path,
                    file_type=file_type,
                    assignment_id=assignment_id
                )
                
                # Add file to database
                db.session.add(assignment_file)
                db.session.commit()
                
                return jsonify({
                    'message': 'File uploaded successfully',
                    'file_id': assignment_file.id,
                    'filename': assignment_file.filename
                }), 201
            
            return jsonify({'error': 'Failed to upload file'}), 400
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error uploading file: {str(e)}")
            return jsonify({'error': f'Failed to upload file: {str(e)}'}), 500
