"""
AI service for homework assistance functionality in the AI Study Buddy application.
"""
import os
import openai
from flask import current_app

class HomeworkService:
    """Service for AI-powered homework assistance features."""
    
    def __init__(self):
        """Initialize the homework service with API key."""
        self.api_key = os.environ.get("OPENAI_API_KEY")
        openai.api_key = self.api_key
    
    def get_homework_assistance(self, question, context=None, subject=None):
        """
        Provide assistance for homework questions.
        
        Args:
            question (str): The homework question or problem.
            context (str, optional): Additional context or course materials.
            subject (str, optional): The subject area (math, science, etc.).
            
        Returns:
            dict: A dictionary containing the assistance response.
        """
        try:
            # Create a prompt for the OpenAI API
            prompt = self._create_assistance_prompt(question, context, subject)
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an educational assistant helping students understand concepts and solve problems. Provide step-by-step explanations rather than just answers. Focus on teaching the underlying concepts."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1500,
                temperature=0.5
            )
            
            # Extract the generated assistance
            assistance_content = response.choices[0].message.content
            
            return {
                "question": question,
                "explanation": assistance_content,
                "subject": subject
            }
            
        except Exception as e:
            current_app.logger.error(f"Error generating homework assistance: {str(e)}")
            return {
                "question": question,
                "explanation": f"An error occurred while generating assistance: {str(e)}",
                "subject": subject
            }
    
    def generate_citations(self, source_info, citation_style="APA"):
        """
        Generate properly formatted citations.
        
        Args:
            source_info (dict): Information about the source (title, author, year, etc.).
            citation_style (str): The citation style (APA, MLA, Chicago, etc.).
            
        Returns:
            dict: A dictionary containing the formatted citation.
        """
        try:
            # Create a prompt for the OpenAI API
            prompt = f"""
            Generate a {citation_style} citation for the following source:
            
            Title: {source_info.get('title', 'Unknown')}
            Author(s): {source_info.get('authors', 'Unknown')}
            Year: {source_info.get('year', 'Unknown')}
            Publisher: {source_info.get('publisher', 'Unknown')}
            URL: {source_info.get('url', 'Unknown')}
            Journal: {source_info.get('journal', 'Unknown')}
            Volume: {source_info.get('volume', 'Unknown')}
            Issue: {source_info.get('issue', 'Unknown')}
            Pages: {source_info.get('pages', 'Unknown')}
            
            Please provide only the formatted citation without any additional text.
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": f"Generate a properly formatted {citation_style} citation."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=200,
                temperature=0.3
            )
            
            # Extract the generated citation
            citation = response.choices[0].message.content.strip()
            
            return {
                "citation": citation,
                "style": citation_style,
                "source_info": source_info
            }
            
        except Exception as e:
            current_app.logger.error(f"Error generating citation: {str(e)}")
            return {
                "citation": f"An error occurred while generating citation: {str(e)}",
                "style": citation_style,
                "source_info": source_info
            }
    
    def format_report(self, content, formatting_style="APA"):
        """
        Format a report according to academic standards.
        
        Args:
            content (str): The content of the report.
            formatting_style (str): The formatting style (APA, MLA, etc.).
            
        Returns:
            dict: A dictionary containing the formatted report.
        """
        try:
            # Create a prompt for the OpenAI API
            prompt = f"""
            Format the following report content according to {formatting_style} style guidelines:
            
            {content}
            
            Please ensure proper:
            1. Title page format
            2. Headings and subheadings
            3. In-text citations
            4. Paragraph structure
            5. Spacing and margins (described in comments)
            6. Reference list format
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": f"Format academic content according to {formatting_style} style guidelines."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=2000,
                temperature=0.3
            )
            
            # Extract the formatted report
            formatted_content = response.choices[0].message.content
            
            return {
                "formatted_content": formatted_content,
                "style": formatting_style
            }
            
        except Exception as e:
            current_app.logger.error(f"Error formatting report: {str(e)}")
            return {
                "formatted_content": f"An error occurred while formatting report: {str(e)}",
                "style": formatting_style
            }
    
    def check_grammar_style(self, text):
        """
        Check grammar and writing style in text.
        
        Args:
            text (str): The text to check.
            
        Returns:
            dict: A dictionary containing grammar and style suggestions.
        """
        try:
            # Create a prompt for the OpenAI API
            prompt = f"""
            Review the following text for grammar, spelling, punctuation, and style issues.
            Provide specific corrections and suggestions for improvement:
            
            {text}
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are a professional editor reviewing academic writing. Identify grammar, spelling, punctuation, and style issues. Provide specific corrections and suggestions for improvement."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000,
                temperature=0.3
            )
            
            # Extract the suggestions
            suggestions = response.choices[0].message.content
            
            return {
                "original_text": text,
                "suggestions": suggestions
            }
            
        except Exception as e:
            current_app.logger.error(f"Error checking grammar and style: {str(e)}")
            return {
                "original_text": text,
                "suggestions": f"An error occurred while checking grammar and style: {str(e)}"
            }
    
    def _create_assistance_prompt(self, question, context=None, subject=None):
        """
        Create a prompt for the OpenAI API to provide homework assistance.
        
        Args:
            question (str): The homework question or problem.
            context (str, optional): Additional context or course materials.
            subject (str, optional): The subject area.
            
        Returns:
            str: The prompt for the OpenAI API.
        """
        subject_context = f"Subject: {subject}\n" if subject else ""
        additional_context = f"\nAdditional Context:\n{context}\n" if context else ""
        
        prompt = f"""
        {subject_context}
        Question: {question}
        {additional_context}
        
        Please provide a step-by-step explanation to help me understand how to solve this problem. Focus on teaching the concepts rather than just giving the answer.
        """
        
        return prompt
