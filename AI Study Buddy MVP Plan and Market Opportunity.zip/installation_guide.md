# AI Study Buddy - Installation Guide

This guide will walk you through the process of setting up and running the AI Study Buddy application on your local machine or server.

## Prerequisites

Before you begin, ensure you have the following installed:

- Python 3.10 or higher
- Node.js 16.0 or higher
- PostgreSQL 13 or higher
- Git

## Step 1: Clone the Repository

```bash
git clone https://github.com/aistudybuddy/ai-study-buddy.git
cd ai-study-buddy
```

## Step 2: Set Up the Backend

### Create a Virtual Environment

```bash
# Create a virtual environment
python -m venv venv

# Activate the virtual environment
# On Windows
venv\Scripts\activate
# On macOS/Linux
source venv/bin/activate
```

### Install Dependencies

```bash
pip install -r requirements.txt
```

### Configure Environment Variables

Create a `.env` file in the root directory with the following variables:

```
# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/ai_study_buddy

# Security
SECRET_KEY=your_secret_key_here
JWT_SECRET_KEY=your_jwt_secret_key_here

# OpenAI API
OPENAI_API_KEY=your_openai_api_key_here

# Application Settings
FLASK_APP=app.py
FLASK_ENV=development
```

Replace the placeholder values with your actual configuration.

### Initialize the Database

```bash
# Create the database in PostgreSQL
createdb ai_study_buddy

# Initialize the database schema
flask db upgrade
```

## Step 3: Set Up the Frontend

### Install Dependencies

```bash
cd frontend
npm install
```

### Configure Frontend Environment

Create a `.env` file in the `frontend` directory:

```
REACT_APP_API_URL=http://localhost:5000/api
```

## Step 4: Run the Application

### Start the Backend Server

From the root directory, with the virtual environment activated:

```bash
python app.py
```

The backend server will start at `http://localhost:5000`.

### Start the Frontend Development Server

In a new terminal, navigate to the frontend directory:

```bash
cd frontend
npm start
```

The frontend development server will start at `http://localhost:3000`.

## Step 5: Access the Application

Open your web browser and navigate to:

```
http://localhost:3000
```

You should now see the AI Study Buddy application running.

## Production Deployment

For production deployment, follow these additional steps:

### Backend Production Setup

1. Use a production WSGI server like Gunicorn:

```bash
pip install gunicorn
gunicorn --bind 0.0.0.0:5000 app:app
```

2. Set up a reverse proxy with Nginx or Apache

3. Configure SSL/TLS certificates for secure connections

4. Update the `.env` file with production settings:

```
FLASK_ENV=production
DATABASE_URL=postgresql://username:password@production_db_host:5432/ai_study_buddy
```

### Frontend Production Build

1. Create an optimized production build:

```bash
cd frontend
npm run build
```

2. Serve the static files using Nginx or another web server

3. Configure the production API URL in the frontend `.env` file:

```
REACT_APP_API_URL=https://api.aistudybuddy.com/api
```

## Docker Deployment (Optional)

For containerized deployment, you can use Docker and Docker Compose.

### Create Docker Compose Configuration

Create a `docker-compose.yml` file in the root directory:

```yaml
version: '3'

services:
  db:
    image: postgres:13
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_PASSWORD=postgres
      - POSTGRES_USER=postgres
      - POSTGRES_DB=ai_study_buddy
    ports:
      - "5432:5432"

  backend:
    build: 
      context: .
      dockerfile: Dockerfile.backend
    volumes:
      - .:/app
    ports:
      - "5000:5000"
    depends_on:
      - db
    environment:
      - DATABASE_URL=postgresql://postgres:postgres@db:5432/ai_study_buddy
      - SECRET_KEY=docker_secret_key
      - JWT_SECRET_KEY=docker_jwt_secret_key
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - FLASK_APP=app.py
      - FLASK_ENV=production

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile.frontend
    volumes:
      - ./frontend:/app
      - /app/node_modules
    ports:
      - "3000:3000"
    depends_on:
      - backend
    environment:
      - REACT_APP_API_URL=http://localhost:5000/api

volumes:
  postgres_data:
```

### Create Backend Dockerfile

Create a `Dockerfile.backend` in the root directory:

```dockerfile
FROM python:3.10-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["gunicorn", "--bind", "0.0.0.0:5000", "app:app"]
```

### Create Frontend Dockerfile

Create a `Dockerfile.frontend` in the frontend directory:

```dockerfile
FROM node:16-alpine

WORKDIR /app

COPY package.json package-lock.json ./
RUN npm install

COPY . .

CMD ["npm", "start"]
```

### Run with Docker Compose

```bash
docker-compose up -d
```

## Troubleshooting

### Database Connection Issues

- Verify PostgreSQL is running
- Check database credentials in `.env` file
- Ensure the database exists

### OpenAI API Issues

- Verify your API key is valid
- Check for rate limiting or quota issues
- Ensure proper network connectivity

### Frontend Connection to Backend

- Verify the backend server is running
- Check CORS configuration in the backend
- Ensure the API URL is correctly set in the frontend

## Maintenance

### Database Backups

```bash
pg_dump -U username ai_study_buddy > backup_$(date +%Y%m%d).sql
```

### Updating Dependencies

```bash
# Backend
pip install -r requirements.txt --upgrade

# Frontend
cd frontend
npm update
```

### Monitoring

Consider setting up monitoring tools like:
- Prometheus for metrics
- Grafana for visualization
- Sentry for error tracking

## Support

If you encounter any issues during installation or deployment, please contact:
- Email: support@aistudybuddy.com
- GitHub Issues: https://github.com/aistudybuddy/ai-study-buddy/issues
