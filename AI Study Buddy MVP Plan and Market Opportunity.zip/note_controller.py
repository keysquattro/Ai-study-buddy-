"""
Controller for note-taking functionality in the AI Study Buddy application.
"""
from flask import request, jsonify, current_app
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename
import os
import uuid

from app import db
from src.models.note import Note, NoteTag, Course
from src.services.note_service import NoteService

class NoteController:
    """Controller for handling note-related requests."""
    
    def __init__(self):
        """Initialize the note controller."""
        self.note_service = NoteService()
    
    @login_required
    def get_notes(self):
        """Get all notes for the current user."""
        try:
            # Get query parameters
            course_id = request.args.get('course_id', type=int)
            
            # Build query
            query = Note.query.filter_by(user_id=current_user.id)
            
            # Apply filters if provided
            if course_id:
                query = query.filter_by(course_id=course_id)
            
            # Execute query and get results
            notes = query.order_by(Note.created_at.desc()).all()
            
            # Format response
            result = []
            for note in notes:
                # Get tags for the note
                tags = [tag.name for tag in note.tags]
                
                result.append({
                    'id': note.id,
                    'title': note.title,
                    'content': note.content,
                    'source_type': note.source_type,
                    'source_reference': note.source_reference,
                    'is_ai_generated': note.is_ai_generated,
                    'created_at': note.created_at.isoformat(),
                    'updated_at': note.updated_at.isoformat(),
                    'course_id': note.course_id,
                    'tags': tags
                })
            
            return jsonify({'notes': result}), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving notes: {str(e)}")
            return jsonify({'error': 'Failed to retrieve notes'}), 500
    
    @login_required
    def get_note(self, note_id):
        """Get a specific note."""
        try:
            # Get the note
            note = Note.query.filter_by(id=note_id, user_id=current_user.id).first()
            
            if not note:
                return jsonify({'error': 'Note not found'}), 404
            
            # Get tags for the note
            tags = [tag.name for tag in note.tags]
            
            # Format response
            result = {
                'id': note.id,
                'title': note.title,
                'content': note.content,
                'source_type': note.source_type,
                'source_reference': note.source_reference,
                'is_ai_generated': note.is_ai_generated,
                'created_at': note.created_at.isoformat(),
                'updated_at': note.updated_at.isoformat(),
                'course_id': note.course_id,
                'tags': tags
            }
            
            return jsonify(result), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving note: {str(e)}")
            return jsonify({'error': 'Failed to retrieve note'}), 500
    
    @login_required
    def create_note(self):
        """Create a new note."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'title' not in data or 'content' not in data:
                return jsonify({'error': 'Title and content are required'}), 400
            
            # Create new note
            note = Note(
                title=data['title'],
                content=data['content'],
                source_type=data.get('source_type'),
                source_reference=data.get('source_reference'),
                is_ai_generated=data.get('is_ai_generated', False),
                user_id=current_user.id,
                course_id=data.get('course_id')
            )
            
            # Add note to database
            db.session.add(note)
            db.session.flush()  # Flush to get the note ID
            
            # Add tags if provided
            if 'tags' in data and isinstance(data['tags'], list):
                for tag_name in data['tags']:
                    tag = NoteTag(name=tag_name, note_id=note.id)
                    db.session.add(tag)
            
            # Commit changes
            db.session.commit()
            
            return jsonify({
                'message': 'Note created successfully',
                'note_id': note.id
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error creating note: {str(e)}")
            return jsonify({'error': 'Failed to create note'}), 500
    
    @login_required
    def update_note(self, note_id):
        """Update a specific note."""
        try:
            # Get the note
            note = Note.query.filter_by(id=note_id, user_id=current_user.id).first()
            
            if not note:
                return jsonify({'error': 'Note not found'}), 404
            
            # Get request data
            data = request.get_json()
            
            # Update note fields
            if 'title' in data:
                note.title = data['title']
            
            if 'content' in data:
                note.content = data['content']
            
            if 'source_type' in data:
                note.source_type = data['source_type']
            
            if 'source_reference' in data:
                note.source_reference = data['source_reference']
            
            if 'course_id' in data:
                note.course_id = data['course_id']
            
            # Update tags if provided
            if 'tags' in data and isinstance(data['tags'], list):
                # Remove existing tags
                NoteTag.query.filter_by(note_id=note.id).delete()
                
                # Add new tags
                for tag_name in data['tags']:
                    tag = NoteTag(name=tag_name, note_id=note.id)
                    db.session.add(tag)
            
            # Commit changes
            db.session.commit()
            
            return jsonify({'message': 'Note updated successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error updating note: {str(e)}")
            return jsonify({'error': 'Failed to update note'}), 500
    
    @login_required
    def delete_note(self, note_id):
        """Delete a specific note."""
        try:
            # Get the note
            note = Note.query.filter_by(id=note_id, user_id=current_user.id).first()
            
            if not note:
                return jsonify({'error': 'Note not found'}), 404
            
            # Delete the note (cascade will delete tags)
            db.session.delete(note)
            db.session.commit()
            
            return jsonify({'message': 'Note deleted successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error deleting note: {str(e)}")
            return jsonify({'error': 'Failed to delete note'}), 500
    
    @login_required
    def generate_notes(self):
        """Generate notes from uploaded content."""
        try:
            # Check if the post request has the file part
            if 'file' not in request.files and 'text' not in request.form:
                return jsonify({'error': 'No file or text provided'}), 400
            
            content = ""
            source_type = request.form.get('source_type', 'upload')
            source_reference = ""
            
            # Get course information if provided
            course_id = request.form.get('course_id')
            course_name = None
            
            if course_id:
                course = Course.query.filter_by(id=course_id, user_id=current_user.id).first()
                if course:
                    course_name = course.name
            
            # Process file if provided
            if 'file' in request.files:
                file = request.files['file']
                
                if file.filename == '':
                    return jsonify({'error': 'No selected file'}), 400
                
                if file:
                    # Save the file
                    filename = secure_filename(file.filename)
                    unique_filename = f"{uuid.uuid4()}_{filename}"
                    upload_folder = current_app.config['UPLOAD_FOLDER']
                    file_path = os.path.join(upload_folder, unique_filename)
                    file.save(file_path)
                    
                    # Read the file content
                    with open(file_path, 'r') as f:
                        content = f.read()
                    
                    source_reference = filename
            
            # Use text content if provided
            elif 'text' in request.form:
                content = request.form['text']
            
            # Generate notes using the service
            generated_notes = self.note_service.generate_notes_from_text(content, course_name)
            
            # Extract key concepts
            key_concepts = self.note_service.extract_key_concepts(generated_notes['content'])
            
            # Suggest tags
            suggested_tags = self.note_service.suggest_tags(generated_notes['content'])
            
            # Create new note
            note = Note(
                title=generated_notes['title'],
                content=generated_notes['content'],
                source_type=source_type,
                source_reference=source_reference,
                is_ai_generated=True,
                user_id=current_user.id,
                course_id=course_id
            )
            
            # Add note to database
            db.session.add(note)
            db.session.flush()  # Flush to get the note ID
            
            # Add suggested tags
            for tag_name in suggested_tags:
                tag = NoteTag(name=tag_name, note_id=note.id)
                db.session.add(tag)
            
            # Commit changes
            db.session.commit()
            
            return jsonify({
                'message': 'Notes generated successfully',
                'note_id': note.id,
                'title': note.title,
                'key_concepts': key_concepts,
                'tags': suggested_tags
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error generating notes: {str(e)}")
            return jsonify({'error': f'Failed to generate notes: {str(e)}'}), 500
