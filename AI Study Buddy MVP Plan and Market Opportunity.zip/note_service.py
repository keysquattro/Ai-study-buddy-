"""
AI service for note-taking functionality in the AI Study Buddy application.
"""
import os
import openai
from flask import current_app

class NoteService:
    """Service for AI-powered note-taking features."""
    
    def __init__(self):
        """Initialize the note service with API key."""
        self.api_key = os.environ.get("OPENAI_API_KEY")
        openai.api_key = self.api_key
    
    def generate_notes_from_text(self, text, course_name=None):
        """
        Generate structured notes from raw text content.
        
        Args:
            text (str): The raw text content from lecture, reading, etc.
            course_name (str, optional): The name of the course for context.
            
        Returns:
            dict: A dictionary containing the generated notes with title and content.
        """
        try:
            # Create a prompt for the OpenAI API
            prompt = self._create_notes_prompt(text, course_name)
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an expert note-taking assistant for students. Your task is to organize raw lecture or reading content into clear, structured notes with headings, subheadings, bullet points, and highlighting of key concepts."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=2000,
                temperature=0.3
            )
            
            # Extract the generated notes
            notes_content = response.choices[0].message.content
            
            # Generate a title for the notes
            title_prompt = f"Generate a concise, descriptive title for these notes:\n\n{notes_content[:500]}..."
            title_response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Generate a concise, descriptive title for student notes."},
                    {"role": "user", "content": title_prompt}
                ],
                max_tokens=50,
                temperature=0.3
            )
            
            title = title_response.choices[0].message.content.strip().replace('"', '')
            
            return {
                "title": title,
                "content": notes_content,
                "is_ai_generated": True
            }
            
        except Exception as e:
            current_app.logger.error(f"Error generating notes: {str(e)}")
            return {
                "title": "Error in Note Generation",
                "content": f"An error occurred while generating notes: {str(e)}",
                "is_ai_generated": True
            }
    
    def extract_key_concepts(self, notes_content):
        """
        Extract key concepts and definitions from notes.
        
        Args:
            notes_content (str): The content of the notes.
            
        Returns:
            list: A list of key concepts and their definitions.
        """
        try:
            prompt = f"Extract the key concepts and their definitions from these notes:\n\n{notes_content}"
            
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Extract key concepts and their definitions from student notes. Format as a list of concept: definition pairs."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000,
                temperature=0.3
            )
            
            concepts_text = response.choices[0].message.content
            
            # Parse the response into a list of concepts
            concepts = []
            for line in concepts_text.split('\n'):
                if ':' in line:
                    parts = line.split(':', 1)
                    concept = parts[0].strip()
                    definition = parts[1].strip()
                    concepts.append({"concept": concept, "definition": definition})
            
            return concepts
            
        except Exception as e:
            current_app.logger.error(f"Error extracting key concepts: {str(e)}")
            return []
    
    def suggest_tags(self, notes_content):
        """
        Suggest tags for categorizing notes.
        
        Args:
            notes_content (str): The content of the notes.
            
        Returns:
            list: A list of suggested tags.
        """
        try:
            prompt = f"Suggest 5-10 relevant tags for categorizing these notes:\n\n{notes_content[:1000]}..."
            
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Suggest relevant tags for categorizing student notes. Provide only the tags as a comma-separated list."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=100,
                temperature=0.3
            )
            
            tags_text = response.choices[0].message.content
            
            # Parse the response into a list of tags
            tags = [tag.strip() for tag in tags_text.replace('#', '').split(',')]
            
            return tags
            
        except Exception as e:
            current_app.logger.error(f"Error suggesting tags: {str(e)}")
            return []
    
    def _create_notes_prompt(self, text, course_name=None):
        """
        Create a prompt for the OpenAI API to generate notes.
        
        Args:
            text (str): The raw text content.
            course_name (str, optional): The name of the course.
            
        Returns:
            str: The prompt for the OpenAI API.
        """
        course_context = f" for the course '{course_name}'" if course_name else ""
        
        prompt = f"""
        Please organize the following raw content{course_context} into clear, structured notes.
        
        Format the notes with:
        1. Clear headings and subheadings
        2. Bullet points for key information
        3. Numbered lists for sequential steps or processes
        4. Bold or highlight important concepts, terms, and definitions
        5. Organize content logically by topic
        
        Here is the content to organize:
        
        {text}
        """
        
        return prompt
