"""
Controller for reminders functionality in the AI Study Buddy application.
"""
from flask import request, jsonify, current_app
from flask_login import current_user, login_required
from datetime import datetime

from app import db
from src.models.reminder import Reminder, Notification
from src.services.reminder_service import ReminderService

class ReminderController:
    """Controller for handling reminder-related requests."""
    
    def __init__(self):
        """Initialize the reminder controller."""
        self.reminder_service = ReminderService()
    
    @login_required
    def get_reminders(self):
        """Get all reminders for the current user."""
        try:
            # Get query parameters
            status = request.args.get('status')
            
            # Build query
            query = Reminder.query.filter_by(user_id=current_user.id)
            
            # Apply filters if provided
            if status:
                query = query.filter_by(status=status)
            
            # Execute query and get results
            reminders = query.order_by(Reminder.reminder_date.asc()).all()
            
            # Format response
            result = []
            for reminder in reminders:
                result.append({
                    'id': reminder.id,
                    'title': reminder.title,
                    'description': reminder.description,
                    'reminder_date': reminder.reminder_date.isoformat(),
                    'is_recurring': reminder.is_recurring,
                    'recurrence_pattern': reminder.recurrence_pattern,
                    'priority': reminder.priority,
                    'status': reminder.status,
                    'is_ai_suggested': reminder.is_ai_suggested,
                    'created_at': reminder.created_at.isoformat(),
                    'updated_at': reminder.updated_at.isoformat(),
                    'assignment_id': reminder.assignment_id,
                    'class_id': reminder.class_id
                })
            
            return jsonify({'reminders': result}), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving reminders: {str(e)}")
            return jsonify({'error': 'Failed to retrieve reminders'}), 500
    
    @login_required
    def get_reminder(self, reminder_id):
        """Get a specific reminder."""
        try:
            # Get the reminder
            reminder = Reminder.query.filter_by(id=reminder_id, user_id=current_user.id).first()
            
            if not reminder:
                return jsonify({'error': 'Reminder not found'}), 404
            
            # Format response
            result = {
                'id': reminder.id,
                'title': reminder.title,
                'description': reminder.description,
                'reminder_date': reminder.reminder_date.isoformat(),
                'is_recurring': reminder.is_recurring,
                'recurrence_pattern': reminder.recurrence_pattern,
                'priority': reminder.priority,
                'status': reminder.status,
                'is_ai_suggested': reminder.is_ai_suggested,
                'created_at': reminder.created_at.isoformat(),
                'updated_at': reminder.updated_at.isoformat(),
                'assignment_id': reminder.assignment_id,
                'class_id': reminder.class_id
            }
            
            return jsonify(result), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving reminder: {str(e)}")
            return jsonify({'error': 'Failed to retrieve reminder'}), 500
    
    @login_required
    def create_reminder(self):
        """Create a new reminder."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'title' not in data or 'reminder_date' not in data:
                return jsonify({'error': 'Title and reminder date are required'}), 400
            
            # Create new reminder
            reminder = Reminder(
                title=data['title'],
                description=data.get('description', ''),
                reminder_date=data['reminder_date'],
                is_recurring=data.get('is_recurring', False),
                recurrence_pattern=data.get('recurrence_pattern'),
                priority=data.get('priority', 2),
                status=data.get('status', 'Active'),
                is_ai_suggested=data.get('is_ai_suggested', False),
                user_id=current_user.id,
                assignment_id=data.get('assignment_id'),
                class_id=data.get('class_id')
            )
            
            # Add reminder to database
            db.session.add(reminder)
            db.session.commit()
            
            return jsonify({
                'message': 'Reminder created successfully',
                'reminder_id': reminder.id
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error creating reminder: {str(e)}")
            return jsonify({'error': 'Failed to create reminder'}), 500
    
    @login_required
    def update_reminder(self, reminder_id):
        """Update a specific reminder."""
        try:
            # Get the reminder
            reminder = Reminder.query.filter_by(id=reminder_id, user_id=current_user.id).first()
            
            if not reminder:
                return jsonify({'error': 'Reminder not found'}), 404
            
            # Get request data
            data = request.get_json()
            
            # Update reminder fields
            if 'title' in data:
                reminder.title = data['title']
            
            if 'description' in data:
                reminder.description = data['description']
            
            if 'reminder_date' in data:
                reminder.reminder_date = data['reminder_date']
            
            if 'is_recurring' in data:
                reminder.is_recurring = data['is_recurring']
            
            if 'recurrence_pattern' in data:
                reminder.recurrence_pattern = data['recurrence_pattern']
            
            if 'priority' in data:
                reminder.priority = data['priority']
            
            if 'status' in data:
                reminder.status = data['status']
            
            if 'assignment_id' in data:
                reminder.assignment_id = data['assignment_id']
            
            if 'class_id' in data:
                reminder.class_id = data['class_id']
            
            # Commit changes
            db.session.commit()
            
            return jsonify({'message': 'Reminder updated successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error updating reminder: {str(e)}")
            return jsonify({'error': 'Failed to update reminder'}), 500
    
    @login_required
    def delete_reminder(self, reminder_id):
        """Delete a specific reminder."""
        try:
            # Get the reminder
            reminder = Reminder.query.filter_by(id=reminder_id, user_id=current_user.id).first()
            
            if not reminder:
                return jsonify({'error': 'Reminder not found'}), 404
            
            # Delete the reminder
            db.session.delete(reminder)
            db.session.commit()
            
            return jsonify({'message': 'Reminder deleted successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error deleting reminder: {str(e)}")
            return jsonify({'error': 'Failed to delete reminder'}), 500
    
    @login_required
    def get_upcoming_reminders(self):
        """Get upcoming reminders for the current user."""
        try:
            # Get current date and time
            now = datetime.now()
            
            # Get reminders that are due in the future and are active
            reminders = Reminder.query.filter(
                Reminder.user_id == current_user.id,
                Reminder.reminder_date >= now,
                Reminder.status == 'Active'
            ).order_by(Reminder.reminder_date.asc()).all()
            
            # Format response
            result = []
            for reminder in reminders:
                result.append({
                    'id': reminder.id,
                    'title': reminder.title,
                    'description': reminder.description,
                    'reminder_date': reminder.reminder_date.isoformat(),
                    'is_recurring': reminder.is_recurring,
                    'recurrence_pattern': reminder.recurrence_pattern,
                    'priority': reminder.priority,
                    'is_ai_suggested': reminder.is_ai_suggested,
                    'assignment_id': reminder.assignment_id,
                    'class_id': reminder.class_id
                })
            
            return jsonify({'reminders': result}), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving upcoming reminders: {str(e)}")
            return jsonify({'error': 'Failed to retrieve upcoming reminders'}), 500
    
    @login_required
    def suggest_reminders(self):
        """Get AI-suggested reminders based on user's schedule and assignments."""
        try:
            # Get user data for reminder suggestions
            # This would typically include assignments, classes, and existing reminders
            
            # Get assignments
            from src.models.assignment import Assignment
            assignments = Assignment.query.filter_by(user_id=current_user.id).all()
            assignments_data = [
                {
                    'title': a.title,
                    'due_date': a.due_date,
                    'status': a.status,
                    'course_id': a.course_id
                }
                for a in assignments
            ]
            
            # Get classes
            from src.models.scheduler import Class, ClassSession
            classes = Class.query.filter_by(user_id=current_user.id).all()
            classes_data = []
            for c in classes:
                sessions = ClassSession.query.filter_by(class_id=c.id).all()
                sessions_data = [
                    {
                        'day_of_week': s.day_of_week,
                        'start_time': s.start_time.strftime('%H:%M'),
                        'end_time': s.end_time.strftime('%H:%M')
                    }
                    for s in sessions
                ]
                classes_data.append({
                    'title': c.title,
                    'start_date': c.start_date,
                    'end_date': c.end_date,
                    'sessions': sessions_data
                })
            
            # Get existing reminders
            existing_reminders = Reminder.query.filter_by(user_id=current_user.id).all()
            reminders_data = [
                {
                    'title': r.title,
                    'reminder_date': r.reminder_date,
                    'status': r.status
                }
                for r in existing_reminders
            ]
            
            # Prepare user data for the service
            user_data = {
                'assignments': assignments_data,
                'classes': classes_data,
                'reminders': reminders_data
            }
            
            # Get reminder suggestions using the service
            suggested_reminders = self.reminder_service.suggest_reminders(user_data)
            
            # Save suggested reminders to database
            saved_reminders = []
            for suggestion in suggested_reminders:
                reminder = Reminder(
                    title=suggestion['title'],
                    description=suggestion.get('description', ''),
                    reminder_date=suggestion['reminder_date'],
                    is_recurring=False,
                    priority=2,  # Medium priority by default
                    status='Active',
                    is_ai_suggested=True,
                    user_id=current_user.id
                )
                
                db.session.add(reminder)
                db.session.flush()  # Flush to get the reminder ID
                
                saved_reminders.append({
                    'id': reminder.id,
                    'title': reminder.title,
                    'description': reminder.description,
                    'reminder_date': reminder.reminder_date.isoformat(),
                    'is_ai_suggested': True
                })
            
            # Commit changes
            db.session.commit()
            
            return jsonify({
                'message': f'{len(saved_reminders)} reminders suggested and saved',
                'reminders': saved_reminders
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error suggesting reminders: {str(e)}")
            return jsonify({'error': f'Failed to suggest reminders: {str(e)}'}), 500
    
    @login_required
    def prioritize_tasks(self):
        """Prioritize tasks based on deadlines, importance, and estimated effort."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'tasks' not in data or not isinstance(data['tasks'], list):
                return jsonify({'error': 'Tasks list is required'}), 400
            
            # Prioritize tasks using the service
            prioritized_tasks = self.reminder_service.prioritize_tasks(data['tasks'])
            
            return jsonify({
                'prioritized_tasks': prioritized_tasks
            }), 200
            
        except Exception as e:
            current_app.logger.error(f"Error prioritizing tasks: {str(e)}")
            return jsonify({'error': f'Failed to prioritize tasks: {str(e)}'}), 500
    
    @login_required
    def generate_study_schedule(self):
        """Generate an optimal study schedule based on assignments, classes, and preferences."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data:
                return jsonify({'error': 'Request data is required'}), 400
            
            # Get assignments, classes, and preferences from request
            assignments = data.get('assignments', [])
            classes = data.get('classes', [])
            preferences = data.get('preferences', {})
            
            # Generate study schedule using the service
            schedule = self.reminder_service.generate_study_schedule(assignments, classes, preferences)
            
            return jsonify(schedule), 200
            
        except Exception as e:
            current_app.logger.error(f"Error generating study schedule: {str(e)}")
            return jsonify({'error': f'Failed to generate study schedule: {str(e)}'}), 500
