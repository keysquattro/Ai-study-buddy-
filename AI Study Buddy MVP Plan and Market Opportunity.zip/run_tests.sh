#!/bin/bash

# Run all tests for the AI Study Buddy MVP
# This script will run unit tests, integration tests, and end-to-end tests

echo "Starting AI Study Buddy test suite..."
echo "====================================="

# Set up Python path to include project root
export PYTHONPATH=$PYTHONPATH:$(pwd)

# Create a test results directory
mkdir -p test_results

# Run unit tests
echo "Running unit tests..."
echo "--------------------"
python -m unittest discover -s tests -p "test_*_service.py" > test_results/unit_tests.log 2>&1
UNIT_RESULT=$?

if [ $UNIT_RESULT -eq 0 ]; then
    echo "✅ Unit tests passed successfully!"
else
    echo "❌ Unit tests failed. Check test_results/unit_tests.log for details."
fi

# Run integration tests
echo ""
echo "Running integration tests..."
echo "--------------------------"
python -m unittest tests/test_integration.py > test_results/integration_tests.log 2>&1
INTEGRATION_RESULT=$?

if [ $INTEGRATION_RESULT -eq 0 ]; then
    echo "✅ Integration tests passed successfully!"
else
    echo "❌ Integration tests failed. Check test_results/integration_tests.log for details."
fi

# Run end-to-end tests
echo ""
echo "Running end-to-end tests..."
echo "-------------------------"
python -m unittest tests/test_end_to_end.py > test_results/end_to_end_tests.log 2>&1
E2E_RESULT=$?

if [ $E2E_RESULT -eq 0 ]; then
    echo "✅ End-to-end tests passed successfully!"
else
    echo "❌ End-to-end tests failed. Check test_results/end_to_end_tests.log for details."
fi

# Overall result
echo ""
echo "Test Suite Summary"
echo "================="
if [ $UNIT_RESULT -eq 0 ] && [ $INTEGRATION_RESULT -eq 0 ] && [ $E2E_RESULT -eq 0 ]; then
    echo "🎉 All tests passed successfully!"
    exit 0
else
    echo "⚠️ Some tests failed. Check the logs for details."
    exit 1
fi
