"""
Controller for class scheduler functionality in the AI Study Buddy application.
"""
from flask import request, jsonify, current_app
from flask_login import current_user, login_required
from datetime import datetime

from app import db
from src.models.scheduler import Class, ClassSession, CalendarEvent
from src.services.scheduler_service import SchedulerService

class SchedulerController:
    """Controller for handling class scheduling requests."""
    
    def __init__(self):
        """Initialize the scheduler controller."""
        self.scheduler_service = SchedulerService()
    
    @login_required
    def get_classes(self):
        """Get all classes for the current user."""
        try:
            # Get query parameters
            course_id = request.args.get('course_id', type=int)
            
            # Build query
            query = Class.query.filter_by(user_id=current_user.id)
            
            # Apply filters if provided
            if course_id:
                query = query.filter_by(course_id=course_id)
            
            # Execute query and get results
            classes = query.order_by(Class.start_date.asc()).all()
            
            # Format response
            result = []
            for cls in classes:
                # Get sessions for the class
                sessions = []
                for session in cls.sessions:
                    sessions.append({
                        'id': session.id,
                        'day_of_week': session.day_of_week,
                        'start_time': session.start_time.strftime('%H:%M'),
                        'end_time': session.end_time.strftime('%H:%M'),
                        'is_online': session.is_online,
                        'meeting_link': session.meeting_link
                    })
                
                result.append({
                    'id': cls.id,
                    'title': cls.title,
                    'location': cls.location,
                    'instructor': cls.instructor,
                    'start_date': cls.start_date.isoformat(),
                    'end_date': cls.end_date.isoformat(),
                    'created_at': cls.created_at.isoformat(),
                    'updated_at': cls.updated_at.isoformat(),
                    'course_id': cls.course_id,
                    'sessions': sessions
                })
            
            return jsonify({'classes': result}), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving classes: {str(e)}")
            return jsonify({'error': 'Failed to retrieve classes'}), 500
    
    @login_required
    def get_class(self, class_id):
        """Get a specific class."""
        try:
            # Get the class
            cls = Class.query.filter_by(id=class_id, user_id=current_user.id).first()
            
            if not cls:
                return jsonify({'error': 'Class not found'}), 404
            
            # Get sessions for the class
            sessions = []
            for session in cls.sessions:
                sessions.append({
                    'id': session.id,
                    'day_of_week': session.day_of_week,
                    'start_time': session.start_time.strftime('%H:%M'),
                    'end_time': session.end_time.strftime('%H:%M'),
                    'is_online': session.is_online,
                    'meeting_link': session.meeting_link
                })
            
            # Format response
            result = {
                'id': cls.id,
                'title': cls.title,
                'location': cls.location,
                'instructor': cls.instructor,
                'start_date': cls.start_date.isoformat(),
                'end_date': cls.end_date.isoformat(),
                'created_at': cls.created_at.isoformat(),
                'updated_at': cls.updated_at.isoformat(),
                'course_id': cls.course_id,
                'sessions': sessions
            }
            
            return jsonify(result), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving class: {str(e)}")
            return jsonify({'error': 'Failed to retrieve class'}), 500
    
    @login_required
    def create_class(self):
        """Create a new class."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'title' not in data or 'start_date' not in data or 'end_date' not in data:
                return jsonify({'error': 'Title, start date, and end date are required'}), 400
            
            # Create new class
            cls = Class(
                title=data['title'],
                location=data.get('location'),
                instructor=data.get('instructor'),
                start_date=data['start_date'],
                end_date=data['end_date'],
                user_id=current_user.id,
                course_id=data.get('course_id')
            )
            
            # Add class to database
            db.session.add(cls)
            db.session.flush()  # Flush to get the class ID
            
            # Add sessions if provided
            sessions = []
            if 'sessions' in data and isinstance(data['sessions'], list):
                for session_data in data['sessions']:
                    if 'day_of_week' in session_data and 'start_time' in session_data and 'end_time' in session_data:
                        session = ClassSession(
                            day_of_week=session_data['day_of_week'],
                            start_time=session_data['start_time'],
                            end_time=session_data['end_time'],
                            is_online=session_data.get('is_online', False),
                            meeting_link=session_data.get('meeting_link'),
                            class_id=cls.id
                        )
                        db.session.add(session)
                        sessions.append({
                            'day_of_week': session_data['day_of_week'],
                            'start_time': session_data['start_time'],
                            'end_time': session_data['end_time']
                        })
            
            # Commit changes
            db.session.commit()
            
            return jsonify({
                'message': 'Class created successfully',
                'class_id': cls.id,
                'sessions': sessions
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error creating class: {str(e)}")
            return jsonify({'error': f'Failed to create class: {str(e)}'}), 500
    
    @login_required
    def update_class(self, class_id):
        """Update a specific class."""
        try:
            # Get the class
            cls = Class.query.filter_by(id=class_id, user_id=current_user.id).first()
            
            if not cls:
                return jsonify({'error': 'Class not found'}), 404
            
            # Get request data
            data = request.get_json()
            
            # Update class fields
            if 'title' in data:
                cls.title = data['title']
            
            if 'location' in data:
                cls.location = data['location']
            
            if 'instructor' in data:
                cls.instructor = data['instructor']
            
            if 'start_date' in data:
                cls.start_date = data['start_date']
            
            if 'end_date' in data:
                cls.end_date = data['end_date']
            
            if 'course_id' in data:
                cls.course_id = data['course_id']
            
            # Update sessions if provided
            if 'sessions' in data and isinstance(data['sessions'], list):
                # Remove existing sessions
                ClassSession.query.filter_by(class_id=cls.id).delete()
                
                # Add new sessions
                for session_data in data['sessions']:
                    if 'day_of_week' in session_data and 'start_time' in session_data and 'end_time' in session_data:
                        session = ClassSession(
                            day_of_week=session_data['day_of_week'],
                            start_time=session_data['start_time'],
                            end_time=session_data['end_time'],
                            is_online=session_data.get('is_online', False),
                            meeting_link=session_data.get('meeting_link'),
                            class_id=cls.id
                        )
                        db.session.add(session)
            
            # Commit changes
            db.session.commit()
            
            return jsonify({'message': 'Class updated successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error updating class: {str(e)}")
            return jsonify({'error': f'Failed to update class: {str(e)}'}), 500
    
    @login_required
    def delete_class(self, class_id):
        """Delete a specific class."""
        try:
            # Get the class
            cls = Class.query.filter_by(id=class_id, user_id=current_user.id).first()
            
            if not cls:
                return jsonify({'error': 'Class not found'}), 404
            
            # Delete the class (cascade will delete sessions)
            db.session.delete(cls)
            db.session.commit()
            
            return jsonify({'message': 'Class deleted successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error deleting class: {str(e)}")
            return jsonify({'error': f'Failed to delete class: {str(e)}'}), 500
    
    @login_required
    def get_calendar(self):
        """Get calendar view of classes and events."""
        try:
            # Get query parameters
            start_date = request.args.get('start_date')
            end_date = request.args.get('end_date')
            
            # Parse dates if provided
            if start_date:
                start_date = datetime.fromisoformat(start_date)
            else:
                start_date = datetime.now()
            
            if end_date:
                end_date = datetime.fromisoformat(end_date)
            else:
                end_date = start_date.replace(day=start_date.day + 30)  # Default to 30 days
            
            # Get classes that overlap with the date range
            classes = Class.query.filter(
                Class.user_id == current_user.id,
                Class.end_date >= start_date,
                Class.start_date <= end_date
            ).all()
            
            # Get one-time events in the date range
            events = CalendarEvent.query.filter(
                CalendarEvent.user_id == current_user.id,
                CalendarEvent.start_datetime >= start_date,
                CalendarEvent.end_datetime <= end_date
            ).all()
            
            # Format classes for calendar view
            class_events = []
            for cls in classes:
                for session in cls.sessions:
                    # Calculate the actual dates for each session within the range
                    session_dates = self._calculate_session_dates(
                        cls.start_date, cls.end_date, session.day_of_week, start_date, end_date
                    )
                    
                    for date in session_dates:
                        class_events.append({
                            'id': f"class_{cls.id}_{session.id}_{date.strftime('%Y%m%d')}",
                            'title': cls.title,
                            'start': f"{date.strftime('%Y-%m-%d')}T{session.start_time.strftime('%H:%M:%S')}",
                            'end': f"{date.strftime('%Y-%m-%d')}T{session.end_time.strftime('%H:%M:%S')}",
                            'location': cls.location,
                            'type': 'class',
                            'class_id': cls.id,
                            'course_id': cls.course_id,
                            'is_online': session.is_online,
                            'meeting_link': session.meeting_link
                        })
            
            # Format one-time events
            calendar_events = []
            for event in events:
                calendar_events.append({
                    'id': f"event_{event.id}",
                    'title': event.title,
                    'start': event.start_datetime.isoformat(),
                    'end': event.end_datetime.isoformat(),
                    'location': event.location,
                    'type': 'event',
                    'all_day': event.is_all_day,
                    'description': event.description
                })
            
            # Combine all events
            all_events = class_events + calendar_events
            
            return jsonify({
                'events': all_events,
                'start_date': start_date.isoformat(),
                'end_date': end_date.isoformat()
            }), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving calendar: {str(e)}")
            return jsonify({'error': f'Failed to retrieve calendar: {str(e)}'}), 500
    
    @login_required
    def import_schedule(self):
        """Import schedule from external source (iCal, CSV, etc.)."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'schedule_text' not in data:
                return jsonify({'error': 'Schedule text is required'}), 400
            
            # Parse the imported schedule
            format_type = data.get('format_type', 'ical')
            parsed_classes = self.scheduler_service.parse_imported_schedule(
                data['schedule_text'], format_type
            )
            
            # Save the parsed classes to the database
            saved_classes = []
            for cls_data in parsed_classes:
                # Create new class
                cls = Class(
                    title=cls_data['title'],
                    location=cls_data.get('location'),
                    instructor=cls_data.get('instructor'),
                    start_date=cls_data.get('start_date', datetime.now()),
                    end_date=cls_data.get('end_date', datetime.now().replace(month=datetime.now().month + 4)),
                    user_id=current_user.id
                )
                
                # Add class to database
                db.session.add(cls)
                db.session.flush()  # Flush to get the class ID
                
                # Add sessions
                sessions = []
                if 'sessions' in cls_data:
                    for session_data in cls_data['sessions']:
                        session = ClassSession(
                            day_of_week=session_data['day_of_week'],
                            start_time=session_data['start_time'],
                            end_time=session_data['end_time'],
                            is_online=session_data.get('is_online', False),
                            class_id=cls.id
                        )
                        db.session.add(session)
                        sessions.append({
                            'day_of_week': session_data['day_of_week'],
                            'start_time': str(session_data['start_time']),
                            'end_time': str(session_data['end_time'])
                        })
                
                saved_classes.append({
                    'id': cls.id,
                    'title': cls.title,
                    'location': cls.location,
                    'instructor': cls.instructor,
                    'sessions': sessions
                })
            
            # Commit changes
            db.session.commit()
            
            return jsonify({
                'message': f'{len(saved_classes)} classes imported successfully',
                'classes': saved_classes
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error importing schedule: {str(e)}")
            return jsonify({'error': f'Failed to import schedule: {str(e)}'}), 500
    
    @login_required
    def check_conflicts(self):
        """Check for scheduling conflicts."""
        try:
            # Get all classes for the user
            classes = Class.query.filter_by(user_id=current_user.id).all()
            
            # Format classes for conflict detection
            classes_data = []
            for cls in classes:
                sessions = []
                for session in cls.sessions:
                    sessions.append({
                        'day_of_week': session.day_of_week,
                        'start_time': session.start_time.strftime('%H:%M'),
                        'end_time': session.end_time.strftime('%H:%M')
                    })
                
                classes_data.append({
                    'title': cls.title,
                    'sessions': sessions
                })
            
            # Get all calendar events for the user
            events = CalendarEvent.query.filter_by(user_id=current_user.id).all()
            
            # Format events for conflict detection
            events_data = []
            for event in events:
                events_data.append({
                    'title': event.title,
                    'start_datetime': event.start_datetime,
                    'end_datetime': event.end_datetime
                })
            
            # Detect conflicts using the service
            conflicts = self.scheduler_service.detect_conflicts(classes_data, events_data)
            
            return jsonify({
                'conflicts': conflicts,
                'count': len(conflicts)
            }), 200
            
        except Exception as e:
            current_app.logger.error(f"Error checking conflicts: {str(e)}")
            return jsonify({'error': f'Failed to check conflicts: {str(e)}'}), 500
    
    @login_required
    def optimize_schedule(self):
        """Optimize class schedule based on user preferences."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'classes' not in data or 'preferences' not in data:
                return jsonify({'error': 'Classes and preferences are required'}), 400
            
            # Optimize schedule using the service
            optimized_schedule = self.scheduler_service.optimize_schedule(
                data['classes'], data['preferences']
            )
            
            return jsonify(optimized_schedule), 200
            
        except Exception as e:
            current_app.logger.error(f"Error optimizing schedule: {str(e)}")
            return jsonify({'error': f'Failed to optimize schedule: {str(e)}'}), 500
    
    def _calculate_session_dates(self, class_start, class_end, day_of_week, range_start, range_end):
        """
        Calculate the actual dates for a class session within a date range.
        
        Args:
            class_start (datetime): The start date of the class.
            class_end (datetime): The end date of the class.
            day_of_week (int): The day of the week for the session (0=Monday, 1=Tuesday, etc.).
            range_start (datetime): The start of the date range to consider.
            range_end (datetime): The end of the date range to consider.
            
        Returns:
            list: A list of datetime objects representing the session dates.
        """
        from datetime import timedelta
        
        # Ensure we're working with the later of class_start and range_start
        start_date = max(class_start, range_start)
        
        # Ensure we're working with the earlier of class_end and range_end
        end_date = min(class_end, range_end)
        
        # Find the first occurrence of the day of the week after start_date
        days_ahead = (day_of_week - start_date.weekday()) % 7
        first_date = start_date + timedelta(days=days_ahead)
        
        # If the first date is before the start date, add a week
        if first_date < start_date:
            first_date += timedelta(days=7)
        
        # Generate all dates
        dates = []
        current_date = first_date
        
        while current_date <= end_date:
            dates.append(current_date)
            current_date += timedelta(days=7)
        
        return dates
