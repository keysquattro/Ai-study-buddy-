# AI Study Buddy - Project Setup

This file contains instructions for setting up the development environment for the AI Study Buddy MVP.

## Prerequisites

- Python 3.8+
- Node.js 16+
- PostgreSQL 13+
- Redis (for Celery task queue)

## Backend Setup

1. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install Python dependencies:
```bash
pip install -r requirements.txt
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env file with your configuration
```

4. Initialize the database:
```bash
flask db init
flask db migrate
flask db upgrade
```

5. Run the development server:
```bash
flask run
```

## Frontend Setup

1. Navigate to the frontend directory:
```bash
cd frontend
```

2. Install Node.js dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm start
```

## Running with Docker

1. Build and start the containers:
```bash
docker-compose up -d
```

2. Access the application at http://localhost:3000

## Environment Variables

The following environment variables are required:

- `FLASK_APP`: Set to `app.py`
- `FLASK_ENV`: Set to `development`, `testing`, or `production`
- `SECRET_KEY`: Secret key for session management
- `DATABASE_URL`: PostgreSQL connection string
- `OPENAI_API_KEY`: API key for OpenAI services
- `REDIS_URL`: Redis connection string for Celery

## Development Workflow

1. Create a new branch for each feature
2. Write tests before implementing features
3. Run linters before committing code
4. Submit pull requests for code review

## Testing

1. Run backend tests:
```bash
pytest
```

2. Run frontend tests:
```bash
cd frontend && npm test
```

## Deployment

Deployment instructions are available in the `deployment.md` file.
