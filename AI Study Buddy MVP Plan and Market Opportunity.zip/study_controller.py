"""
Controller for study mode and flashcard functionality in the AI Study Buddy application.
"""
from flask import request, jsonify, current_app
from flask_login import current_user, login_required
from datetime import datetime

from app import db
from src.models.study import FlashcardSet, Flashcard, StudySession, FlashcardStudyRecord, StudySummary
from src.models.note import Note, Course
from src.services.study_service import StudyService

class StudyController:
    """Controller for handling study-related requests."""
    
    def __init__(self):
        """Initialize the study controller."""
        self.study_service = StudyService()
    
    @login_required
    def get_flashcard_sets(self):
        """Get all flashcard sets for the current user."""
        try:
            # Get query parameters
            course_id = request.args.get('course_id', type=int)
            
            # Build query
            query = FlashcardSet.query.filter_by(user_id=current_user.id)
            
            # Apply filters if provided
            if course_id:
                query = query.filter_by(course_id=course_id)
            
            # Execute query and get results
            flashcard_sets = query.order_by(FlashcardSet.created_at.desc()).all()
            
            # Format response
            result = []
            for flashcard_set in flashcard_sets:
                # Count flashcards in the set
                flashcard_count = Flashcard.query.filter_by(flashcard_set_id=flashcard_set.id).count()
                
                result.append({
                    'id': flashcard_set.id,
                    'title': flashcard_set.title,
                    'description': flashcard_set.description,
                    'is_ai_generated': flashcard_set.is_ai_generated,
                    'created_at': flashcard_set.created_at.isoformat(),
                    'updated_at': flashcard_set.updated_at.isoformat(),
                    'course_id': flashcard_set.course_id,
                    'flashcard_count': flashcard_count
                })
            
            return jsonify({'flashcard_sets': result}), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving flashcard sets: {str(e)}")
            return jsonify({'error': 'Failed to retrieve flashcard sets'}), 500
    
    @login_required
    def get_flashcard_set(self, set_id):
        """Get a specific flashcard set."""
        try:
            # Get the flashcard set
            flashcard_set = FlashcardSet.query.filter_by(id=set_id, user_id=current_user.id).first()
            
            if not flashcard_set:
                return jsonify({'error': 'Flashcard set not found'}), 404
            
            # Get flashcards in the set
            flashcards = Flashcard.query.filter_by(flashcard_set_id=flashcard_set.id).all()
            
            # Format flashcards
            formatted_flashcards = []
            for flashcard in flashcards:
                formatted_flashcards.append({
                    'id': flashcard.id,
                    'front_content': flashcard.front_content,
                    'back_content': flashcard.back_content,
                    'difficulty': flashcard.difficulty,
                    'created_at': flashcard.created_at.isoformat()
                })
            
            # Format response
            result = {
                'id': flashcard_set.id,
                'title': flashcard_set.title,
                'description': flashcard_set.description,
                'is_ai_generated': flashcard_set.is_ai_generated,
                'created_at': flashcard_set.created_at.isoformat(),
                'updated_at': flashcard_set.updated_at.isoformat(),
                'course_id': flashcard_set.course_id,
                'flashcards': formatted_flashcards
            }
            
            return jsonify(result), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving flashcard set: {str(e)}")
            return jsonify({'error': 'Failed to retrieve flashcard set'}), 500
    
    @login_required
    def create_flashcard_set(self):
        """Create a new flashcard set."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'title' not in data:
                return jsonify({'error': 'Title is required'}), 400
            
            # Create new flashcard set
            flashcard_set = FlashcardSet(
                title=data['title'],
                description=data.get('description', ''),
                is_ai_generated=data.get('is_ai_generated', False),
                user_id=current_user.id,
                course_id=data.get('course_id')
            )
            
            # Add flashcard set to database
            db.session.add(flashcard_set)
            db.session.flush()  # Flush to get the flashcard set ID
            
            # Add flashcards if provided
            flashcards = []
            if 'flashcards' in data and isinstance(data['flashcards'], list):
                for flashcard_data in data['flashcards']:
                    if 'front_content' in flashcard_data and 'back_content' in flashcard_data:
                        flashcard = Flashcard(
                            front_content=flashcard_data['front_content'],
                            back_content=flashcard_data['back_content'],
                            difficulty=flashcard_data.get('difficulty', 2),
                            flashcard_set_id=flashcard_set.id
                        )
                        db.session.add(flashcard)
                        flashcards.append({
                            'front_content': flashcard_data['front_content'],
                            'back_content': flashcard_data['back_content'],
                            'difficulty': flashcard_data.get('difficulty', 2)
                        })
            
            # Commit changes
            db.session.commit()
            
            return jsonify({
                'message': 'Flashcard set created successfully',
                'flashcard_set_id': flashcard_set.id,
                'flashcards': flashcards
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error creating flashcard set: {str(e)}")
            return jsonify({'error': f'Failed to create flashcard set: {str(e)}'}), 500
    
    @login_required
    def update_flashcard_set(self, set_id):
        """Update a specific flashcard set."""
        try:
            # Get the flashcard set
            flashcard_set = FlashcardSet.query.filter_by(id=set_id, user_id=current_user.id).first()
            
            if not flashcard_set:
                return jsonify({'error': 'Flashcard set not found'}), 404
            
            # Get request data
            data = request.get_json()
            
            # Update flashcard set fields
            if 'title' in data:
                flashcard_set.title = data['title']
            
            if 'description' in data:
                flashcard_set.description = data['description']
            
            if 'course_id' in data:
                flashcard_set.course_id = data['course_id']
            
            # Update flashcards if provided
            if 'flashcards' in data and isinstance(data['flashcards'], list):
                # Process each flashcard
                for flashcard_data in data['flashcards']:
                    # If ID is provided, update existing flashcard
                    if 'id' in flashcard_data:
                        flashcard = Flashcard.query.filter_by(id=flashcard_data['id'], flashcard_set_id=set_id).first()
                        if flashcard:
                            if 'front_content' in flashcard_data:
                                flashcard.front_content = flashcard_data['front_content']
                            if 'back_content' in flashcard_data:
                                flashcard.back_content = flashcard_data['back_content']
                            if 'difficulty' in flashcard_data:
                                flashcard.difficulty = flashcard_data['difficulty']
                    # Otherwise, create new flashcard
                    elif 'front_content' in flashcard_data and 'back_content' in flashcard_data:
                        flashcard = Flashcard(
                            front_content=flashcard_data['front_content'],
                            back_content=flashcard_data['back_content'],
                            difficulty=flashcard_data.get('difficulty', 2),
                            flashcard_set_id=set_id
                        )
                        db.session.add(flashcard)
            
            # Delete flashcards if provided
            if 'delete_flashcards' in data and isinstance(data['delete_flashcards'], list):
                for flashcard_id in data['delete_flashcards']:
                    flashcard = Flashcard.query.filter_by(id=flashcard_id, flashcard_set_id=set_id).first()
                    if flashcard:
                        db.session.delete(flashcard)
            
            # Commit changes
            db.session.commit()
            
            return jsonify({'message': 'Flashcard set updated successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error updating flashcard set: {str(e)}")
            return jsonify({'error': f'Failed to update flashcard set: {str(e)}'}), 500
    
    @login_required
    def delete_flashcard_set(self, set_id):
        """Delete a specific flashcard set."""
        try:
            # Get the flashcard set
            flashcard_set = FlashcardSet.query.filter_by(id=set_id, user_id=current_user.id).first()
            
            if not flashcard_set:
                return jsonify({'error': 'Flashcard set not found'}), 404
            
            # Delete the flashcard set (cascade will delete flashcards)
            db.session.delete(flashcard_set)
            db.session.commit()
            
            return jsonify({'message': 'Flashcard set deleted successfully'}), 200
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error deleting flashcard set: {str(e)}")
            return jsonify({'error': f'Failed to delete flashcard set: {str(e)}'}), 500
    
    @login_required
    def generate_summary(self):
        """Generate a summary from notes or uploaded content."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or ('content' not in data and 'note_id' not in data):
                return jsonify({'error': 'Content or note ID is required'}), 400
            
            content = ""
            note_id = None
            
            # Get content from note if note_id is provided
            if 'note_id' in data:
                note_id = data['note_id']
                note = Note.query.filter_by(id=note_id, user_id=current_user.id).first()
                
                if not note:
                    return jsonify({'error': 'Note not found'}), 404
                
                content = note.content
                course_id = note.course_id
            else:
                content = data['content']
                course_id = data.get('course_id')
            
            # Generate summary using the service
            max_length = data.get('max_length')
            summary = self.study_service.generate_summary(content, max_length)
            
            # Save summary to database
            study_summary = StudySummary(
                title=summary['title'],
                content=summary['content'],
                source_type='note' if note_id else 'custom',
                user_id=current_user.id,
                course_id=course_id,
                note_id=note_id
            )
            
            db.session.add(study_summary)
            db.session.commit()
            
            return jsonify({
                'message': 'Summary generated successfully',
                'summary_id': study_summary.id,
                'title': study_summary.title,
                'content': study_summary.content
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error generating summary: {str(e)}")
            return jsonify({'error': f'Failed to generate summary: {str(e)}'}), 500
    
    @login_required
    def generate_flashcards(self):
        """Generate flashcards from notes or uploaded content."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or ('content' not in data and 'note_id' not in data):
                return jsonify({'error': 'Content or note ID is required'}), 400
            
            content = ""
            note_id = None
            course_id = None
            
            # Get content from note if note_id is provided
            if 'note_id' in data:
                note_id = data['note_id']
                note = Note.query.filter_by(id=note_id, user_id=current_user.id).first()
                
                if not note:
                    return jsonify({'error': 'Note not found'}), 404
                
                content = note.content
                course_id = note.course_id
            else:
                content = data['content']
                course_id = data.get('course_id')
            
            # Generate flashcards using the service
            num_cards = data.get('num_cards', 10)
            flashcards_data = self.study_service.generate_flashcards(content, num_cards)
            
            # Create new flashcard set
            flashcard_set = FlashcardSet(
                title=flashcards_data['title'],
                description=f"Generated from {'note' if note_id else 'custom content'}",
                is_ai_generated=True,
                user_id=current_user.id,
                course_id=course_id
            )
            
            # Add flashcard set to database
            db.session.add(flashcard_set)
            db.session.flush()  # Flush to get the flashcard set ID
            
            # Add flashcards
            for flashcard_data in flashcards_data['flashcards']:
                flashcard = Flashcard(
                    front_content=flashcard_data['front_content'],
                    back_content=flashcard_data['back_content'],
                    difficulty=flashcard_data.get('difficulty', 2),
                    flashcard_set_id=flashcard_set.id
                )
                db.session.add(flashcard)
            
            # Commit changes
            db.session.commit()
            
            return jsonify({
                'message': 'Flashcards generated successfully',
                'flashcard_set_id': flashcard_set.id,
                'title': flashcard_set.title,
                'flashcard_count': len(flashcards_data['flashcards'])
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error generating flashcards: {str(e)}")
            return jsonify({'error': f'Failed to generate flashcards: {str(e)}'}), 500
    
    @login_required
    def generate_quiz(self):
        """Generate quiz questions from notes or uploaded content."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or ('content' not in data and 'note_id' not in data):
                return jsonify({'error': 'Content or note ID is required'}), 400
            
            content = ""
            
            # Get content from note if note_id is provided
            if 'note_id' in data:
                note_id = data['note_id']
                note = Note.query.filter_by(id=note_id, user_id=current_user.id).first()
                
                if not note:
                    return jsonify({'error': 'Note not found'}), 404
                
                content = note.content
            else:
                content = data['content']
            
            # Generate quiz using the service
            num_questions = data.get('num_questions', 5)
            question_types = data.get('question_types')
            quiz = self.study_service.generate_quiz(content, num_questions, question_types)
            
            return jsonify({
                'title': quiz['title'],
                'questions': quiz['questions'],
                'created_at': quiz['created_at'].isoformat()
            }), 200
            
        except Exception as e:
            current_app.logger.error(f"Error generating quiz: {str(e)}")
            return jsonify({'error': f'Failed to generate quiz: {str(e)}'}), 500
    
    @login_required
    def record_study_session(self):
        """Record a study session."""
        try:
            # Get request data
            data = request.get_json()
            
            # Validate required fields
            if not data or 'flashcard_set_id' not in data:
                return jsonify({'error': 'Flashcard set ID is required'}), 400
            
            # Verify flashcard set exists and belongs to user
            flashcard_set = FlashcardSet.query.filter_by(
                id=data['flashcard_set_id'], 
                user_id=current_user.id
            ).first()
            
            if not flashcard_set:
                return jsonify({'error': 'Flashcard set not found'}), 404
            
            # Create new study session
            study_session = StudySession(
                start_time=data.get('start_time', datetime.now()),
                end_time=data.get('end_time'),
                duration_minutes=data.get('duration_minutes'),
                cards_studied=data.get('cards_studied', 0),
                correct_answers=data.get('correct_answers', 0),
                user_id=current_user.id,
                flashcard_set_id=data['flashcard_set_id']
            )
            
            # Add study session to database
            db.session.add(study_session)
            db.session.flush()  # Flush to get the study session ID
            
            # Add study records if provided
            if 'study_records' in data and isinstance(data['study_records'], list):
                for record_data in data['study_records']:
                    if 'flashcard_id' in record_data:
                        # Verify flashcard exists and belongs to the set
                        flashcard = Flashcard.query.filter_by(
                            id=record_data['flashcard_id'], 
                            flashcard_set_id=data['flashcard_set_id']
                        ).first()
                        
                        if flashcard:
                            # Calculate next review date using spaced repetition
                            # Get previous study records for this flashcard
                            previous_records = FlashcardStudyRecord.query.filter_by(
                                flashcard_id=record_data['flashcard_id']
                            ).order_by(FlashcardStudyRecord.created_at.asc()).all()
                            
                            # Convert to format expected by the service
                            flashcard_history = [
                                {
                                    'confidence_level': record.confidence_level,
                                    'created_at': record.created_at,
                                    'next_review_date': record.next_review_date
                                }
                                for record in previous_records
                            ]
                            
                            # Add current record to history
                            flashcard_history.append({
                                'confidence_level': record_data.get('confidence_level', 3),
                                'created_at': datetime.now()
                            })
                            
                            # Calculate next review date
                            next_review_date = self.study_service.calculate_spaced_repetition(flashcard_history)
                            
                            # Create study record
                            study_record = FlashcardStudyRecord(
                                is_correct=record_data.get('is_correct', False),
                                confidence_level=record_data.get('confidence_level', 3),
                                time_spent_seconds=record_data.get('time_spent_seconds', 0),
                                next_review_date=next_review_date,
                                flashcard_id=record_data['flashcard_id'],
                                study_session_id=study_session.id
                            )
                            
                            db.session.add(study_record)
            
            # Commit changes
            db.session.commit()
            
            return jsonify({
                'message': 'Study session recorded successfully',
                'study_session_id': study_session.id
            }), 201
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error recording study session: {str(e)}")
            return jsonify({'error': f'Failed to record study session: {str(e)}'}), 500
    
    @login_required
    def get_study_progress(self):
        """Get study progress for the current user."""
        try:
            # Get study sessions for the user
            study_sessions = StudySession.query.filter_by(user_id=current_user.id).all()
            
            # Get flashcard study records for the user
            flashcard_records = []
            for session in study_sessions:
                records = FlashcardStudyRecord.query.filter_by(study_session_id=session.id).all()
                for record in records:
                    flashcard = Flashcard.query.filter_by(id=record.flashcard_id).first()
                    if flashcard:
                        flashcard_records.append({
                            'record': record,
                            'flashcard': flashcard
                        })
            
            # Analyze study progress using the service
            progress = self.study_service.analyze_study_progress(study_sessions, flashcard_records)
            
            return jsonify(progress), 200
            
        except Exception as e:
            current_app.logger.error(f"Error retrieving study progress: {str(e)}")
            return jsonify({'error': f'Failed to retrieve study progress: {str(e)}'}), 500
