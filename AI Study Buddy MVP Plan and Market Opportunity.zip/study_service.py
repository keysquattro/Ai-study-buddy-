"""
AI service for study mode and flashcard functionality in the AI Study Buddy application.
"""
import os
import openai
import random
from datetime import datetime, timedelta
from flask import current_app

class StudyService:
    """Service for AI-powered study features."""
    
    def __init__(self):
        """Initialize the study service with API key."""
        self.api_key = os.environ.get("OPENAI_API_KEY")
        openai.api_key = self.api_key
    
    def generate_summary(self, content, max_length=None):
        """
        Generate a concise summary of the provided content.
        
        Args:
            content (str): The content to summarize.
            max_length (int, optional): Maximum length of the summary in words.
            
        Returns:
            dict: A dictionary containing the generated summary.
        """
        try:
            # Create a prompt for the OpenAI API
            length_instruction = f" in approximately {max_length} words" if max_length else ""
            
            prompt = f"""
            Create a comprehensive study summary{length_instruction} of the following content:
            
            {content[:4000]}  # Limit to first 4000 chars for API limits
            
            The summary should:
            1. Identify and explain key concepts
            2. Highlight important relationships between ideas
            3. Use clear, concise language
            4. Include relevant examples where appropriate
            5. Organize information logically
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an educational assistant that creates concise, informative summaries for students."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1500,
                temperature=0.4
            )
            
            # Extract the generated summary
            summary = response.choices[0].message.content
            
            # Generate a title for the summary
            title_prompt = f"Generate a concise, descriptive title for this study summary:\n\n{summary[:500]}..."
            title_response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Generate a concise, descriptive title for a study summary."},
                    {"role": "user", "content": title_prompt}
                ],
                max_tokens=50,
                temperature=0.3
            )
            
            title = title_response.choices[0].message.content.strip().replace('"', '')
            
            return {
                "title": title,
                "content": summary,
                "created_at": datetime.now()
            }
            
        except Exception as e:
            current_app.logger.error(f"Error generating summary: {str(e)}")
            return {
                "title": "Error in Summary Generation",
                "content": f"An error occurred while generating summary: {str(e)}",
                "created_at": datetime.now()
            }
    
    def generate_flashcards(self, content, num_cards=10):
        """
        Generate flashcards from the provided content.
        
        Args:
            content (str): The content to generate flashcards from.
            num_cards (int, optional): Number of flashcards to generate.
            
        Returns:
            dict: A dictionary containing the generated flashcards.
        """
        try:
            # Create a prompt for the OpenAI API
            prompt = f"""
            Create {num_cards} high-quality flashcards from the following content:
            
            {content[:4000]}  # Limit to first 4000 chars for API limits
            
            For each flashcard:
            1. Front side should contain a clear question, term, or concept
            2. Back side should contain a comprehensive answer, definition, or explanation
            3. Focus on the most important information
            4. Vary the difficulty level
            5. Use a mix of factual recall, conceptual understanding, and application questions
            
            Format each flashcard as:
            CARD [number]
            FRONT: [Question/Term/Concept]
            BACK: [Answer/Definition/Explanation]
            DIFFICULTY: [Easy/Medium/Hard]
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an educational assistant that creates effective flashcards for students."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=2000,
                temperature=0.5
            )
            
            # Extract the generated flashcards
            flashcards_text = response.choices[0].message.content
            
            # Parse the flashcards into a structured format
            flashcards = self._parse_flashcards(flashcards_text)
            
            # Generate a title for the flashcard set
            title_prompt = f"Generate a concise, descriptive title for a set of flashcards about:\n\n{content[:500]}..."
            title_response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Generate a concise, descriptive title for a flashcard set."},
                    {"role": "user", "content": title_prompt}
                ],
                max_tokens=50,
                temperature=0.3
            )
            
            title = title_response.choices[0].message.content.strip().replace('"', '')
            
            return {
                "title": title,
                "flashcards": flashcards,
                "created_at": datetime.now()
            }
            
        except Exception as e:
            current_app.logger.error(f"Error generating flashcards: {str(e)}")
            return {
                "title": "Error in Flashcard Generation",
                "flashcards": [],
                "created_at": datetime.now()
            }
    
    def generate_quiz(self, content, num_questions=5, question_types=None):
        """
        Generate a quiz from the provided content.
        
        Args:
            content (str): The content to generate quiz questions from.
            num_questions (int, optional): Number of questions to generate.
            question_types (list, optional): Types of questions to include (multiple_choice, true_false, short_answer).
            
        Returns:
            dict: A dictionary containing the generated quiz.
        """
        try:
            # Set default question types if not provided
            if not question_types:
                question_types = ["multiple_choice", "true_false", "short_answer"]
            
            # Create a prompt for the OpenAI API
            types_text = ", ".join(question_types)
            
            prompt = f"""
            Create a quiz with {num_questions} questions based on the following content:
            
            {content[:4000]}  # Limit to first 4000 chars for API limits
            
            Include the following question types: {types_text}
            
            For each question:
            1. Provide a clear, concise question
            2. For multiple-choice questions, include 4 options with the correct answer indicated
            3. For true/false questions, indicate the correct answer
            4. For short-answer questions, provide an example of a correct response
            5. Include a brief explanation of why the answer is correct
            
            Format each question as:
            QUESTION [number]: [Question text]
            TYPE: [Multiple Choice/True False/Short Answer]
            OPTIONS: [A. Option 1, B. Option 2, etc.] (for multiple choice only)
            ANSWER: [Correct answer]
            EXPLANATION: [Explanation of the correct answer]
            """
            
            # Call the OpenAI API
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an educational assistant that creates effective quiz questions for students."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=2000,
                temperature=0.5
            )
            
            # Extract the generated quiz
            quiz_text = response.choices[0].message.content
            
            # Parse the quiz into a structured format
            questions = self._parse_quiz_questions(quiz_text)
            
            # Generate a title for the quiz
            title_prompt = f"Generate a concise, descriptive title for a quiz about:\n\n{content[:500]}..."
            title_response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "Generate a concise, descriptive title for a quiz."},
                    {"role": "user", "content": title_prompt}
                ],
                max_tokens=50,
                temperature=0.3
            )
            
            title = title_response.choices[0].message.content.strip().replace('"', '')
            
            return {
                "title": title,
                "questions": questions,
                "created_at": datetime.now()
            }
            
        except Exception as e:
            current_app.logger.error(f"Error generating quiz: {str(e)}")
            return {
                "title": "Error in Quiz Generation",
                "questions": [],
                "created_at": datetime.now()
            }
    
    def calculate_spaced_repetition(self, flashcard_history):
        """
        Calculate the next review date for a flashcard using spaced repetition algorithm.
        
        Args:
            flashcard_history (list): List of study records for the flashcard.
            
        Returns:
            datetime: The next recommended review date.
        """
        try:
            # Simple implementation of SuperMemo-2 algorithm
            # https://www.supermemo.com/en/archives1990-2015/english/ol/sm2
            
            if not flashcard_history:
                # First time seeing the card
                return datetime.now() + timedelta(days=1)
            
            # Get the most recent study record
            latest_record = flashcard_history[-1]
            
            # Extract the confidence level (1-5)
            confidence = latest_record.get('confidence_level', 3)
            
            # Calculate the easiness factor (EF)
            if len(flashcard_history) == 1:
                ef = 2.5  # Initial easiness factor
            else:
                prev_ef = flashcard_history[-2].get('easiness_factor', 2.5)
                ef = max(1.3, prev_ef + (0.1 - (5 - confidence) * (0.08 + (5 - confidence) * 0.02)))
            
            # Calculate the interval
            if len(flashcard_history) == 1:
                if confidence < 3:
                    interval = 1  # Review again tomorrow
                else:
                    interval = 6  # Review in 6 days
            elif len(flashcard_history) == 2:
                if confidence < 3:
                    interval = 1  # Review again tomorrow
                else:
                    interval = 4  # Review in 4 days
            else:
                prev_interval = (flashcard_history[-1].get('next_review_date', datetime.now()) - 
                                flashcard_history[-2].get('created_at', datetime.now())).days
                interval = int(prev_interval * ef)
                
                if confidence < 3:
                    interval = 1  # Review again tomorrow
            
            # Calculate the next review date
            next_review_date = datetime.now() + timedelta(days=interval)
            
            return next_review_date
            
        except Exception as e:
            current_app.logger.error(f"Error calculating spaced repetition: {str(e)}")
            return datetime.now() + timedelta(days=1)  # Default to tomorrow
    
    def analyze_study_progress(self, study_sessions, flashcard_records):
        """
        Analyze study progress and provide insights.
        
        Args:
            study_sessions (list): List of study session records.
            flashcard_records (list): List of flashcard study records.
            
        Returns:
            dict: A dictionary containing study progress analysis.
        """
        try:
            # Calculate basic metrics
            total_sessions = len(study_sessions)
            total_time_minutes = sum(session.get('duration_minutes', 0) for session in study_sessions)
            total_cards_studied = sum(session.get('cards_studied', 0) for session in study_sessions)
            
            if total_cards_studied > 0:
                correct_answers = sum(session.get('correct_answers', 0) for session in study_sessions)
                accuracy_rate = (correct_answers / total_cards_studied) * 100
            else:
                accuracy_rate = 0
            
            # Group flashcard records by difficulty
            difficulty_counts = {1: 0, 2: 0, 3: 0}  # Easy, Medium, Hard
            for record in flashcard_records:
                flashcard = record.get('flashcard', {})
                difficulty = flashcard.get('difficulty', 2)
                difficulty_counts[difficulty] += 1
            
            # Calculate progress over time
            weekly_progress = {}
            for session in study_sessions:
                date = session.get('start_time', datetime.now())
                week = date.strftime('%Y-%U')  # Year and week number
                
                if week not in weekly_progress:
                    weekly_progress[week] = {
                        'sessions': 0,
                        'minutes': 0,
                        'cards': 0,
                        'correct': 0
                    }
                
                weekly_progress[week]['sessions'] += 1
                weekly_progress[week]['minutes'] += session.get('duration_minutes', 0)
                weekly_progress[week]['cards'] += session.get('cards_studied', 0)
                weekly_progress[week]['correct'] += session.get('correct_answers', 0)
            
            # Format the weekly progress for the response
            formatted_weekly_progress = []
            for week, data in weekly_progress.items():
                year, week_num = week.split('-')
                formatted_weekly_progress.append({
                    'year': year,
                    'week': week_num,
                    'sessions': data['sessions'],
                    'minutes': data['minutes'],
                    'cards': data['cards'],
                    'correct': data['correct'],
                    'accuracy': (data['correct'] / data['cards'] * 100) if data['cards'] > 0 else 0
                })
            
            # Sort by year and week
            formatted_weekly_progress.sort(key=lambda x: (x['year'], x['week']))
            
            return {
                'total_sessions': total_sessions,
                'total_time_minutes': total_time_minutes,
                'total_cards_studied': total_cards_studied,
                'accuracy_rate': accuracy_rate,
                'difficulty_distribution': difficulty_counts,
                'weekly_progress': formatted_weekly_progress,
                'analysis_date': datetime.now().strftime('%Y-%m-%d')
            }
            
        except Exception as e:
            current_app.logger.error(f"Error analyzing study progress: {str(e)}")
            return {
                'error': f"An error occurred while analyzing study progress: {str(e)}",
                'analysis_date': datetime.now().strftime('%Y-%m-%d')
            }
    
    def _parse_flashcards(self, flashcards_text):
        """
        Parse the flashcards text into a structured format.
        
        Args:
            flashcards_text (str): The text containing flashcard information.
            
        Returns:
            list: A list of flashcard dictionaries.
        """
        flashcards = []
        current_card = None
        
        for line in flashcards_text.split('\n'):
            line = line.strip()
            if not line:
                continue
                
            if line.startswith('CARD') or line.startswith('FLASHCARD'):
                if current_card and 'front_content' in current_card and 'back_content' in current_card:
                    flashcards.append(current_card)
                current_card = {}
            elif line.startswith('FRONT:') and current_card is not None:
                current_card['front_content'] = line.split(':', 1)[1].strip()
            elif line.startswith('BACK:') and current_card is not None:
                current_card['back_content'] = line.split(':', 1)[1].strip()
            elif line.startswith('DIFFICULTY:') and current_card is not None:
                difficulty_text = line.split(':', 1)[1].strip().lower()
                if 'easy' in difficulty_text:
                    current_card['difficulty'] = 1
                elif 'hard' in difficulty_text:
                    current_card['difficulty'] = 3
                else:
                    current_card['difficulty'] = 2
        
        if current_card and 'front_content' in current_card and 'back_content' in current_card:
            flashcards.append(current_card)
        
        return flashcards
    
    def _parse_quiz_questions(self, quiz_text):
        """
        Parse the quiz text into a structured format.
        
        Args:
            quiz_text (str): The text containing quiz questions.
            
        Returns:
            list: A list of question dictionaries.
        """
        questions = []
        current_question = None
        
        for line in quiz_text.split('\n'):
            line = line.strip()
            if not line:
                continue
                
            if line.startswith('QUESTION'):
                if current_question and 'text' in current_question:
                    questions.append(current_question)
                
                # Extract question number and text
                parts = line.split(':', 1)
                if len(parts) > 1:
                    question_text = parts[1].strip()
                    current_question = {'text': question_text}
                else:
                    current_question = {}
            elif line.startswith('TYPE:') and current_question is not None:
                question_type = line.split(':', 1)[1].strip().lower()
                if 'multiple choice' in question_type:
                    current_question['type'] = 'multiple_choice'
                elif 'true' in question_type and 'false' in question_type:
                    current_question['type'] = 'true_false'
                else:
                    current_question['type'] = 'short_answer'
            elif line.startswith('OPTIONS:') and current_question is not None:
                options_text = line.split(':', 1)[1].strip()
                options = []
                
                # Parse options (A. Option 1, B. Option 2, etc.)
                for option in options_text.split(','):
                    option = option.strip()
                    if option and '.' in option:
                        letter, text = option.split('.', 1)
                        options.append({
                            'letter': letter.strip(),
                            'text': text.strip()
                        })
                
                current_question['options'] = options
            elif line.startswith('ANSWER:') and current_question is not None:
                current_question['answer'] = line.split(':', 1)[1].strip()
            elif line.startswith('EXPLANATION:') and current_question is not None:
                current_question['explanation'] = line.split(':', 1)[1].strip()
        
        if current_question and 'text' in current_question:
            questions.append(current_question)
        
        return questions
