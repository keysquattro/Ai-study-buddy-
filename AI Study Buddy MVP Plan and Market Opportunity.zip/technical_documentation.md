# AI Study Buddy - Technical Documentation

## System Architecture

The AI Study Buddy MVP is built using a modern web application architecture with the following components:

### Backend Architecture

- **Framework**: Flask (Python)
- **Database**: PostgreSQL with SQLAlchemy ORM
- **Authentication**: JWT (JSON Web Tokens)
- **API**: RESTful API endpoints
- **AI Integration**: OpenAI API for intelligent features

### Frontend Architecture

- **Framework**: React.js
- **UI Components**: Material-UI
- **State Management**: React Context API and Hooks
- **Routing**: React Router
- **HTTP Client**: Axios

### System Components

1. **Core Services**:
   - NoteService: Handles note generation and management
   - HomeworkService: Provides homework assistance
   - ReminderService: Manages smart reminders
   - SchedulerService: Handles class scheduling
   - StudyService: Manages study materials and flashcards

2. **Controllers**:
   - Handle business logic
   - Process requests and responses
   - Coordinate between services and data models

3. **Data Models**:
   - User: Authentication and profile information
   - Note: Note content and metadata
   - Assignment: Homework assignments
   - Reminder: Smart reminders
   - ClassSchedule: Class scheduling information
   - StudyMaterial: Flashcards, summaries, and quizzes

4. **API Routes**:
   - Authentication endpoints
   - Feature-specific endpoints for each service
   - Dashboard and utility endpoints

## Database Schema

### Users Table
```
id: Integer (Primary Key)
username: String (Unique)
email: String (Unique)
password_hash: String
created_at: DateTime
updated_at: DateTime
```

### Notes Table
```
id: Integer (Primary Key)
user_id: Integer (Foreign Key -> Users.id)
title: String
content: Text
is_ai_generated: Boolean
tags: JSON
created_at: DateTime
updated_at: DateTime
course_id: Integer (Foreign Key -> Courses.id, Nullable)
```

### Assignments Table
```
id: Integer (Primary Key)
user_id: Integer (Foreign Key -> Users.id)
title: String
description: Text
due_date: DateTime
priority: Integer
status: String
created_at: DateTime
updated_at: DateTime
course_id: Integer (Foreign Key -> Courses.id, Nullable)
```

### Reminders Table
```
id: Integer (Primary Key)
user_id: Integer (Foreign Key -> Users.id)
title: String
description: Text
reminder_date: DateTime
is_recurring: Boolean
recurrence_pattern: JSON (Nullable)
priority: Integer
status: String
created_at: DateTime
updated_at: DateTime
assignment_id: Integer (Foreign Key -> Assignments.id, Nullable)
class_id: Integer (Foreign Key -> ClassSchedules.id, Nullable)
```

### ClassSchedules Table
```
id: Integer (Primary Key)
user_id: Integer (Foreign Key -> Users.id)
title: String
location: String
instructor: String
start_date: Date
end_date: Date
created_at: DateTime
updated_at: DateTime
```

### ClassSessions Table
```
id: Integer (Primary Key)
class_id: Integer (Foreign Key -> ClassSchedules.id)
day_of_week: Integer
start_time: Time
end_time: Time
is_online: Boolean
meeting_link: String (Nullable)
```

### StudyMaterials Table
```
id: Integer (Primary Key)
user_id: Integer (Foreign Key -> Users.id)
title: String
type: String (flashcards, summary, quiz)
content: JSON
is_ai_generated: Boolean
created_at: DateTime
updated_at: DateTime
course_id: Integer (Foreign Key -> Courses.id, Nullable)
```

### Courses Table
```
id: Integer (Primary Key)
user_id: Integer (Foreign Key -> Users.id)
name: String
description: Text (Nullable)
created_at: DateTime
updated_at: DateTime
```

## API Endpoints

### Authentication

- `POST /api/auth/register`: Register a new user
- `POST /api/auth/login`: Login and get JWT token
- `POST /api/auth/refresh`: Refresh JWT token
- `GET /api/auth/profile`: Get user profile
- `PUT /api/auth/profile`: Update user profile

### Notes

- `GET /api/notes`: Get all notes
- `GET /api/notes/:id`: Get a specific note
- `POST /api/notes`: Create a new note
- `PUT /api/notes/:id`: Update a note
- `DELETE /api/notes/:id`: Delete a note
- `POST /api/notes/generate`: Generate notes using AI
- `GET /api/notes/search`: Search notes

### Homework

- `GET /api/homework/assignments`: Get all assignments
- `GET /api/homework/assignments/:id`: Get a specific assignment
- `POST /api/homework/assignments`: Create a new assignment
- `PUT /api/homework/assignments/:id`: Update an assignment
- `DELETE /api/homework/assignments/:id`: Delete an assignment
- `POST /api/homework/assist`: Get homework assistance
- `POST /api/homework/citations`: Generate citations
- `POST /api/homework/grammar`: Check grammar and style

### Reminders

- `GET /api/reminders`: Get all reminders
- `GET /api/reminders/:id`: Get a specific reminder
- `POST /api/reminders`: Create a new reminder
- `PUT /api/reminders/:id`: Update a reminder
- `DELETE /api/reminders/:id`: Delete a reminder
- `POST /api/reminders/suggest`: Get AI-suggested reminders
- `POST /api/reminders/schedule`: Generate a study schedule

### Scheduler

- `GET /api/scheduler/classes`: Get all classes
- `GET /api/scheduler/classes/:id`: Get a specific class
- `POST /api/scheduler/classes`: Create a new class
- `PUT /api/scheduler/classes/:id`: Update a class
- `DELETE /api/scheduler/classes/:id`: Delete a class
- `GET /api/scheduler/conflicts`: Check for schedule conflicts
- `POST /api/scheduler/optimize`: Optimize class schedule
- `POST /api/scheduler/import`: Import schedule from text/CSV

### Study

- `GET /api/study/flashcards`: Get all flashcard sets
- `GET /api/study/flashcards/:id`: Get a specific flashcard set
- `POST /api/study/flashcards`: Create a new flashcard set
- `PUT /api/study/flashcards/:id`: Update a flashcard set
- `DELETE /api/study/flashcards/:id`: Delete a flashcard set
- `POST /api/study/flashcards/generate`: Generate flashcards using AI
- `GET /api/study/summaries`: Get all summaries
- `POST /api/study/summaries`: Create a new summary
- `POST /api/study/summaries/generate`: Generate a summary using AI
- `GET /api/study/quizzes`: Get all quizzes
- `POST /api/study/quizzes/generate`: Generate a quiz using AI

### Dashboard

- `GET /api/dashboard`: Get dashboard data

## AI Integration

The AI Study Buddy MVP integrates with OpenAI's API to provide intelligent features:

### NoteService

- Uses GPT-4 to generate structured notes from lecture content
- Extracts key concepts and important points
- Suggests relevant tags for organization

### HomeworkService

- Generates step-by-step explanations for problems
- Creates citations in various formats
- Checks grammar and writing style

### ReminderService

- Suggests smart reminders based on assignments and deadlines
- Prioritizes tasks based on due dates and importance
- Generates optimized study schedules

### SchedulerService

- Detects scheduling conflicts
- Optimizes class schedules based on preferences
- Parses imported schedules from various formats

### StudyService

- Generates flashcards from study materials
- Creates comprehensive summaries
- Builds quizzes with questions and answers
- Implements spaced repetition algorithms

## Security Considerations

- **Authentication**: JWT tokens with proper expiration
- **Authorization**: Role-based access control
- **Data Protection**: Input validation and sanitization
- **API Security**: Rate limiting and CORS configuration
- **Environment Variables**: Sensitive information stored in .env files
- **Password Security**: Bcrypt hashing for passwords

## Deployment

### Requirements

- Python 3.10+
- Node.js 16+
- PostgreSQL 13+
- OpenAI API key

### Development Setup

1. Clone the repository
2. Create and activate a virtual environment
3. Install backend dependencies: `pip install -r requirements.txt`
4. Install frontend dependencies: `cd frontend && npm install`
5. Set up environment variables in `.env` file
6. Initialize the database: `flask db upgrade`
7. Run the backend: `python app.py`
8. Run the frontend: `cd frontend && npm start`

### Production Deployment

1. Build the frontend: `cd frontend && npm run build`
2. Configure a production web server (Nginx, Apache)
3. Set up a WSGI server (Gunicorn, uWSGI)
4. Configure PostgreSQL for production
5. Set up SSL/TLS certificates
6. Implement monitoring and logging

## Testing

The AI Study Buddy MVP includes a comprehensive testing suite:

### Unit Tests

- Tests for all service classes
- Mock OpenAI API responses
- Validates core functionality

### Integration Tests

- Tests API endpoints
- Verifies database interactions
- Checks authentication flows

### End-to-End Tests

- Simulates complete user flows
- Tests feature interactions
- Validates UI components

### Running Tests

- Execute `./run_tests.sh` to run all tests
- Test results are stored in the `test_results` directory

## Performance Considerations

- **Database Indexing**: Optimized queries for frequently accessed data
- **Caching**: Implemented for AI-generated content
- **Pagination**: Used for large data sets
- **Asynchronous Processing**: For time-consuming AI operations
- **Frontend Optimization**: Code splitting and lazy loading

## Future Enhancements

- **Mobile Application**: Native mobile apps for iOS and Android
- **Offline Mode**: Support for offline note-taking and studying
- **Advanced Analytics**: Learning patterns and study effectiveness
- **Collaboration Features**: Group studying and note sharing
- **Integration with LMS**: Canvas, Blackboard, Moodle integration
- **Voice Input**: Speech-to-text for note-taking
- **OCR Capabilities**: Scan handwritten notes or textbooks
- **Custom AI Models**: Domain-specific models for better assistance

## Troubleshooting

### Common Issues

- **Database Connection Errors**: Check PostgreSQL configuration
- **OpenAI API Issues**: Verify API key and rate limits
- **JWT Authentication Failures**: Check token expiration and secret key
- **Frontend Build Problems**: Verify Node.js version and dependencies

### Logging

- Backend logs are stored in `logs/app.log`
- Frontend errors are logged to the browser console
- API request logs are available in the server logs

## Maintenance

- **Database Backups**: Scheduled daily
- **Dependency Updates**: Monthly review of package versions
- **Security Patches**: Applied as needed
- **Performance Monitoring**: Regular review of application metrics
