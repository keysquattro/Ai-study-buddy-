# AI Study Buddy MVP - Technology Stack

## Backend
- **Framework**: Flask (Python)
- **Database**: PostgreSQL
- **ORM**: SQLAlchemy
- **Authentication**: Flask-Login with JWT
- **Task Queue**: Celery with Redis (for background processing)

## Frontend
- **Framework**: React.js
- **UI Library**: Material-UI
- **State Management**: Redux
- **Routing**: React Router
- **Forms**: Formik with Yup validation

## AI/ML Components
- **LLM Integration**: OpenAI API (GPT-4)
- **NLP Processing**: Hugging Face Transformers
- **Text Analysis**: spaCy
- **Speech Recognition**: (Optional) Google Cloud Speech-to-Text

## DevOps
- **Containerization**: Docker
- **CI/CD**: GitHub Actions
- **Hosting**: AWS (EC2, RDS, S3)
- **Monitoring**: Sentry

## Testing
- **Backend Testing**: pytest
- **Frontend Testing**: Jest with React Testing Library
- **E2E Testing**: Cypress

## Additional Tools
- **API Documentation**: Swagger/OpenAPI
- **Code Formatting**: Black (Python), Prettier (JavaScript)
- **Linting**: flake8 (Python), ESLint (JavaScript)
- **Version Control**: Git with GitHub
