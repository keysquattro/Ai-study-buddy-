import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add the project root to the path so we can import our modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from src.models.reminder import Reminder
from src.models.scheduler import ClassSchedule

class TestEndToEnd(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()
        
        # Import db after app context is created
        from app import db
        self.db = db
        
        # Create all tables
        self.db.create_all()
        
        # Create a test user
        from src.models.user import User
        test_user = User(
            username='testuser',
            email='test@example.com'
        )
        test_user.set_password('password123')
        self.db.session.add(test_user)
        self.db.session.commit()
        
        # Store the user ID for later use
        self.user_id = test_user.id
        
        # Login and get token
        login_response = self.client.post('/api/auth/login', json={
            'email': 'test@example.com',
            'password': 'password123'
        })
        self.token = login_response.json['token']
        
    def tearDown(self):
        self.db.session.remove()
        self.db.drop_all()
        self.app_context.pop()
    
    def test_complete_user_flow(self):
        """Test a complete user flow through the application"""
        
        # 1. Create a class schedule
        create_class_response = self.client.post(
            '/api/scheduler/classes',
            json={
                'title': 'Calculus I',
                'location': 'Math Building, Room 101',
                'instructor': 'Dr. Smith',
                'start_date': '2025-01-15',
                'end_date': '2025-05-15',
                'sessions': [
                    {
                        'day_of_week': 1,  # Monday
                        'start_time': '09:00',
                        'end_time': '10:30',
                        'is_online': False
                    },
                    {
                        'day_of_week': 3,  # Wednesday
                        'start_time': '09:00',
                        'end_time': '10:30',
                        'is_online': False
                    }
                ]
            },
            headers={'Authorization': f'Bearer {self.token}'}
        )
        self.assertEqual(create_class_response.status_code, 201)
        class_id = create_class_response.json['id']
        
        # 2. Create a homework assignment
        create_assignment_response = self.client.post(
            '/api/homework/assignments',
            json={
                'title': 'Calculus Problem Set 1',
                'description': 'Complete problems 1-20 on page 35',
                'due_date': '2025-03-25T23:59:00',
                'priority': 2,
                'status': 'Not Started',
                'course_id': class_id
            },
            headers={'Authorization': f'Bearer {self.token}'}
        )
        self.assertEqual(create_assignment_response.status_code, 201)
        assignment_id = create_assignment_response.json['id']
        
        # 3. Create a reminder for the assignment
        create_reminder_response = self.client.post(
            '/api/reminders',
            json={
                'title': 'Start Calculus Homework',
                'description': 'Begin working on Calculus Problem Set 1',
                'reminder_date': '2025-03-22T14:00:00',
                'is_recurring': False,
                'priority': 2,
                'status': 'Active',
                'assignment_id': assignment_id,
                'class_id': class_id
            },
            headers={'Authorization': f'Bearer {self.token}'}
        )
        self.assertEqual(create_reminder_response.status_code, 201)
        
        # 4. Get AI assistance for the homework
        with patch('src.services.homework_service.openai') as mock_openai:
            # Mock the OpenAI API response
            mock_response = MagicMock()
            mock_response.choices[0].message.content = """
            {
                "explanation": "To solve limits, we can use direct substitution if the function is continuous at that point. Otherwise, we need to use algebraic manipulation, factoring, or other techniques to simplify the expression.",
                "steps": [
                    "Identify if direct substitution works",
                    "If not, try algebraic manipulation",
                    "Look for opportunities to factor or simplify",
                    "Apply limit laws when appropriate"
                ]
            }
            """
            mock_openai.ChatCompletion.create.return_value = mock_response
            
            homework_assistance_response = self.client.post(
                '/api/homework/assist',
                json={
                    'problem': 'How do I solve limits in calculus?',
                    'assignment_id': assignment_id
                },
                headers={'Authorization': f'Bearer {self.token}'}
            )
            self.assertEqual(homework_assistance_response.status_code, 200)
            self.assertIn('explanation', homework_assistance_response.json)
        
        # 5. Create study materials based on the homework
        with patch('src.services.study_service.openai') as mock_openai:
            # Mock the OpenAI API response
            mock_response = MagicMock()
            mock_response.choices[0].message.content = """
            {
                "summary": "Limits are a fundamental concept in calculus that describe the behavior of a function as its input approaches a certain value. They form the basis for differentiation and integration.",
                "key_points": [
                    "Limits describe function behavior as x approaches a value",
                    "Direct substitution works for continuous functions",
                    "Algebraic manipulation is needed for indeterminate forms",
                    "Limits are the foundation of differential calculus"
                ]
            }
            """
            mock_openai.ChatCompletion.create.return_value = mock_response
            
            create_summary_response = self.client.post(
                '/api/study/summaries',
                json={
                    'title': 'Limits in Calculus',
                    'content': 'Limits describe the behavior of a function as its input approaches a certain value.',
                    'course_id': class_id
                },
                headers={'Authorization': f'Bearer {self.token}'}
            )
            self.assertEqual(create_summary_response.status_code, 201)
        
        # 6. Check for schedule conflicts
        with patch('src.services.scheduler_service.openai') as mock_openai:
            # Mock the OpenAI API response
            mock_response = MagicMock()
            mock_response.choices[0].message.content = "[]"  # No conflicts
            mock_openai.ChatCompletion.create.return_value = mock_response
            
            check_conflicts_response = self.client.get(
                '/api/scheduler/conflicts',
                headers={'Authorization': f'Bearer {self.token}'}
            )
            self.assertEqual(check_conflicts_response.status_code, 200)
        
        # 7. Get dashboard data
        dashboard_response = self.client.get(
            '/api/dashboard',
            headers={'Authorization': f'Bearer {self.token}'}
        )
        self.assertEqual(dashboard_response.status_code, 200)
        self.assertIn('upcoming_assignments', dashboard_response.json)
        self.assertIn('upcoming_reminders', dashboard_response.json)
        self.assertIn('class_schedule', dashboard_response.json)
        
        # 8. Update assignment status
        update_assignment_response = self.client.put(
            f'/api/homework/assignments/{assignment_id}',
            json={
                'status': 'In Progress'
            },
            headers={'Authorization': f'Bearer {self.token}'}
        )
        self.assertEqual(update_assignment_response.status_code, 200)
        self.assertEqual(update_assignment_response.json['status'], 'In Progress')
        
        # 9. Get all study materials
        study_materials_response = self.client.get(
            '/api/study/summaries',
            headers={'Authorization': f'Bearer {self.token}'}
        )
        self.assertEqual(study_materials_response.status_code, 200)
        self.assertTrue(len(study_materials_response.json) > 0)

if __name__ == '__main__':
    unittest.main()
