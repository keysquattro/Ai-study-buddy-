import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add the project root to the path so we can import our modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from src.models.user import User
from src.models.note import Note

class TestIntegration(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.client = self.app.test_client()
        self.app_context = self.app.app_context()
        self.app_context.push()
        
        # Import db after app context is created
        from app import db
        self.db = db
        
        # Create all tables
        self.db.create_all()
        
        # Create a test user
        test_user = User(
            username='testuser',
            email='test@example.com'
        )
        test_user.set_password('password123')
        self.db.session.add(test_user)
        self.db.session.commit()
        
        # Store the user ID for later use
        self.user_id = test_user.id
        
    def tearDown(self):
        self.db.session.remove()
        self.db.drop_all()
        self.app_context.pop()
    
    @patch('src.services.note_service.openai')
    def test_note_creation_and_retrieval(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        {
            "content": "# Lecture Notes: Introduction to Python\n\n## Key Concepts\n- Python is a high-level, interpreted programming language\n- Python emphasizes code readability\n- Python supports multiple programming paradigms\n\n## Important Points\n1. Created by Guido van Rossum in 1991\n2. Named after Monty Python\n3. Uses indentation for code blocks\n\n## Summary\nPython is widely used in data science, web development, and automation.",
            "key_concepts": ["Python programming language", "Code readability", "Multiple programming paradigms", "Guido van Rossum", "Data science applications"]
        }
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Login the test user
        login_response = self.client.post('/api/auth/login', json={
            'email': 'test@example.com',
            'password': 'password123'
        })
        self.assertEqual(login_response.status_code, 200)
        token = login_response.json['token']
        
        # Create a new note
        create_note_response = self.client.post(
            '/api/notes',
            json={
                'title': 'Introduction to Python',
                'content': 'Python is a programming language created by Guido van Rossum.',
                'tags': ['python', 'programming'],
                'is_ai_generated': False
            },
            headers={'Authorization': f'Bearer {token}'}
        )
        self.assertEqual(create_note_response.status_code, 201)
        note_id = create_note_response.json['id']
        
        # Get the created note
        get_note_response = self.client.get(
            f'/api/notes/{note_id}',
            headers={'Authorization': f'Bearer {token}'}
        )
        self.assertEqual(get_note_response.status_code, 200)
        self.assertEqual(get_note_response.json['title'], 'Introduction to Python')
        
        # Generate AI notes
        generate_notes_response = self.client.post(
            '/api/notes/generate',
            json={
                'content': 'Python is a programming language created by Guido van Rossum.'
            },
            headers={'Authorization': f'Bearer {token}'}
        )
        self.assertEqual(generate_notes_response.status_code, 200)
        self.assertIn('content', generate_notes_response.json)
        self.assertIn('key_concepts', generate_notes_response.json)
        
        # Get all notes
        get_all_notes_response = self.client.get(
            '/api/notes',
            headers={'Authorization': f'Bearer {token}'}
        )
        self.assertEqual(get_all_notes_response.status_code, 200)
        self.assertTrue(len(get_all_notes_response.json) >= 1)
    
    @patch('src.services.homework_service.openai')
    def test_homework_assistance(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        {
            "explanation": "To solve the quadratic equation x² + 5x + 6 = 0, we can use factoring.\n\nStep 1: Identify the factors of 6 that add up to 5.\nThe factors of 6 are: 1 and 6, 2 and 3.\nSince 2 + 3 = 5, we'll use these factors.\n\nStep 2: Rewrite the equation using these factors.\nx² + 5x + 6 = 0\nx² + 2x + 3x + 6 = 0\nx(x + 2) + 3(x + 2) = 0\n(x + 2)(x + 3) = 0\n\nStep 3: Set each factor equal to zero and solve.\nx + 2 = 0 → x = -2\nx + 3 = 0 → x = -3\n\nTherefore, the solutions are x = -2 and x = -3.",
            "steps": [
                "Identify the factors of 6 that add up to 5",
                "Rewrite the equation using these factors",
                "Set each factor equal to zero and solve"
            ]
        }
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Login the test user
        login_response = self.client.post('/api/auth/login', json={
            'email': 'test@example.com',
            'password': 'password123'
        })
        self.assertEqual(login_response.status_code, 200)
        token = login_response.json['token']
        
        # Get homework assistance
        homework_assistance_response = self.client.post(
            '/api/homework/assist',
            json={
                'problem': 'Solve the quadratic equation: x² + 5x + 6 = 0'
            },
            headers={'Authorization': f'Bearer {token}'}
        )
        self.assertEqual(homework_assistance_response.status_code, 200)
        self.assertIn('explanation', homework_assistance_response.json)
        self.assertIn('steps', homework_assistance_response.json)
    
    @patch('src.services.study_service.openai')
    def test_study_materials_generation(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        [
            {
                "front": "What is Newton's First Law of Motion?",
                "back": "An object at rest stays at rest, and an object in motion stays in motion unless acted upon by an external force."
            },
            {
                "front": "What is Newton's Second Law of Motion?",
                "back": "The acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass. F = ma"
            },
            {
                "front": "What is Newton's Third Law of Motion?",
                "back": "For every action, there is an equal and opposite reaction."
            }
        ]
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Login the test user
        login_response = self.client.post('/api/auth/login', json={
            'email': 'test@example.com',
            'password': 'password123'
        })
        self.assertEqual(login_response.status_code, 200)
        token = login_response.json['token']
        
        # Generate flashcards
        generate_flashcards_response = self.client.post(
            '/api/study/flashcards/generate',
            json={
                'content': "Newton's Laws of Motion include the First Law (inertia), the Second Law (F = ma), and the Third Law (equal and opposite reactions)."
            },
            headers={'Authorization': f'Bearer {token}'}
        )
        self.assertEqual(generate_flashcards_response.status_code, 200)
        self.assertTrue(len(generate_flashcards_response.json) > 0)
        self.assertIn('front', generate_flashcards_response.json[0])
        self.assertIn('back', generate_flashcards_response.json[0])

if __name__ == '__main__':
    unittest.main()
