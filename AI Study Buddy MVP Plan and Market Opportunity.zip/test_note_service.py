import unittest
from unittest.mock import patch, MagicMock
import sys
import os

# Add the project root to the path so we can import our modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.services.note_service import NoteService
from src.models.note import Note

class TestNoteService(unittest.TestCase):
    def setUp(self):
        self.note_service = NoteService()
        
    @patch('src.services.note_service.openai')
    def test_generate_notes_from_content(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        # Lecture Notes: Introduction to Python
        
        ## Key Concepts
        - Python is a high-level, interpreted programming language
        - Python emphasizes code readability with its notable use of significant whitespace
        - Python supports multiple programming paradigms
        
        ## Important Points
        1. Created by Guido van Rossum in 1991
        2. Named after Monty Python
        3. Uses indentation for code blocks instead of curly braces
        
        ## Summary
        Python is widely used in data science, web development, and automation.
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        lecture_content = "Python is a programming language. It was created by Guido van Rossum. Python is used for web development, data science, and automation."
        
        # Call the method
        result = self.note_service.generate_notes_from_content(lecture_content)
        
        # Assertions
        self.assertIsInstance(result, dict)
        self.assertIn('content', result)
        self.assertIn('key_concepts', result)
        self.assertTrue(len(result['key_concepts']) > 0)
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        call_args = mock_openai.ChatCompletion.create.call_args[1]
        self.assertEqual(call_args['model'], 'gpt-4')
        self.assertIn('messages', call_args)
        
    @patch('src.services.note_service.openai')
    def test_extract_key_concepts(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        [
            "Python programming language",
            "Code readability",
            "Multiple programming paradigms",
            "Guido van Rossum",
            "Data science applications"
        ]
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        note_content = "Python is a high-level programming language known for its readability. It was created by Guido van Rossum and supports multiple programming paradigms. Python is widely used in data science."
        
        # Call the method
        result = self.note_service.extract_key_concepts(note_content)
        
        # Assertions
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) > 0)
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()
        
    @patch('src.services.note_service.openai')
    def test_suggest_tags(self, mock_openai):
        # Mock the OpenAI API response
        mock_response = MagicMock()
        mock_response.choices[0].message.content = """
        [
            "python",
            "programming",
            "data science",
            "web development",
            "automation"
        ]
        """
        mock_openai.ChatCompletion.create.return_value = mock_response
        
        # Test input
        note_content = "Python is used for web development, data science, and automation."
        
        # Call the method
        result = self.note_service.suggest_tags(note_content)
        
        # Assertions
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) > 0)
        
        # Verify OpenAI was called with correct parameters
        mock_openai.ChatCompletion.create.assert_called_once()

if __name__ == '__main__':
    unittest.main()
